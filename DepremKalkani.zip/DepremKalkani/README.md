# Deprem Kalkanı (Android, Kotlin + Jetpack Compose)

Verdiğin iki uygulamanın (Deprem Türk + Earthquake Network) özelliklerini tek, modern uygulamada birleştirir.

## APK nasıl alınır
1. Android Studio (Koala veya yeni) ile bu klasörü aç, "Sync" bekle (Gradle 8.9 ve bağımlılıklar kendiliğinden iner).
2. Test için: `Run ▶` ile telefona kur. APK için: **Build ▸ Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`.
3. Yayın için: **Build ▸ Generate Signed Bundle / APK**.

## Özellikler
- **Canlı deprem listesi**: AFAD + Kandilli + EMSC + USGS'ten **doğrudan** çekilir, birleştirilir, tekilleştirilir, telefona kaydedilir (açılışta son veri hazır). Önemli tarihî depremler uygulamayla birlikte gelir.
- **Bildirim**: büyüklük eşiği, **bölge** (Tüm Türkiye / Dünya / seçtiğin iller / konuma yarıçap), kaynak seçimi, ses (sistem, siren, SOS, nükleer), titreşim, gece modu. Arka planda ön plan servisiyle çalışır, telefon açılınca otomatik başlar.
- **Tam ekran sismik dalga ekranı**: yıldız = merkez üssü, genişleyen kırmızı daire = dalga, mavi nokta = sen, "X saniyede sismik dalga" geri sayımı, sarsıntı şiddeti kestirimi.
- **Harita** (OpenStreetMap, anahtar gerekmez): büyüklüğe göre renkli/boyutlu işaretler, konumun, toplanma alanları (çevrimdışı saklanır).
- **Acil mod**: "ENKAZ ALTINDAYIM" → düdük (SON SES seçeneği, 3'lü SOS düzeni), flaşla SOS ışığı, titreşim, yakındakilere periyodik SOS+konum. Ekran kapalıyken de çalışır.
- **İnternetsiz yakın cihaz iletişimi** (Google Nearby Connections: Bluetooth + Wi-Fi Direct): mesaj, konum, "Güvendeyim / Yaralıyım / Enkaz altındayım / Su-ilaç lazım", aile kodu, zincirleme aktarım (8 atlama), "hissettim" bildirimleri.
- **Yakınlarım**: aile/tanıdık ekle (davet kodu ile, şifreli). "Güvendeyim", "Güvende misin?", "Yardım lazım" gönder; karşı tarafa bildirim gider, bildirimden tek dokunuşla cevap verir. Deprem bildiriminde "Yakınlarıma: Güvendeyim" düğmesi, Acil moddaki SOS yakınlarına da gider. İnternetle (ntfy aktarma sunucusu, uçtan uca şifreli) veya internetsiz (Yakındakiler zinciri) iletilir.
- **SMS ile durum + konum** (acil kişilere; SMS uygulaması açılır, sen gönder'e basarsın).
- **Sismograf + yerel sarsıntı algılayıcı** (ivmeölçer, STA/LTA).
- Hazırlık rehberi, deprem çantası listesi, acil numaralar, tıbbi not.
- **Reklam (AdMob) + Pro (tek seferlik, Play Billing)** ve Google UMP onay formu.

## Yayından önce yapman gerekenler
1. `gradle.properties`: AdMob uygulama/banner kimliklerini kendi hesabınla değiştir (şu an Google'ın **test** kimlikleri var). `PRO_PRODUCT_ID` ile aynı kimlikte Play Console'da tek seferlik ürün aç.
2. `app/build.gradle.kts`: `applicationId` değiştir (isteğe bağlı).
3. Play Console: ön plan servisi (specialUse, mediaPlayback) ve konum beyanlarını doldur.

## Bu kodda doğrulayamadığım noktalar (gerçek telefonda dene)
- Kodu derleyemedim; ortamımda Android SDK ve internet yoktu. Sadece sözdizimi denetimi yapıldı. Derleme hatası çıkarsa hata metnini bana gönder, düzelteyim.
- AFAD API zamanını UTC kabul ediyorum; AFAD sitesiyle saatleri karşılaştır, 3 saat kayma varsa `Sources.fetchAfad` içindeki saat dilimini değiştir.
- Kandilli sayfası metin olarak ayrıştırılıyor; biçimi değişirse `Sources.fetchKandilli` ayarlanmalı.
- Nearby Connections en az iki gerçek telefonla denenmeli (emülatörde çalışmaz).

## Yakınlarım hakkında
- Davet kodunu afetten ÖNCE, internet varken paylaş. Kodu bilen herkes o iki kişinin mesajlarını okuyabilir.
- İnternet yolu varsayılan olarak herkese açık ntfy.sh sunucusunu kullanır (mesajlar şifreli). Kendi ntfy sunucun varsa "Yakınlarım › Aktarma sunucusu" alanına yaz.
- Alıcı telefonda canlı takip servisi çalışmalı; aksi halde mesaj, uygulama açılınca (ntfy yaklaşık 12 saat saklar) gelir.

## Sunucu gerektirdiği için YAPILMAYANLAR
- Türkiye genelinde tüm kullanıcılardan toplanan "N kişi hissetti" bildirimi, ortak telefon ağıyla erken algılama, herkese açık sohbet, arkadaşlık. Bunlar bir sunucu ister (ör. Firebase). İstersen sonraki adımda eklenir.
- Telefon kapalıyken/uygulama öldürülmüşken anlık itme bildirimi (FCM) de sunucu ister; şimdiki sistem, uygulama servisinin çalışmasına bağlıdır (pil kısıtlamasını kapat).

## GitHub ile APK alma (bilgisayara Android Studio kurmadan)
1. GitHub'da yeni depo aç, bu klasörün İÇİNDEKİ her şeyi (`.github` klasörü dahil) yükle (Add file ▸ Upload files).
2. Üstteki **Actions** sekmesi ▸ "APK derle" çalışır (yeşil tik ~5-10 dk).
3. Çalışmaya tıkla ▸ en altta **Artifacts** ▸ `DepremKalkani-APK` indir ▸ zip içindeki `app-debug.apk`'yı telefona kur.
Hata (kırmızı) olursa çalışmanın log metnini bana gönder.

## v1.1 yenilikleri
- Gönderim onayı: SOS/durum/Yakınlarım/yakın cihaz mesajlarında "Gönderildi ✓" bildirimi ve acil ekranda gönderim özeti penceresi.
- Sismik dalga testi + uyarı mesafesi ve test mesafesi ayarı (Daha fazla > Ayarlar > Sismik dalga).
- "Deprem hissettim" toplu bildirimi: ntfy üzerinden bölge hücresi; eşikten fazla kullanıcı bildirirse "Kullanıcılar deprem hissedildiğini bildiriyor" bildirimi, dokununca Hissettim/Hissetmedim ekranı. Doğrulama yoktur, sahte oy mümkündür.
- targetSdk 34, v1+v2+v3 imza; minSdk 26 (Android 8+).
