import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

fun prop(name: String, def: String): String =
    (project.findProperty(name) as String?) ?: def

android {
    namespace = "app.depremkalkani"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.depremkalkani"
        minSdk = 26
        targetSdk = 36
        versionCode = (System.currentTimeMillis() / 60000L).toInt()   // her derlemede otomatik artar (Play her yüklemede yeni kod ister)
        versionName = "1.0.3"
        manifestPlaceholders["admobAppId"] = prop("ADMOB_APP_ID", "ca-app-pub-3940256099942544~3347511713")
        buildConfigField("String", "ADMOB_BANNER_ID", "\"${prop("ADMOB_BANNER_ID", "ca-app-pub-3940256099942544/6300978111")}\"")
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", "\"${prop("GOOGLE_WEB_CLIENT_ID", "")}\"")
        buildConfigField("String", "PLAY_LICENSE_KEY", "\"${prop("PLAY_LICENSE_KEY", "")}\"")
        buildConfigField("String", "TRUSTED_CERTS", "\"${prop("TRUSTED_CERTS", "")}\"")
        buildConfigField("String", "PRO_PRODUCT_ID", "\"${prop("PRO_PRODUCT_ID", "pro_remove_ads")}\"")
        buildConfigField("String", "PRO_SUB_ID", "\"${prop("PRO_SUB_ID", "pro_sub")}\"")
        buildConfigField("String", "PRO_SUB_YEARLY_ID", "\"${prop("PRO_SUB_YEARLY_ID", "pro_yearly")}\"")
        buildConfigField("String", "PRO_PLAN_MONTHLY", "\"${prop("PRO_PLAN_MONTHLY", "aylik")}\"")
        buildConfigField("String", "PRO_PLAN_YEARLY", "\"${prop("PRO_PLAN_YEARLY", "yillik")}\"")
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android"
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
        }
    }
    buildTypes {
        debug {
            // Test APK'sında kendi reklamına dokunup hesabını riske atma: her zaman Google test reklamları
            manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713"
            buildConfigField("String", "ADMOB_BANNER_ID", "\"ca-app-pub-3940256099942544/6300978111\"")
        }
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = true            // R8: kod küçültme + karartma (Play "DEX kod optimizasyonu" uyarısı)
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
            "-opt-in=androidx.compose.foundation.layout.ExperimentalLayoutApi",
        )
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")   // QR tarama: kamera izni gerektirmez
    implementation("com.google.zxing:core:3.5.3")                                // QR üretme
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")

    val bom = platform("androidx.compose:compose-bom:2024.09.02")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")

    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
    implementation("com.google.android.gms:play-services-ads:23.3.0")
    implementation("com.google.android.ump:user-messaging-platform:3.0.0")
    implementation("com.android.billingclient:billing-ktx:8.0.0")
    implementation("com.google.android.play:review-ktx:2.0.1")
    implementation("com.google.android.play:app-update-ktx:2.1.0")   // uygulama içi güncelleme (arka planda indirme)

    implementation("org.osmdroid:osmdroid-android:6.1.18")
}
