# Uygulamanın kendi kodu: yansıma/manifest adlarıyla sorun çıkmaması için olduğu gibi kalır.
# Küçültme ve karartma kütüphane kodunda (Compose, Play Hizmetleri, OkHttp, osmdroid...) yapılır.
-keep class app.depremkalkani.** { *; }

# Credential Manager sağlayıcıyı sınıf adıyla yükler (yansıma)
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }

# OSM harita
-keep class org.osmdroid.** { *; }
-dontwarn org.osmdroid.**

# OkHttp isteğe bağlı sağlayıcılar (cihazda yoksa uyarı verme)
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**

# Play faturalandırma / güncelleme / yorum: kendi tüketici kuralları var; yine de eksik sınıf uyarısını yoksay
-dontwarn com.google.android.play.core.**

# Çökme izlerinin okunabilmesi
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
