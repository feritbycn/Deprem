# Uygulamanın kendi kodu: yansıma/manifest adlarıyla sorun çıkmaması için olduğu gibi kalır.
# Küçültme ve karartma kütüphane kodunda (Compose, Play Hizmetleri, OkHttp, osmdroid...) yapılır.
-keep class app.depremkalkani.** { *; }

# Google girişi: Credential Manager sağlayıcıyı sınıf adıyla yükler (yansıma); Play Hizmetleri istemci sınıfları da olduğu gibi kalır
-keep class androidx.credentials.** { *; }
-keep class androidx.credentials.playservices.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
-keep class com.google.android.gms.auth.** { *; }
-keep class com.google.android.gms.common.** { *; }
-keep class com.google.android.gms.tasks.** { *; }
-keep class com.google.android.gms.internal.auth** { *; }
-keep class com.google.android.gms.internal.identity** { *; }
-keep class com.google.android.gms.internal.p00** { *; }
-keepclassmembers class * implements android.os.Parcelable { public static final ** CREATOR; }
-keep @com.google.android.gms.common.annotation.KeepName class *
-keepclassmembers class * { @com.google.android.gms.common.annotation.KeepName *; }
-keep class com.android.billingclient.** { *; }
-keep class com.google.android.ump.** { *; }
-keep class com.google.android.play.core.** { *; }
-keep class com.google.android.play.** { *; }

# OSM harita
-keep class org.osmdroid.** { *; }
-dontwarn org.osmdroid.**

# OkHttp isteğe bağlı sağlayıcılar (cihazda yoksa uyarı verme)
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**

# Play faturalandırma / güncelleme / yorum: kendi tüketici kuralları var; yine de eksik sınıf uyarısını yoksay
-dontwarn com.google.android.play.core.**

# Çökme izlerinin okunabilmesi
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
