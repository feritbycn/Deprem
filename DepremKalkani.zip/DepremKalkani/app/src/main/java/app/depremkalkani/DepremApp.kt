package app.depremkalkani

import android.app.Application
import android.content.Context
import app.depremkalkani.data.Notifs
import app.depremkalkani.data.Prefs
import app.depremkalkani.data.QuakeRepository
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.billing.BillingManager
import org.osmdroid.config.Configuration

class DepremApp : Application() {
    val prefs by lazy { Prefs(this) }
    val repo by lazy { QuakeRepository(this) }
    val billing by lazy { BillingManager(this, prefs) }

    override fun onCreate() {
        super.onCreate()
        Notifs.createChannels(this)
        Mesh.init(this, prefs)
        app.depremkalkani.data.Circles.init(this, prefs)
        Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = cacheDir
            osmdroidTileCache = cacheDir.resolve("tiles")
        }
    }
}

