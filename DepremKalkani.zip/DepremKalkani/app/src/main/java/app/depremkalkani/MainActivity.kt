package app.depremkalkani

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.data.Quake
import app.depremkalkani.data.Seed
import app.depremkalkani.service.LocationHelper
import app.depremkalkani.service.MonitorService
import app.depremkalkani.ui.*
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

sealed interface Dest {
    data object Home : Dest
    data object Map : Dest
    data object Emergency : Dest
    data object Mesh : Dest
    data object More : Dest
    data object Felt : Dest
    data class Detail(val q: Quake) : Dest
    data class Alert(val q: Quake) : Dest
    data class MapAt(val q: Quake) : Dest
    data class Sub2(val s: Sub) : Dest
}

class MainActivity : ComponentActivity() {
    private val adsStarted = AtomicBoolean(false)
    private val pendingQuake = mutableStateOf<String?>(null)
    private var pendingAlert = false
    private val pendingFelt = mutableStateOf(false)
    private val pendingDest = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (android.os.Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        pendingQuake.value = intent?.getStringExtra("quake_id")
        pendingAlert = intent?.getBooleanExtra("alert", false) == true
        pendingFelt.value = intent?.getBooleanExtra("felt", false) == true
        pendingDest.value = intent?.getStringExtra("dest")
        dk.prefs.launchCount = dk.prefs.launchCount + 1
        if (dk.prefs.firstLaunch == 0L) dk.prefs.firstLaunch = System.currentTimeMillis()
        runCatching { setupAds() }
        runCatching { app.depremkalkani.mesh.Mesh.autoStart(Perms.hasNearby(this)) }
        runCatching { dk.billing.connect() }
        if ((dk.prefs.monitorOn || app.depremkalkani.data.Circles.members.value.isNotEmpty()) && Perms.has(this, Perms.notification)) runCatching { MonitorService.start(this) }
        ThemeState.load(dk.prefs.themeMode)
        val skipSplash = pendingAlert
        setContent { DepremTheme { Box(Modifier.fillMaxSize()) { Root(); AppSplash(skipSplash) } } }
    }

    override fun onStop() {
        super.onStop()
        runCatching { android.app.backup.BackupManager(this).dataChanged() }
        lifecycleScope.launch { runCatching { app.depremkalkani.data.CloudBackup.autoBackup(applicationContext, dk.prefs) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingQuake.value = intent.getStringExtra("quake_id")
        pendingAlert = intent.getBooleanExtra("alert", false)
        if (intent.getBooleanExtra("felt", false)) pendingFelt.value = true
        intent.getStringExtra("dest")?.let { pendingDest.value = it }
    }

    // ---- Google UMP onay formu + AdMob (kullanıcı Pro ise reklam hiç başlatılmaz)
    private fun setupAds() {
        if (dk.prefs.isPro) return
        val info = UserMessagingPlatform.getConsentInformation(this)
        val start = {
            if (info.canRequestAds() && adsStarted.compareAndSet(false, true)) {
                MobileAds.initialize(this) { AdsGate.ready.value = true }
            }
        }
        info.requestConsentInfoUpdate(this, ConsentRequestParameters.Builder().build(), {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) { start() }
        }, { start() })
        start()
    }

    @Composable
    private fun Root() {
        val prefs = dk.prefs
        val isPro by dk.billing.isPro.collectAsState()
        val all by dk.repo.quakes.collectAsState()
        val sysDark = androidx.compose.foundation.isSystemInDarkTheme()
        val darkNow = ThemeState.choice.value ?: sysDark
        SideEffect {
            val c = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            c.isAppearanceLightStatusBars = !darkNow; c.isAppearanceLightNavigationBars = !darkNow
        }
        var onboarded by remember { mutableStateOf(prefs.onboarded) }
        var stack by remember { mutableStateOf(listOf<Dest>(Dest.Home)) }
        val cur = stack.last()
        val scope = rememberCoroutineScope()

        // önceki açılışta uygulama çöktüyse sebebini göster (teşhis için paylaşılabilir)
        val crashFile = remember { java.io.File(filesDir, "last_crash.txt") }
        var crashText by remember { mutableStateOf(runCatching { if (crashFile.exists()) crashFile.readText() else null }.getOrNull()) }
        crashText?.let { txt ->
            AlertDialog(
                onDismissRequest = { runCatching { crashFile.delete() }; crashText = null },
                title = { Text("Uygulama önceki açılışta kapanmıştı") },
                text = { Text(txt.take(900), fontSize = 11.sp) },
                confirmButton = { TextButton({
                    runCatching {
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, txt), "Hata kaydını gönder"))
                    }
                }) { Text("Paylaş") } },
                dismissButton = { TextButton({ runCatching { crashFile.delete() }; crashText = null }) { Text("Kapat") } },
            )
        }

        LaunchedEffect(Unit) { LocationHelper.refresh(this@MainActivity) }
        // Uygulama açıkken yakın mesajlarını/ilini anlık çek (arka plandayken canlı takip servisi çalışır)
        val lifeOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
        LaunchedEffect(lifeOwner) {
            lifeOwner.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.RESUMED) {
                while (true) { runCatching { app.depremkalkani.data.Circles.pollNow() }; kotlinx.coroutines.delay(6000) }
            }
        }
        // İzin/giriş ekranları açıkken deprem verisi arka planda hemen çekilsin; ana ekran açıldığında hazır olsun
        LaunchedEffect(Unit) {
            runCatching { dk.repo.refresh(prefs.sources.ifEmpty { setOf(app.depremkalkani.data.Sources.AFAD) }) }
        }
        LaunchedEffect(pendingDest.value) {
            when (pendingDest.value) {
                "circle" -> stack = listOf(Dest.Home, Dest.Sub2(Sub.CIRCLE))
                "mesh" -> stack = listOf(Dest.Mesh)
                "perms" -> stack = listOf(Dest.Home, Dest.Sub2(Sub.PERMS))
                else -> {}
            }
            pendingDest.value = null
        }
        LaunchedEffect(pendingFelt.value) {
            if (pendingFelt.value) { stack = stack + Dest.Felt; pendingFelt.value = false }
        }
        LaunchedEffect(pendingQuake.value, all.size) {
            val id = pendingQuake.value ?: return@LaunchedEffect
            (all + Seed.notable + listOfNotNull(app.depremkalkani.data.TestQuake.q)).firstOrNull { it.id == id }?.let {
                val fresh = System.currentTimeMillis() - it.time < 15 * 60_000L
                stack = stack + (if (pendingAlert && fresh) Dest.Alert(it) else Dest.Detail(it)); pendingQuake.value = null; pendingAlert = false
            }
        }

        fun go(d: Dest) { stack = stack + d }
        fun tab(d: Dest) { stack = listOf(d) }
        BackHandler(enabled = stack.size > 1) { stack = stack.dropLast(1) }

        if (!onboarded) {
            Onboarding { prefs.onboarded = true; onboarded = true
                if (prefs.monitorOn) runCatching { MonitorService.start(this) }
                scope.launch { LocationHelper.refresh(this@MainActivity) } }
            return
        }

        if (cur is Dest.Alert) { DepremTheme(forceDark = true) { AlertScreen(cur.q, onClose = { stack = stack.dropLast(1) }) }; return }
        if (cur is Dest.Home) { LateAsks(); ReviewAsk() }
        val isTab = cur is Dest.Home || cur is Dest.Map || cur is Dest.Emergency || cur is Dest.Mesh || cur is Dest.More
        val imeOpen = WindowInsets.ime.getBottom(androidx.compose.ui.platform.LocalDensity.current) > 0
        Scaffold(
            modifier = Modifier.imePadding(),
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                if (!isTab) TopAppBar(
                    title = { Text(titleOf(cur)) },
                    navigationIcon = { IconButton({ stack = stack.dropLast(1) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
            },
            bottomBar = {
                if (!imeOpen && isTab) Column {   // klavye açıkken alt çubuk ve reklam gizlenir; yazı kutusu klavyenin üstünde kalır
                    if (isTab && cur !is Dest.Emergency) AdBanner(isPro)
                    if (isTab) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        Item("Deprem", Icons.Filled.Public, cur is Dest.Home) { tab(Dest.Home) }
                        Item("Harita", Icons.Filled.Map, cur is Dest.Map) { tab(Dest.Map) }
                        Item("ACİL", Icons.Filled.Warning, cur is Dest.Emergency, tint = DK.Danger) { tab(Dest.Emergency) }
                        Item("Yakınımdakiler", Icons.Filled.Sensors, cur is Dest.Mesh) { tab(Dest.Mesh) }
                        Item("Daha fazla", Icons.Filled.Menu, cur is Dest.More) { tab(Dest.More) }
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(if (cur is Dest.Map) PaddingValues(bottom = pad.calculateBottomPadding()) else pad).fillMaxSize()) {
                LaunchedEffect(cur) { RefreshClock.maybe(this@MainActivity) }
                when (val d = cur) {
                    Dest.Home -> HomeScreen({ go(Dest.Detail(it)) }, { go(Dest.Sub2(Sub.PRO)) }, { go(Dest.Sub2(Sub.CIRCLE)) }, { go(Dest.Felt) }, { go(Dest.Sub2(Sub.PERMS)) })
                    Dest.Map -> MapScreen(null) { go(Dest.Detail(it)) }
                    is Dest.MapAt -> MapScreen(d.q) { go(Dest.Detail(it)) }
                    Dest.Emergency -> GlobalRefresh { EmergencyScreen { go(Dest.Sub2(Sub.SETTINGS)) } }
                    Dest.Mesh -> GlobalRefresh { MeshScreen() }
                    Dest.Felt -> FeltScreen()
                    Dest.More -> GlobalRefresh { MoreScreen { go(Dest.Sub2(it)) } }
                    is Dest.Detail -> GlobalRefresh { DetailScreen(d.q, { go(Dest.MapAt(it)) }, { go(Dest.Alert(it)) }) }
                    is Dest.Alert -> {}
                    is Dest.Sub2 -> when (d.s) {
                        Sub.CIRCLE -> CircleScreen(); Sub.WAVE -> GlobalRefresh { WaveScreen() }; Sub.GUIDE -> GlobalRefresh { GuideScreen() }; Sub.SETTINGS -> GlobalRefresh { SettingsScreen { go(Dest.Alert(it)) } }
                        Sub.PERMS -> PermsScreen(); Sub.PRO -> GlobalRefresh { ProScreen() }; Sub.ABOUT -> GlobalRefresh { AboutScreen() }
                    }
                }
            }
        }
    }

    private fun titleOf(d: Dest) = when (d) {
        is Dest.Detail -> "Deprem detayı"; Dest.Felt -> "Deprem hissettin mi?"; is Dest.Alert -> ""; is Dest.MapAt -> "Harita"
        is Dest.Sub2 -> when (d.s) { Sub.CIRCLE -> "Yakınlarım"; Sub.WAVE -> "Sismograf"; Sub.GUIDE -> "Rehber"; Sub.SETTINGS -> "Ayarlar"; Sub.PERMS -> "Kurulum ve izinler"; Sub.PRO -> "Pro"; Sub.ABOUT -> "Hakkında" }
        else -> ""
    }

    @Composable
    private fun RowScope.Item(label: String, icon: ImageVector, selected: Boolean, tint: Color? = null, onClick: () -> Unit) {
        NavigationBarItem(
            selected = selected, onClick = onClick,
            icon = { Icon(icon, label, tint = tint ?: LocalContentColor.current) },
            label = { Text(label, fontSize = 10.sp, maxLines = 1) },
            alwaysShowLabel = true,
        )
    }

    @Composable
    private fun ReviewAsk() {
        val prefs = dk.prefs
        val due = remember { Reviews.due(prefs) }
        val onExit = remember { kotlin.random.Random.nextBoolean() }   // bazen çıkarken, bazen kullanırken sor
        var show by remember { mutableStateOf(false) }
        var exiting by remember { mutableStateOf(false) }
        var done by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        LaunchedEffect(Unit) {
            if (due && !onExit) { kotlinx.coroutines.delay(25_000); if (!done) show = true }
        }
        BackHandler(enabled = due && onExit && !done) { exiting = true; show = true }
        if (show) AlertDialog(
            onDismissRequest = { Reviews.markAsked(prefs); done = true; show = false; if (exiting) finish() },
            title = { Text("Görüşün bizim için önemli") },
            text = { Text("Deprem Kalkanı'nı kullandıysan birkaç saniyeni ayırıp puanlayabilir ve yorum yazabilirsin. Yorumların uygulamayı geliştirmemize ve daha fazla kişiye ulaşmasına yardım eder.") },
            confirmButton = { TextButton({ Reviews.markAsked(prefs); done = true; show = false; scope.launch { Reviews.launchInApp(this@MainActivity) } }) { Text("Puan ver") } },
            dismissButton = { TextButton({ Reviews.markAsked(prefs); done = true; show = false; if (exiting) finish() }) { Text("Sonra") } },
        )
    }

    @Composable
    private fun LateAsks() {
        val prefs = dk.prefs
        val ctx = this
        var ask by remember {
            mutableIntStateOf(when {
                prefs.launchCount < 2 -> 0
                android.os.Build.VERSION.SDK_INT >= 34 && !prefs.fsiAsked && !getSystemService(android.app.NotificationManager::class.java).canUseFullScreenIntent() -> 1
                !prefs.battAsked && !getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(packageName) -> 2
                else -> 0
            })
        }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}
        if (ask == 1) ExplainDialog("Kilit ekranında uyarı",
            "Sismik dalga uyarısının, ekran kilitliyken veya kapalıyken tam ekran açılıp geri sayımı göstermesini sağlar. Sonraki ekranda Deprem Kalkanı'nı bulup izni aç.",
            onOk = { prefs.fsiAsked = true; ask = 0
                runCatching { launcher.launch(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, android.net.Uri.parse("package:$packageName"))) } },
            onCancel = { prefs.fsiAsked = true; ask = 0 })
        if (ask == 2) ExplainDialog("Arka planda çalışma",
            "Telefon pil tasarrufuna girince uygulamanın kapatılmaması ve depremleri sürekli takip edebilmesi için pil kısıtlamasının kaldırılması önerilir. Açılan listede Deprem Kalkanı'nı bulup kısıtlamayı kaldır.",
            onOk = { prefs.battAsked = true; ask = 0
                runCatching { launcher.launch(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } },
            onCancel = { prefs.battAsked = true; ask = 0 })
    }

    private class PStep(val title: String, val why: String, val perms: Array<String>? = null, val settings: (() -> Intent)? = null)

    @Composable
    private fun Onboarding(done: () -> Unit) {
        val ctx = this
        val steps = remember {
            buildList {
                if (android.os.Build.VERSION.SDK_INT >= 33 && !Perms.has(ctx, Perms.notification))
                    add(PStep("Bildirim izni", "Deprem uyarılarını, sismik dalga bildirimini ve yakınlarından gelen mesajları sana gösterebilmek için gerekir.", Perms.notification))
                if (!Perms.has(ctx, Perms.location))
                    add(PStep("Konum izni", "Depremin sana uzaklığını hesaplamak, bölgene göre uyarı vermek ve acil durumda konumunu paylaşmak için kullanılır. Konumun sunucuya kaydedilmez.", Perms.location))
            }
        }
        var step by remember { mutableIntStateOf(-1) }   // -1 = karşılama
        val prefs = dk.prefs
        val scope = rememberCoroutineScope()
        var login by remember { mutableStateOf(false) }
        var loginMsg by remember { mutableStateOf<String?>(null) }
        val driveSetup = rememberDriveSetup(false) { _ -> prefs.loginAsked = true; done() }
        fun afterSteps() { if (prefs.accountEmail.isBlank() && !prefs.loginAsked) login = true else done() }
        fun next() { if (step + 1 >= steps.size) afterSteps() else step++ }
        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { next() }
        val setLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { next() }
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Spacer(Modifier.height(24.dp))
            Text("Deprem Kalkanı", style = MaterialTheme.typography.headlineLarge)
            if (login) {
                Text("Google ile giriş (isteğe bağlı)", style = MaterialTheme.typography.titleLarge)
                Card2 {
                    Text("Giriş yaparsan adın otomatik doldurulur, Pro satın alımın ve Yakınlarım listen telefon değişince kaybolmaz. Sadece adın ve e-postan alınır; giriş zorunlu değildir, uygulamanın hiçbir temel özelliği girişe bağlı değildir.", fontSize = 14.sp)
                }
                BigButton("Google ile devam et", {
                    scope.launch {
                        loginMsg = GoogleAuth.signIn(this@MainActivity)
                        if (loginMsg == null) driveSetup()
                    }
                })
                loginMsg?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
                TextButton({ prefs.loginAsked = true; done() }, Modifier.align(Alignment.CenterHorizontally)) { Text("Şimdilik atla") }
            } else if (step < 0 || steps.isEmpty()) {
                Text("Depremleri canlı takip et, bölgene göre bildirim al, afet anında düdük ve SOS ile yardım çağır; internet yokken bile yakındakilerle iletişimde kal.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Card2 {
                    Text("Önce iki temel izin", style = MaterialTheme.typography.titleMedium)
                    Text("Bildirim ve konum izninin ne işe yaradığını vermeden önce kısaca anlatacağız. Diğer izinleri (Bluetooth, SMS, kilit ekranı, pil) ilgili özelliği kullanırken, o an açıklayarak isteyeceğiz. İstemediğin izni atlayabilirsin.", fontSize = 14.sp)
                }
                BigButton("Başla", { if (steps.isEmpty()) afterSteps() else step = 0 })
                TextButton({ done() }, Modifier.align(Alignment.CenterHorizontally)) { Text("Şimdilik atla") }
            } else {
                val st = steps[step]
                Text("İzin ${step + 1} / ${steps.size}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                LinearProgressIndicator(progress = { (step + 1f) / steps.size }, modifier = Modifier.fillMaxWidth())
                Card2 {
                    Text(st.title, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(6.dp))
                    Text(st.why, fontSize = 15.sp)
                }
                BigButton("İzin ver", {
                    val pr = st.perms; val se = st.settings
                    if (pr != null) permLauncher.launch(pr.distinct().toTypedArray())
                    else if (se != null) runCatching { setLauncher.launch(se()) }.onFailure { next() }
                })
                TextButton({ next() }, Modifier.align(Alignment.CenterHorizontally)) { Text("Bunu atla") }
            }
        }
        }
    }
}

val android.content.Context.dk: DepremApp get() = applicationContext as DepremApp
