package app.depremkalkani

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.data.Quake
import app.depremkalkani.data.Seed
import app.depremkalkani.service.LocationHelper
import app.depremkalkani.service.MonitorService
import app.depremkalkani.ui.*
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

sealed interface Dest {
    data object Home : Dest
    data object Map : Dest
    data object Emergency : Dest
    data object Mesh : Dest
    data object More : Dest
    data class Detail(val q: Quake) : Dest
    data class Alert(val q: Quake) : Dest
    data class MapAt(val q: Quake) : Dest
    data class Sub2(val s: Sub) : Dest
}

class MainActivity : ComponentActivity() {
    private val adsStarted = AtomicBoolean(false)
    private val pendingQuake = mutableStateOf<String?>(null)
    private var pendingAlert = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingQuake.value = intent?.getStringExtra("quake_id")
        pendingAlert = intent?.getBooleanExtra("alert", false) == true
        setupAds()
        dk.billing.connect()
        if ((dk.prefs.monitorOn || app.depremkalkani.data.Circles.members.value.isNotEmpty()) && Perms.has(this, Perms.notification)) runCatching { MonitorService.start(this) }
        setContent { DepremTheme { Root() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingQuake.value = intent.getStringExtra("quake_id")
        pendingAlert = intent.getBooleanExtra("alert", false)
    }

    // ---- Google UMP onay formu + AdMob (kullanıcı Pro ise reklam hiç başlatılmaz)
    private fun setupAds() {
        if (dk.prefs.isPro) return
        val info = UserMessagingPlatform.getConsentInformation(this)
        val start = {
            if (info.canRequestAds() && adsStarted.compareAndSet(false, true)) {
                MobileAds.initialize(this) { AdsGate.ready.value = true }
            }
        }
        info.requestConsentInfoUpdate(this, ConsentRequestParameters.Builder().build(), {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) { start() }
        }, { start() })
        start()
    }

    @Composable
    private fun Root() {
        val prefs = dk.prefs
        val isPro by dk.billing.isPro.collectAsState()
        val all by dk.repo.quakes.collectAsState()
        var onboarded by remember { mutableStateOf(prefs.onboarded) }
        var stack by remember { mutableStateOf(listOf<Dest>(Dest.Home)) }
        val cur = stack.last()
        val scope = rememberCoroutineScope()

        LaunchedEffect(Unit) { LocationHelper.refresh(this@MainActivity) }
        LaunchedEffect(pendingQuake.value, all.size) {
            val id = pendingQuake.value ?: return@LaunchedEffect
            (all + Seed.notable).firstOrNull { it.id == id }?.let {
                val fresh = System.currentTimeMillis() - it.time < 15 * 60_000L
                stack = stack + (if (pendingAlert && fresh) Dest.Alert(it) else Dest.Detail(it)); pendingQuake.value = null; pendingAlert = false
            }
        }

        fun go(d: Dest) { stack = stack + d }
        fun tab(d: Dest) { stack = listOf(d) }
        BackHandler(enabled = stack.size > 1) { stack = stack.dropLast(1) }

        if (!onboarded) {
            Onboarding { prefs.onboarded = true; onboarded = true
                if (prefs.monitorOn) runCatching { MonitorService.start(this) }
                scope.launch { LocationHelper.refresh(this@MainActivity) } }
            return
        }

        if (cur is Dest.Alert) { AlertScreen(cur.q, onClose = { stack = stack.dropLast(1) }); return }
        val isTab = cur is Dest.Home || cur is Dest.Map || cur is Dest.Emergency || cur is Dest.Mesh || cur is Dest.More
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                if (!isTab) TopAppBar(
                    title = { Text(titleOf(cur)) },
                    navigationIcon = { IconButton({ stack = stack.dropLast(1) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
            },
            bottomBar = {
                Column {
                    if (isTab && cur !is Dest.Emergency) AdBanner(isPro)
                    if (isTab) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        Item("Deprem", Icons.Filled.Public, cur is Dest.Home) { tab(Dest.Home) }
                        Item("Harita", Icons.Filled.Map, cur is Dest.Map) { tab(Dest.Map) }
                        Item("ACİL", Icons.Filled.Warning, cur is Dest.Emergency, tint = DK.Danger) { tab(Dest.Emergency) }
                        Item("Yakınımdakiler", Icons.Filled.Sensors, cur is Dest.Mesh) { tab(Dest.Mesh) }
                        Item("Daha fazla", Icons.Filled.Menu, cur is Dest.More) { tab(Dest.More) }
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(if (cur is Dest.Map) PaddingValues(bottom = pad.calculateBottomPadding()) else pad).fillMaxSize()) {
                when (val d = cur) {
                    Dest.Home -> HomeScreen({ go(Dest.Detail(it)) }, { go(Dest.Sub2(Sub.PRO)) }, { go(Dest.Sub2(Sub.CIRCLE)) })
                    Dest.Map -> MapScreen(null) { go(Dest.Detail(it)) }
                    is Dest.MapAt -> MapScreen(d.q) { go(Dest.Detail(it)) }
                    Dest.Emergency -> EmergencyScreen { go(Dest.Sub2(Sub.SETTINGS)) }
                    Dest.Mesh -> MeshScreen()
                    Dest.More -> MoreScreen { go(Dest.Sub2(it)) }
                    is Dest.Detail -> DetailScreen(d.q, { go(Dest.MapAt(it)) }, { go(Dest.Alert(it)) })
                    is Dest.Alert -> {}
                    is Dest.Sub2 -> when (d.s) {
                        Sub.CIRCLE -> CircleScreen(); Sub.WAVE -> WaveScreen(); Sub.GUIDE -> GuideScreen(); Sub.SETTINGS -> SettingsScreen()
                        Sub.PRO -> ProScreen(); Sub.ABOUT -> AboutScreen()
                    }
                }
            }
        }
    }

    private fun titleOf(d: Dest) = when (d) {
        is Dest.Detail -> "Deprem detayı"; is Dest.Alert -> ""; is Dest.MapAt -> "Harita"
        is Dest.Sub2 -> when (d.s) { Sub.CIRCLE -> "Yakınlarım"; Sub.WAVE -> "Sismograf"; Sub.GUIDE -> "Rehber"; Sub.SETTINGS -> "Ayarlar"; Sub.PRO -> "Pro"; Sub.ABOUT -> "Hakkında" }
        else -> ""
    }

    @Composable
    private fun RowScope.Item(label: String, icon: ImageVector, selected: Boolean, tint: Color? = null, onClick: () -> Unit) {
        NavigationBarItem(
            selected = selected, onClick = onClick,
            icon = { Icon(icon, label, tint = tint ?: LocalContentColor.current) },
            label = { Text(label, fontSize = 10.sp, maxLines = 1) },
            alwaysShowLabel = true,
        )
    }

    @Composable
    private fun Onboarding(done: () -> Unit) {
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { done() }
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Spacer(Modifier.height(24.dp))
            Text("Deprem Kalkanı", style = MaterialTheme.typography.headlineLarge)
            Text("Depremleri canlı takip et, bölgene göre bildirim al, afet anında düdük ve SOS ile yardım çağır; internet yokken bile yakındakilerle iletişimde kal.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Card2 {
                Text("Neden izin istiyoruz?", style = MaterialTheme.typography.titleMedium)
                Text("• Bildirim: deprem uyarıları için\n• Konum: depreme uzaklığı hesaplamak, bölge filtresi ve acil durumda konumunu paylaşmak için\nİzinleri vermesen de uygulamanın çoğu bölümü çalışır.",
                    fontSize = 14.sp)
            }
            BigButton("Başla", { launcher.launch(Perms.notification + Perms.location) })
            TextButton({ done() }, Modifier.align(Alignment.CenterHorizontally)) { Text("Şimdilik atla") }
        }
    }
}

val android.content.Context.dk: DepremApp get() = applicationContext as DepremApp
