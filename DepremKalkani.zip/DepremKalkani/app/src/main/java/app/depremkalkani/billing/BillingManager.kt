package app.depremkalkani.billing

import android.app.Activity
import android.content.Context
import app.depremkalkani.BuildConfig
import app.depremkalkani.data.Prefs
import com.android.billingclient.api.*
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * "Pro" = reklamsız + daha sık veri yenileme. Tek seferlik (kalıcı) ürün.
 * Play Console'da ürün kimliğini gradle.properties içindeki PRO_PRODUCT_ID ile aynı aç.
 */
class BillingManager(private val ctx: Context, private val prefs: Prefs) {
    val isPro = MutableStateFlow(prefs.isPro && Guard.environmentClean(ctx))
    val price = MutableStateFlow<String?>(null)
    val message = MutableStateFlow<String?>(null)
    private var details: ProductDetails? = null

    private val client: BillingClient = BillingClient.newBuilder(ctx.applicationContext)
        .setListener { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) purchases.forEach { handle(it) }
            else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED)
                message.value = "Satın alma tamamlanamadı (${result.responseCode})."
        }
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    fun connect() {
        if (client.isReady) return
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(r: BillingResult) {
                if (r.responseCode == BillingClient.BillingResponseCode.OK) { queryDetails(); restore() }
            }
            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun queryDetails() {
        val p = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(BuildConfig.PRO_PRODUCT_ID).setProductType(BillingClient.ProductType.INAPP).build()
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(p)).build()) { _, list ->
            details = list.firstOrNull()
            price.value = details?.oneTimePurchaseOfferDetails?.formattedPrice
        }
    }

    fun restore() {
        if (!Guard.environmentClean(ctx)) {
            prefs.revokePro(); isPro.value = false
            message.value = "Bu kurulum doğrulanamadı (değiştirilmiş uygulama veya sahte satın alma aracı). Pro devre dışı. Uygulamayı Google Play'den yükle."
            return
        }
        client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()) { r, list ->
            if (r.responseCode == BillingClient.BillingResponseCode.OK) {
                val valid = list.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED && it.products.contains(BuildConfig.PRO_PRODUCT_ID) && Guard.purchaseSignatureOk(it.originalJson, it.signature) }
                if (valid.isNotEmpty()) valid.forEach { handle(it) }
                else { prefs.revokePro(); isPro.value = false }   // Play "satın alım yok" diyorsa Pro kapanır (iade/sahte)
            }
            // yanıt başarısızsa (çevrimdışı) mevcut imzalı kayıt korunur
        }
    }

    fun buy(activity: Activity) {
        val d = details ?: run { message.value = "Ürün bilgisi alınamadı. Play Console'da ürünün tanımlı ve yayında olduğundan emin ol."; connect(); return }
        val params = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build()))
            .build()
        client.launchBillingFlow(activity, params)
    }

    private fun handle(p: Purchase) {
        if (p.purchaseState != Purchase.PurchaseState.PURCHASED || !p.products.contains(BuildConfig.PRO_PRODUCT_ID)) return
        if (!Guard.environmentClean(ctx) || !Guard.purchaseSignatureOk(p.originalJson, p.signature)) { message.value = "Satın alma doğrulanamadı."; return }
        if (!p.isAcknowledged) {
            client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) {}
        }
        prefs.grantPro(p.purchaseToken); isPro.value = true; message.value = "Pro etkinleştirildi, teşekkürler!"
    }
}
