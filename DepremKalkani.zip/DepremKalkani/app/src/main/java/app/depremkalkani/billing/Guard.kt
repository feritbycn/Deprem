package app.depremkalkani.billing

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Base64
import app.depremkalkani.BuildConfig
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Sahte satın alma / kırılmış APK korumaları (sunucusuz, istemci tarafı).
 * Mutlak koruma değildir; çıtayı yükseltir. Tam koruma için sunucuda satın alma doğrulaması gerekir.
 */
object Guard {
    // Projedeki sabit debug.keystore imzası (SHA-1)
    private const val BUILT_IN_CERT = "500e46378d184ca4c73d0ada01254651ec39caf5"

    private val cheatPackages = listOf(
        "com.dimonvideo.luckypatcher", "com.chelpus.lackypatch", "com.forpda.lp", "cc.madkite.freedom", "com.android.protips",
        "com.android.vending.billing.InAppBillingService.COIN", "com.android.vending.billing.InAppBillingService.LUCK",
        "com.android.vending.billing.InAppBillingService.CLON", "com.android.vending.billing.InAppBillingService.LOCK",
        "com.android.vending.billing.InAppBillingService.CRAC",
    )

    @Suppress("DEPRECATION")
    private fun certSha1s(ctx: Context): List<String> = runCatching {
        val pm = ctx.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val i = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo
            if (i == null) emptyArray<android.content.pm.Signature>() else if (i.hasMultipleSigners()) i.apkContentsSigners else i.signingCertificateHistory
        } else pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures
        sigs.orEmpty().map { MessageDigest.getInstance("SHA-1").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) } }
    }.getOrDefault(emptyList())

    @Suppress("DEPRECATION")
    private fun installedByPlay(ctx: Context): Boolean = runCatching {
        val n: String? = if (Build.VERSION.SDK_INT >= 30) ctx.packageManager.getInstallSourceInfo(ctx.packageName).installingPackageName
        else ctx.packageManager.getInstallerPackageName(ctx.packageName)
        n == "com.android.vending"
    }.getOrDefault(false)

    /** Yeniden imzalanmış (kırılmış) kopya mı? Play'den kurulduysa veya imza güvenilir listedeyse temiz sayılır. */
    fun signatureTrusted(ctx: Context): Boolean {
        if (installedByPlay(ctx)) return true
        val trusted = (BuildConfig.TRUSTED_CERTS.split(",").map { it.trim().lowercase().replace(":", "") }.filter { it.isNotEmpty() } + BUILT_IN_CERT).toSet()
        return certSha1s(ctx).any { it in trusted }
    }

    private fun installed(ctx: Context, pkg: String) = runCatching {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    }.getOrDefault(false)

    /** Lucky Patcher benzeri araç kurulu mu veya Play faturalandırma servisi başka bir uygulamaya mı yönlendirilmiş? */
    fun cheatToolPresent(ctx: Context): Boolean {
        if (cheatPackages.any { installed(ctx, it) }) return true
        return runCatching {
            val i = Intent("com.android.vending.billing.InAppBillingService.BIND").setPackage(null)
            val owners = ctx.packageManager.queryIntentServices(i, 0).map { it.serviceInfo.packageName }
            owners.any { it != "com.android.vending" && it != "com.google.android.gms" }
        }.getOrDefault(false)
    }

    /** Pro'nun açık kalabilmesi için ortam temiz olmalı. */
    fun environmentClean(ctx: Context) = signatureTrusted(ctx) && !cheatToolPresent(ctx)

    /** Google'ın imzası doğru mu? (Anahtar tanımlı değilse atlanır.) */
    fun purchaseSignatureOk(originalJson: String, signature: String): Boolean {
        val key = BuildConfig.PLAY_LICENSE_KEY
        if (key.isBlank()) return true
        return runCatching {
            val pub = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(Base64.decode(key, Base64.DEFAULT)))
            Signature.getInstance("SHA1withRSA").run {
                initVerify(pub); update(originalJson.toByteArray()); verify(Base64.decode(signature, Base64.DEFAULT))
            }
        }.getOrDefault(false)
    }

    /** Yerel Pro kaydını (bayrak + imza) doğrudan düzenlemeyi zorlaştırır. */
    fun proMac(ctx: Context, purchaseToken: String): String {
        val secret = ("dk|" + ctx.packageName + "|" + android.provider.Settings.Secure.getString(ctx.contentResolver, android.provider.Settings.Secure.ANDROID_ID) + "|k7Qz").toByteArray()
        val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(secret, "HmacSHA256")) }
        return mac.doFinal(("pro|" + purchaseToken).toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
