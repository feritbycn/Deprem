package app.depremkalkani.data

import android.app.backup.BackupAgent
import android.app.backup.BackupDataInput
import android.app.backup.BackupDataOutput
import android.content.Context
import android.content.SharedPreferences
import android.os.ParcelFileDescriptor
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.FileOutputStream

/**
 * Yedek içeriği: yakınlar (ve anahtarları), ad, bölge/bildirim/ses/sesli okuma ayarları.
 * YedeklenMEYEN: konum, mesaj geçmişi, cihaza özel kimlikler, Pro kaydı, izin/sihirbaz durumu, geçici sayaçlar.
 * Android'in kendi yedeği (BackupAgent) tarafından kullanılır; Drive yedeği kaldırıldı.
 */
object Backup {
    private val EXACT = setOf(
        "dev_id", "is_pro", "pro_tok", "pro_sig", "onboarded", "login_asked", "launch_count", "first_launch", "review_at", "review_n",
        "fsi_asked", "batt_asked", "seen_ids", "circle_since", "acked_ids", "circle_events", "mesh_msgs", "felt_notified_ts", "mesh_felt_notified",
        "prov_sent", "prov_sent_ts", "cq_done", "felt_ids", "mesh_on", "acc_name", "acc_email", "drive_granted", "cloud_last", "bag_checked",
    )
    private fun skip(k: String) = k in EXACT || k.startsWith("pa_") || k.startsWith("pd_") || k.startsWith("pda_")

    fun export(sp: SharedPreferences): String {
        val o = JSONObject()
        for ((k, v) in sp.all) {
            if (skip(k) || v == null) continue
            val e = JSONObject()
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                is Set<*> -> e.put("t", "S").put("v", org.json.JSONArray(v.map { it.toString() }))
                else -> continue
            }
            o.put(k, e)
        }
        return JSONObject().put("ver", 1).put("o", Mark.ID).put("ts", System.currentTimeMillis()).put("d", o).toString()
    }

    fun import(sp: SharedPreferences, json: String): Boolean = runCatching {
        val d = JSONObject(json).getJSONObject("d")
        val ed = sp.edit()
        for (k in d.keys()) {
            if (skip(k)) continue
            val e = d.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v")); "i" -> ed.putInt(k, e.getInt("v")); "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat()); "s" -> ed.putString(k, e.getString("v"))
                "S" -> ed.putStringSet(k, e.getJSONArray("v").let { a -> (0 until a.length()).map { a.getString(it) }.toSet() })
            }
        }
        ed.apply(); true
    }.getOrDefault(false)
}

/** Android'in kendi (Google hesabına otomatik) yedeği; yalnızca yukarıdaki seçili veriyi yazar. */
class DkBackupAgent : BackupAgent() {
    override fun onBackup(oldState: ParcelFileDescriptor?, data: BackupDataOutput, newState: ParcelFileDescriptor) {
        val bytes = Backup.export(getSharedPreferences("dk", Context.MODE_PRIVATE)).toByteArray()
        data.writeEntityHeader("dk", bytes.size); data.writeEntityData(bytes, bytes.size)
        DataOutputStream(FileOutputStream(newState.fileDescriptor)).use { it.writeLong(System.currentTimeMillis()) }
    }

    override fun onRestore(data: BackupDataInput, appVersionCode: Int, newState: ParcelFileDescriptor) {
        while (data.readNextHeader()) {
            if (data.key == "dk") {
                val buf = ByteArray(data.dataSize); data.readEntityData(buf, 0, buf.size)
                Backup.import(getSharedPreferences("dk", Context.MODE_PRIVATE), String(buf))
            } else data.skipEntityData()
        }
        DataOutputStream(FileOutputStream(newState.fileDescriptor)).use { it.writeLong(System.currentTimeMillis()) }
    }
}
