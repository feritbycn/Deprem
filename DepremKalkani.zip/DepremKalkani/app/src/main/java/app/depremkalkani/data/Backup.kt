package app.depremkalkani.data

import android.app.backup.BackupAgent
import android.app.backup.BackupDataInput
import android.app.backup.BackupDataOutput
import android.content.Context
import android.content.SharedPreferences
import android.os.ParcelFileDescriptor
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.FileOutputStream

/**
 * Yedek içeriği: yakınlar (ve anahtarları), ad, bölge/bildirim/ses/sesli okuma ayarları.
 * YedeklenMEYEN: konum, mesaj geçmişi, cihaza özel kimlikler, Pro kaydı, izin/sihirbaz durumu, geçici sayaçlar.
 * İki yerde kullanılır: (1) Android'in kendi yedeği (BackupAgent), (2) Google hesabına bağlı Drive uygulama verisi klasörü.
 */
object Backup {
    private val EXACT = setOf(
        "dev_id", "is_pro", "pro_tok", "pro_sig", "onboarded", "login_asked", "launch_count", "first_launch", "review_at", "review_n",
        "fsi_asked", "batt_asked", "seen_ids", "circle_since", "acked_ids", "circle_events", "mesh_msgs", "felt_notified_ts", "mesh_felt_notified",
        "prov_sent", "prov_sent_ts", "cq_done", "felt_ids", "mesh_on", "acc_name", "acc_email", "drive_granted", "cloud_last", "bag_checked",
    )
    private fun skip(k: String) = k in EXACT || k.startsWith("pa_") || k.startsWith("pd_") || k.startsWith("pda_")

    fun export(sp: SharedPreferences): String {
        val o = JSONObject()
        for ((k, v) in sp.all) {
            if (skip(k) || v == null) continue
            val e = JSONObject()
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                is Set<*> -> e.put("t", "S").put("v", org.json.JSONArray(v.map { it.toString() }))
                else -> continue
            }
            o.put(k, e)
        }
        return JSONObject().put("ver", 1).put("ts", System.currentTimeMillis()).put("d", o).toString()
    }

    fun import(sp: SharedPreferences, json: String): Boolean = runCatching {
        val d = JSONObject(json).getJSONObject("d")
        val ed = sp.edit()
        for (k in d.keys()) {
            if (skip(k)) continue
            val e = d.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v")); "i" -> ed.putInt(k, e.getInt("v")); "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat()); "s" -> ed.putString(k, e.getString("v"))
                "S" -> ed.putStringSet(k, e.getJSONArray("v").let { a -> (0 until a.length()).map { a.getString(it) }.toSet() })
            }
        }
        ed.apply(); true
    }.getOrDefault(false)
}

/** Android'in kendi (Google hesabına otomatik) yedeği; yalnızca yukarıdaki seçili veriyi yazar. */
class DkBackupAgent : BackupAgent() {
    override fun onBackup(oldState: ParcelFileDescriptor?, data: BackupDataOutput, newState: ParcelFileDescriptor) {
        val bytes = Backup.export(getSharedPreferences("dk", Context.MODE_PRIVATE)).toByteArray()
        data.writeEntityHeader("dk", bytes.size); data.writeEntityData(bytes, bytes.size)
        DataOutputStream(FileOutputStream(newState.fileDescriptor)).use { it.writeLong(System.currentTimeMillis()) }
    }

    override fun onRestore(data: BackupDataInput, appVersionCode: Int, newState: ParcelFileDescriptor) {
        while (data.readNextHeader()) {
            if (data.key == "dk") {
                val buf = ByteArray(data.dataSize); data.readEntityData(buf, 0, buf.size)
                Backup.import(getSharedPreferences("dk", Context.MODE_PRIVATE), String(buf))
            } else data.skipEntityData()
        }
        DataOutputStream(FileOutputStream(newState.fileDescriptor)).use { it.writeLong(System.currentTimeMillis()) }
    }
}

/** Google hesabına bağlı yedek: Drive'ın yalnızca bu uygulamanın görebildiği gizli "appDataFolder" klasörü. */
object CloudBackup {
    const val SCOPE = "https://www.googleapis.com/auth/drive.appdata"
    private const val NAME = "dk_backup.json"
    class Remote(val id: String, val modified: String)

    suspend fun authorize(ctx: Context): AuthorizationResult =
        Identity.getAuthorizationClient(ctx.applicationContext)
            .authorize(AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()).await()

    /** Daha önce izin verildiyse arayüz göstermeden belirteç alır. */
    suspend fun silentToken(ctx: Context): String? = runCatching {
        val r = authorize(ctx); if (r.hasResolution()) null else r.accessToken
    }.getOrNull()

    private val http get() = Sources.client

    suspend fun find(token: String): Remote? = withContext(Dispatchers.IO) {
        runCatching {
            val url = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&pageSize=1&fields=files(id,modifiedTime)&q=" +
                java.net.URLEncoder.encode("name='$NAME'", "UTF-8")
            http.newCall(Request.Builder().url(url).header("Authorization", "Bearer $token").build()).execute().use { r ->
                if (!r.isSuccessful) return@use null
                val a = JSONObject(r.body!!.string()).getJSONArray("files")
                if (a.length() == 0) null else a.getJSONObject(0).let { Remote(it.getString("id"), it.optString("modifiedTime")) }
            }
        }.getOrNull()
    }

    suspend fun upload(token: String, json: String, existing: Remote?): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val jt = "application/json".toMediaType()
            val req = if (existing != null)
                Request.Builder().url("https://www.googleapis.com/upload/drive/v3/files/${existing.id}?uploadType=media")
                    .patch(json.toRequestBody(jt))
            else {
                val meta = JSONObject().put("name", NAME).put("parents", org.json.JSONArray().put("appDataFolder")).toString()
                val body = MultipartBody.Builder().setType("multipart/related".toMediaType())
                    .addPart(meta.toRequestBody(jt)).addPart(json.toRequestBody(jt)).build()
                Request.Builder().url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart").post(body)
            }
            http.newCall(req.header("Authorization", "Bearer $token").build()).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    suspend fun download(token: String, id: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            http.newCall(Request.Builder().url("https://www.googleapis.com/drive/v3/files/$id?alt=media").header("Authorization", "Bearer $token").build())
                .execute().use { if (it.isSuccessful) it.body?.string() else null }
        }.getOrNull()
    }

    suspend fun backupNow(ctx: Context, token: String, prefs: Prefs): Boolean {
        val ok = upload(token, Backup.export(prefs.sp), find(token))
        if (ok) prefs.cloudLast = System.currentTimeMillis()
        return ok
    }

    /** Yedeği uygular; yakınlar ve tema/servis yeniden yüklenir. */
    suspend fun restore(ctx: Context, token: String, remote: Remote, prefs: Prefs): Boolean {
        val json = download(token, remote.id) ?: return false
        if (!Backup.import(prefs.sp, json)) return false
        withContext(Dispatchers.Main) { Circles.init(ctx, prefs); app.depremkalkani.ui.ThemeState.load(prefs.themeMode) }
        return true
    }

    /** Uygulama arka plana geçerken: giriş yapılmış, izin verilmiş ve otomatik yedek açıksa (en çok 30 dakikada bir). */
    suspend fun autoBackup(ctx: Context, prefs: Prefs) {
        if (prefs.accountEmail.isBlank() || !prefs.driveGranted || !prefs.cloudAuto) return
        if (System.currentTimeMillis() - prefs.cloudLast < 30 * 60_000L) return
        val t = silentToken(ctx) ?: return
        backupNow(ctx, t, prefs)
    }
}
