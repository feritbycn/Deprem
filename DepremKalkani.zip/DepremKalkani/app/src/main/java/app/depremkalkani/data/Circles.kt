package app.depremkalkani.data

import android.content.Context
import android.util.Base64
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.PendingIntent
import android.content.Intent
import app.depremkalkani.R
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.service.CircleActionReceiver
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

enum class CType(val label: String) {
    HELLO("Bağlandı"), CHECK("Güvende misin?"), SAFE("Güvendeyim"), HELP("Yardım lazım"), SOS("ENKAZ ALTINDAYIM"), TEXT("Mesaj")
}

data class Member(
    val id: String, val name: String, val secret: String, val phone: String = "",
    val status: CType? = null, val statusTs: Long = 0, val lat: Double? = null, val lon: Double? = null,
    val connected: Boolean = false, val lastAsked: Long = 0,
)

data class CEvent(val id: String, val memberId: String, val name: String, val type: CType, val text: String, val ts: Long, val mine: Boolean)

/**
 * YAKINLARIM: aile/tanıdık çevresi.
 * - Eşleşme: davet kodu (içinde ortak gizli anahtar). Kodu mesajla gönder, karşı taraf "Kodla ekle" der.
 * - Mesajlar AES-256-GCM ile şifrelenir; yalnızca anahtarı bilen iki telefon okuyabilir.
 * - Teslimat yolları: (1) internet: açık kaynak "ntfy" aktarma sunucusu (varsayılan ntfy.sh, ayarlardan değiştirilebilir),
 *   (2) internetsiz: yakındaki Deprem Kalkanı telefonları üzerinden zincirleme aktarım (Mesh),
 *   (3) SMS (kullanıcı gönder'e basar).
 * Alıcı tarafta uygulamanın canlı takip servisi çalışıyor olmalıdır.
 */
object Circles {
    private val B64 = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    private lateinit var ctx: Context
    private lateinit var prefs: Prefs
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val stream = Sources.client.newBuilder().readTimeout(0, TimeUnit.MILLISECONDS).callTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(30, TimeUnit.SECONDS).build()
    @Volatile private var activeCall: Call? = null

    val members = MutableStateFlow<List<Member>>(emptyList())
    val events = MutableStateFlow<List<CEvent>>(emptyList())
    private val pending = ArrayList<Pair<Member, String>>()
    private val recent = ArrayList<Pair<Long, String>>()  // son 6 saatte gönderilen şifreli mesajlar (Mesh yeniden iletim)

    fun init(c: Context, p: Prefs) {
        ctx = c.applicationContext; prefs = p
        runCatching {
            val a = JSONArray(p.sp.getString("circle_members", "[]"))
            members.value = (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                Member(o.getString("id"), o.getString("n"), o.getString("s"), o.optString("ph"),
                    o.optString("st").takeIf { it.isNotBlank() }?.let { s -> runCatching { CType.valueOf(s) }.getOrNull() },
                    o.optLong("ts"), if (o.has("la")) o.getDouble("la") else null, if (o.has("lo")) o.getDouble("lo") else null,
                    o.optBoolean("c"), o.optLong("ask"))
            } }
        }
        runCatching {
            val a = JSONArray(p.sp.getString("circle_events", "[]"))
            events.value = (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                CEvent(o.getString("id"), o.getString("m"), o.getString("n"), CType.valueOf(o.getString("t")), o.optString("x"), o.getLong("ts"), o.optBoolean("me"))
            } }
        }
    }

    private fun saveMembers() {
        val a = JSONArray()
        members.value.forEach { m -> a.put(JSONObject().apply {
            put("id", m.id); put("n", m.name); put("s", m.secret); put("ph", m.phone); put("st", m.status?.name ?: "")
            put("ts", m.statusTs); if (m.lat != null && m.lon != null) { put("la", m.lat); put("lo", m.lon) }
            put("c", m.connected); put("ask", m.lastAsked)
        }) }
        prefs.sp.edit().putString("circle_members", a.toString()).apply()
    }

    private fun saveEvents() {
        val a = JSONArray()
        events.value.forEach { e -> a.put(JSONObject().put("id", e.id).put("m", e.memberId).put("n", e.name).put("t", e.type.name).put("x", e.text).put("ts", e.ts).put("me", e.mine)) }
        prefs.sp.edit().putString("circle_events", a.toString()).apply()
    }

    private fun update(id: String, f: (Member) -> Member) {
        members.value = members.value.map { if (it.id == id) f(it) else it }; saveMembers()
    }

    private fun addEvent(e: CEvent) {
        events.value = (events.value + e).sortedBy { it.ts }.takeLast(150); saveEvents()
    }

    // ------------------------------------------------------------------ eşleşme
    private fun newSecret(): String = Base64.encodeToString(ByteArray(32).also { SecureRandom().nextBytes(it) }, B64)

    /** Yeni bir kişi için davet kodu üretir ve listeye "bekliyor" olarak ekler. */
    fun createInvite(label: String): Pair<Member, String> {
        val me = prefs.nick.ifBlank { "Anonim" }
        val m = Member(UUID.randomUUID().toString().take(8), label.ifBlank { "Davet bekliyor" }, newSecret())
        members.value = members.value + m; saveMembers()
        return m to inviteCode(m, me)
    }

    fun inviteCode(m: Member, myName: String = prefs.nick.ifBlank { "Anonim" }) =
        "DK1." + m.secret + "." + URLEncoder.encode(myName, "UTF-8")

    /** Karşı tarafın kodunu girince çağrılır. Başarı: null, hata: mesaj. */
    suspend fun acceptInvite(code: String, label: String = ""): String? {
        val p = code.trim().split('.', limit = 3)
        if (p.size < 3 || p[0] != "DK1") return "Kod geçersiz."
        val secret = p[1]
        if (runCatching { Base64.decode(secret, B64).size }.getOrDefault(0) != 32) return "Kod geçersiz."
        if (members.value.any { it.secret == secret }) return "Bu kişi zaten ekli."
        val name = label.trim().ifBlank { runCatching { URLDecoder.decode(p[2], "UTF-8") }.getOrDefault("Yakınım") }
        val m = Member(UUID.randomUUID().toString().take(8), name, secret, connected = true)
        members.value = members.value + m; saveMembers()
        sendTo(m, CType.HELLO, "")
        return null
    }

    fun rename(id: String, name: String, phone: String) = update(id) { it.copy(name = name.ifBlank { it.name }, phone = phone.trim()) }

    fun remove(id: String) { members.value = members.value.filter { it.id != id }; saveMembers() }

    // ------------------------------------------------------------------ gönderim
    private fun key(secret: String) = SecretKeySpec(Base64.decode(secret, B64), "AES")

    private fun topic(m: Member): String {
        val h = MessageDigest.getInstance("SHA-256").digest(Base64.decode(m.secret, B64))
        return "dk" + h.take(16).joinToString("") { "%02x".format(it) }
    }

    private fun encrypt(secret: String, plain: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key(secret), GCMParameterSpec(128, iv))
        return Base64.encodeToString(iv + c.doFinal(plain.toByteArray()), B64)
    }

    private fun decrypt(secret: String, cipher: String): String? = runCatching {
        val raw = Base64.decode(cipher.trim(), B64)
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key(secret), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        String(c.doFinal(raw, 12, raw.size - 12))
    }.getOrNull()

    private fun server() = prefs.sp.getString("circle_server", "https://ntfy.sh")!!.trim().trimEnd('/')

    private fun publish(m: Member, cipher: String): Boolean = runCatching {
        val req = Request.Builder().url("${server()}/${topic(m)}")
            .post(cipher.toRequestBody("text/plain".toMediaType())).header("User-Agent", "DepremKalkani/1.0").build()
        Sources.client.newCall(req).execute().use { it.isSuccessful }
    }.getOrDefault(false)

    /** Tek kişiye gönder; ağ yoksa kuyruğa alır, yakın cihaz ağına da (açıksa) bırakır. */
    suspend fun sendTo(m: Member, type: CType, text: String) {
        if (type == CType.SAFE || type == CType.HELP || type == CType.SOS || type == CType.CHECK) runCatching { LocationHelper.refresh(ctx) }
        val msg = JSONObject().apply {
            put("id", UUID.randomUUID().toString()); put("ty", type.name); put("f", Mesh.myId)
            put("n", prefs.nick.ifBlank { "Anonim" }); put("tx", text); put("ts", System.currentTimeMillis())
            if (type != CType.HELLO && type != CType.TEXT && Geo.known) { put("la", Geo.lat!!); put("lo", Geo.lon!!) }
        }
        val cipher = encrypt(m.secret, msg.toString())
        withContext(Dispatchers.Main) {
            addEvent(CEvent(msg.getString("id"), m.id, m.name, type, text, msg.getLong("ts"), true))
            if (type == CType.CHECK) update(m.id) { it.copy(lastAsked = System.currentTimeMillis()) }
        }
        synchronized(recent) { recent += System.currentTimeMillis() to cipher; recent.removeAll { it.first < System.currentTimeMillis() - 6 * 3600_000L } }
        if (Mesh.running.value) Mesh.sendCircle(cipher)
        if (!publish(m, cipher)) synchronized(pending) { pending += m to cipher }
    }

    fun send(m: Member, type: CType, text: String = "") { scope.launch { sendTo(m, type, text) } }

    fun sendAll(type: CType, text: String = "") { members.value.forEach { send(it, type, text) } }

    fun recentCiphers(): List<String> = synchronized(recent) { recent.map { it.second } }

    private fun flushPending() {
        val list = synchronized(pending) { pending.toList().also { pending.clear() } }
        list.forEach { (m, c) -> if (!publish(m, c)) synchronized(pending) { pending += m to c } }
    }

    // ------------------------------------------------------------------ alım
    /** Mesh veya ntfy'den gelen şifreli metin. */
    fun onCipher(cipher: String, topicHint: String? = null) {
        for (m in members.value) {
            if (topicHint != null && topic(m) != topicHint) continue
            val plain = decrypt(m.secret, cipher) ?: continue
            val o = runCatching { JSONObject(plain) }.getOrNull() ?: return
            if (o.optString("f") == Mesh.myId) return
            val id = o.optString("id")
            if (events.value.any { it.id == id }) return
            handle(m, o); return
        }
    }

    private fun handle(m: Member, o: JSONObject) {
        val type = runCatching { CType.valueOf(o.getString("ty")) }.getOrNull() ?: return
        val nick = o.optString("n").ifBlank { m.name }
        val ts = o.optLong("ts", System.currentTimeMillis())
        val name = if (m.name == "Davet bekliyor" || m.name.isBlank()) nick else m.name
        val lat = if (o.has("la")) o.getDouble("la") else null
        val lon = if (o.has("lo")) o.getDouble("lo") else null
        scopeMain {
            update(m.id) {
                var u = it.copy(name = name, connected = true)
                if (type == CType.SAFE || type == CType.HELP || type == CType.SOS) u = u.copy(status = type, statusTs = ts, lat = lat ?: u.lat, lon = lon ?: u.lon)
                u
            }
            addEvent(CEvent(o.getString("id"), m.id, name, type, o.optString("tx"), ts, false))
        }
        notifyEvent(m.id, name, type, o.optString("tx"), lat, lon)
    }

    private fun scopeMain(f: () -> Unit) { CoroutineScope(Dispatchers.Main).launch { f() } }

    private fun actionIntent(memberId: String, type: CType, req: Int): PendingIntent =
        PendingIntent.getBroadcast(ctx, req, Intent(ctx, CircleActionReceiver::class.java)
            .putExtra("member", memberId).putExtra("type", type.name), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun safeActionIntent(): PendingIntent = actionIntent("all", CType.SAFE, 9001)

    private fun notifyEvent(memberId: String, name: String, type: CType, text: String, lat: Double?, lon: Double?) {
        if (!Notifs.canPost(ctx)) return
        val d = if (lat != null && lon != null) Geo.distanceFromMe(lat, lon) else null
        val (title, body) = when (type) {
            CType.CHECK -> "$name: Güvende misin?" to "Yakının durumunu soruyor. Tek dokunuşla cevap ver."
            CType.SAFE -> "$name güvende ✓" to (text.ifBlank { "Güvendeyim" })
            CType.HELP -> "$name yardım istiyor!" to text.ifBlank { "Yardım lazım" }
            CType.SOS -> "$name ENKAZ ALTINDA!" to text.ifBlank { "Enkaz altındayım, yardım edin!" }
            CType.HELLO -> "$name bağlandı" to "Artık birbirinizin durumunu görebilirsiniz."
            CType.TEXT -> name to text
        }
        val b = NotificationCompat.Builder(ctx, Notifs.CH_CIRCLE)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title)
            .setContentText(body + (d?.let { " • ~${fmtKm(it)} uzakta" } ?: ""))
            .setStyle(NotificationCompat.BigTextStyle().bigText(body + (d?.let { " • ~${fmtKm(it)} uzakta" } ?: "")))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true)
            .setContentIntent(Notifs.openAppIntent(ctx))
        if (type == CType.CHECK) {
            b.addAction(0, "Güvendeyim", actionIntent(memberId, CType.SAFE, memberId.hashCode()))
            b.addAction(0, "Yardım lazım", actionIntent(memberId, CType.HELP, memberId.hashCode() + 1))
        }
        runCatching { NotificationManagerCompat.from(ctx).notify(("c$memberId$type").hashCode(), b.build()) }
    }

    private fun fmtKm(km: Double) = if (km < 1) "${(km * 1000).toInt()} m" else "${km.toInt()} km"

    // ------------------------------------------------------------- internet dinleme
    fun stop() { activeCall?.cancel() }

    suspend fun subscribeLoop() {
        var backoff = 2000L
        while (currentCoroutineContext().isActive) {
            val ms = members.value
            if (ms.isEmpty()) { delay(5000); continue }
            val since = prefs.sp.getLong("circle_since", System.currentTimeMillis() / 1000 - 6 * 3600)
            val url = "${server()}/${ms.joinToString(",") { topic(it) }}/json?since=$since"
            val call = stream.newCall(Request.Builder().url(url).header("User-Agent", "DepremKalkani/1.0").build())
            activeCall = call
            coroutineScope {
                val watcher = launch { members.drop(1).first(); call.cancel() } // kişi listesi değişirse yeniden bağlan
                runCatching {
                    withContext(Dispatchers.IO) {
                        call.execute().use { r ->
                            if (!r.isSuccessful) error("HTTP ${r.code}")
                            backoff = 2000L
                            flushPending()
                            val src = r.body!!.source()
                            while (!src.exhausted()) {
                                val line = src.readUtf8Line() ?: break
                                runCatching {
                                    val o = JSONObject(line)
                                    if (o.optString("event") == "message") {
                                        prefs.sp.edit().putLong("circle_since", o.getLong("time") + 1).apply()
                                        onCipher(o.getString("message"), o.optString("topic"))
                                    }
                                }
                            }
                        }
                    }
                }
                watcher.cancel()
            }
            if (!currentCoroutineContext().isActive) break
            delay(backoff); backoff = minOf(backoff * 2, 60_000L)
        }
    }
}
