package app.depremkalkani.data

import android.content.Context
import android.util.Base64
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.PendingIntent
import android.content.Intent
import app.depremkalkani.R
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.service.CircleActionReceiver
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

enum class CType(val label: String) {
    HELLO("Bağlandı"), READ("Görüldü"), CHECK("Güvende misin?"), SAFE("Güvendeyim"), HELP("Yardım lazım"), SOS("ENKAZ ALTINDAYIM"), TEXT("Mesaj"),
    LOCREQ("İl isteği"), LOCOK("İl paylaşıldı"), LOCOFF("İl paylaşımı kapalı")
}

data class Member(
    val id: String, val name: String, val secret: String, val phone: String = "",
    val status: CType? = null, val statusTs: Long = 0, val lat: Double? = null, val lon: Double? = null,
    val connected: Boolean = false, val lastAsked: Long = 0, val dev: String = "",
    val theirProv: String = "",      // yakının bana paylaştığı il
    val manualProv: String = "",     // benim elle yazdığım il
    val shareWith: Boolean = false,  // ben ilimi bu kişiyle paylaşıyorum
    val incomingReq: Boolean = false, // kişi ilimi görmek istiyor, cevap bekliyor
    val reqSent: Boolean = false,    // ben ona il isteği gönderdim
    val noAuto: Boolean = false,     // "Kaldır" dedim: otomatik onay uygulanmasın
    val group: Boolean = false,      // grup: aynı kodla katılan herkes aynı kanalı paylaşır
    val owner: Boolean = false,      // grubu ben kurdum (kodu yenileyebilirim)
    val limit: Int = 0,              // grup için beklenen en çok kişi (yumuşak sınır, 0 = yok)
) {
    val prov: String get() = theirProv.ifBlank { manualProv }
}

data class CEvent(val id: String, val memberId: String, val name: String, val type: CType, val text: String, val ts: Long, val mine: Boolean)

/**
 * YAKINLARIM: aile/tanıdık çevresi.
 * - Eşleşme: davet kodu (içinde ortak gizli anahtar). Kodu mesajla gönder, karşı taraf "Kodla ekle" der.
 * - Mesajlar AES-256-GCM ile şifrelenir; yalnızca anahtarı bilen iki telefon okuyabilir.
 * - Teslimat yolları: (1) internet: açık kaynak "ntfy" aktarma sunucusu (varsayılan ntfy.sh, ayarlardan değiştirilebilir),
 *   (2) internetsiz: yakındaki Deprem Kalkanı telefonları üzerinden zincirleme aktarım (Mesh),
 *   (3) SMS (kullanıcı gönder'e basar).
 * Alıcı tarafta uygulamanın canlı takip servisi çalışıyor olmalıdır.
 */
object Circles {
    private val B64 = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    private lateinit var ctx: Context
    private lateinit var prefs: Prefs
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val stream = Sources.client.newBuilder().readTimeout(0, TimeUnit.MILLISECONDS).callTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(30, TimeUnit.SECONDS).build()
    @Volatile private var activeCall: Call? = null

    val members = MutableStateFlow<List<Member>>(emptyList())
    val events = MutableStateFlow<List<CEvent>>(emptyList())
    /** mesaj kimliği -> görenlerin adları ("Görüldü" bilgisi) */
    val reads = MutableStateFlow<Map<String, Set<String>>>(emptyMap())
    /** İletilemeyip sıraya alınan (internet/yakın cihaz bekleyen) mesaj kimlikleri */
    val queued = MutableStateFlow<Set<String>>(emptySet())
    private val queuedCipher = HashMap<String, String>()
    private val acked = HashSet<String>()
    private val pending = ArrayList<Pair<Member, String>>()
    private val recent = ArrayList<Pair<Long, String>>()  // son 6 saatte gönderilen şifreli mesajlar (Mesh yeniden iletim)

    fun init(c: Context, p: Prefs) {
        ctx = c.applicationContext; prefs = p
        acked += p.sp.getStringSet("acked_ids", emptySet()) ?: emptySet()
        runCatching {
            val a = JSONArray(p.sp.getString("circle_members", "[]"))
            members.value = (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                Member(o.getString("id"), o.getString("n"), o.getString("s"), o.optString("ph"),
                    o.optString("st").takeIf { it.isNotBlank() }?.let { s -> runCatching { CType.valueOf(s) }.getOrNull() },
                    o.optLong("ts"), if (o.has("la")) o.getDouble("la") else null, if (o.has("lo")) o.getDouble("lo") else null,
                    o.optBoolean("c"), o.optLong("ask"), o.optString("dv"),
                    o.optString("tp"), o.optString("mp"), o.optBoolean("sw"), o.optBoolean("ir"), o.optBoolean("rs"), o.optBoolean("na"), o.optBoolean("g"), o.optBoolean("ow"), o.optInt("gl"))
            } }
        }
        runCatching {
            val a = JSONArray(p.sp.getString("circle_events", "[]"))
            events.value = (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                CEvent(o.getString("id"), o.getString("m"), o.getString("n"), CType.valueOf(o.getString("t")), o.optString("x"), o.getLong("ts"), o.optBoolean("me"))
            } }
        }
    }

    private fun saveMembers() {
        val a = JSONArray()
        members.value.forEach { m -> a.put(JSONObject().apply {
            put("id", m.id); put("n", m.name); put("s", m.secret); put("ph", m.phone); put("st", m.status?.name ?: "")
            put("ts", m.statusTs); if (m.lat != null && m.lon != null) { put("la", m.lat); put("lo", m.lon) }
            put("c", m.connected); put("ask", m.lastAsked); put("dv", m.dev)
            put("tp", m.theirProv); put("mp", m.manualProv); put("sw", m.shareWith); put("ir", m.incomingReq); put("rs", m.reqSent); put("na", m.noAuto); put("g", m.group); put("ow", m.owner); put("gl", m.limit)
        }) }
        prefs.sp.edit().putString("circle_members", a.toString()).apply()
    }

    private fun saveEvents() {
        val a = JSONArray()
        events.value.forEach { e -> a.put(JSONObject().put("id", e.id).put("m", e.memberId).put("n", e.name).put("t", e.type.name).put("x", e.text).put("ts", e.ts).put("me", e.mine)) }
        prefs.sp.edit().putString("circle_events", a.toString()).apply()
    }

    private fun update(id: String, f: (Member) -> Member) {
        members.value = members.value.map { if (it.id == id) f(it) else it }; saveMembers()
    }

    private fun addEvent(e: CEvent) {
        events.value = (events.value + e).sortedBy { it.ts }.takeLast(150); saveEvents()
    }

    // ------------------------------------------------------------------ eşleşme
    private fun newSecret(): String = Base64.encodeToString(ByteArray(32).also { SecureRandom().nextBytes(it) }, B64)

    /** Yeni bir kişi için davet kodu üretir ve listeye "bekliyor" olarak ekler. */
    fun createInvite(label: String): Pair<Member, String> {
        val me = prefs.nick.ifBlank { "Anonim" }
        val m = Member(UUID.randomUUID().toString().take(8), label.ifBlank { "Davet bekliyor" }, newSecret())
        members.value = members.value + m; saveMembers()
        return m to inviteCode(m, me)
    }

    fun inviteCode(m: Member, myName: String = prefs.nick.ifBlank { "Anonim" }) =
        "DK1." + m.secret + "." + URLEncoder.encode(myName, "UTF-8")

    /** Grup kurar: kodu alan herkes aynı şifreli kanala katılır ve aynı mesajları görür. */
    fun createGroup(name: String, limit: Int = 0): Pair<Member, String> {
        val g = Member(UUID.randomUUID().toString().take(8), name.ifBlank { "Grubum" }, newSecret(), connected = true, group = true, owner = true, limit = limit)
        members.value = members.value + g; saveMembers()
        return g to groupCode(g)
    }

    fun groupCode(m: Member) = "DKG1." + m.secret + "." + URLEncoder.encode(m.name, "UTF-8")

    /** Yönetici: yeni anahtar üretir. Eski kodla giren (ör. çıkardığın kişi) yeni kanalı okuyamaz; kalmasını istediklerine yeni kodu gönder. */
    fun renewGroup(id: String): String? {
        val g = members.value.firstOrNull { it.id == id && it.group && it.owner } ?: return null
        val s = newSecret()
        update(id) { it.copy(secret = s) }
        return groupCode(g.copy(secret = s))
    }

    /** Karşı tarafın kodunu girince çağrılır. Başarı: null, hata: mesaj. */
    suspend fun acceptInvite(code: String, label: String = "", phone: String = ""): String? {
        val p = code.trim().split('.', limit = 3)
        if (p.size < 3 || (p[0] != "DK1" && p[0] != "DKG1")) return "Kod geçersiz."
        val isGroup = p[0] == "DKG1"
        val secret = p[1]
        if (runCatching { Base64.decode(secret, B64).size }.getOrDefault(0) != 32) return "Kod geçersiz."
        if (members.value.any { it.secret == secret }) return "Bu kişi zaten ekli."
        val name = label.trim().ifBlank { runCatching { URLDecoder.decode(p[2], "UTF-8") }.getOrDefault("Yakınım") }
        val m = Member(UUID.randomUUID().toString().take(8), name, secret, phone = if (isGroup) "" else phone.trim(), connected = true, group = isGroup)
        members.value = members.value + m; saveMembers()
        sendTo(m, CType.HELLO, "")
        if (!isGroup) requestProvince(m.id)
        return null
    }

    fun rename(id: String, name: String, phone: String) = update(id) { it.copy(name = name.ifBlank { it.name }, phone = phone.trim()) }

    fun remove(id: String) { members.value = members.value.filter { it.id != id }; saveMembers() }

    // ------------------------------------------------------------------ gönderim
    private fun key(secret: String) = SecretKeySpec(Base64.decode(secret, B64), "AES")

    private fun topic(m: Member): String {
        val h = MessageDigest.getInstance("SHA-256").digest(Base64.decode(m.secret, B64))
        return "dk" + h.take(16).joinToString("") { "%02x".format(it) }
    }

    private fun encrypt(secret: String, plain: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key(secret), GCMParameterSpec(128, iv))
        return Base64.encodeToString(iv + c.doFinal(plain.toByteArray()), B64)
    }

    private fun decrypt(secret: String, cipher: String): String? = runCatching {
        val raw = Base64.decode(cipher.trim(), B64)
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, key(secret), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        String(c.doFinal(raw, 12, raw.size - 12))
    }.getOrNull()

    private fun server() = prefs.sp.getString("circle_server", "https://ntfy.sh")!!.trim().trimEnd('/')

    private fun publish(m: Member, cipher: String): Boolean = runCatching {
        val req = Request.Builder().url("${server()}/${topic(m)}")
            .post(cipher.toRequestBody("text/plain".toMediaType())).header("User-Agent", "DepremKalkani/1.0").build()
        Sources.client.newCall(req).execute().use { it.isSuccessful }
    }.getOrDefault(false)

    /** Tek kişiye gönder; ağ yoksa kuyruğa alır, yakın cihaz ağına da (açıksa) bırakır. */
    suspend fun sendTo(m: Member, type: CType, text: String) {
        if (type == CType.SAFE || type == CType.HELP || type == CType.SOS || type == CType.CHECK) runCatching { LocationHelper.refresh(ctx) }
        val msg = JSONObject().apply {
            put("id", UUID.randomUUID().toString()); put("ty", type.name); put("f", Mesh.myId)
            put("n", prefs.nick.ifBlank { "Anonim" }); put("tx", text); put("ts", System.currentTimeMillis())
            // Grupta konum yalnızca yardım/SOS çağrısında gider
            if (type != CType.HELLO && !isLoc(type) && Geo.known && (!m.group || type == CType.HELP || type == CType.SOS)) { put("la", Geo.lat!!); put("lo", Geo.lon!!) }
        }
        val cipher = encrypt(m.secret, msg.toString())
        withContext(Dispatchers.Main) {
            if (type != CType.READ && !isLoc(type)) addEvent(CEvent(msg.getString("id"), m.id, m.name, type, text, msg.getLong("ts"), true))
            if (type == CType.CHECK) update(m.id) { it.copy(lastAsked = System.currentTimeMillis()) }
        }
        synchronized(recent) { recent += System.currentTimeMillis() to cipher; recent.removeAll { it.first < System.currentTimeMillis() - 6 * 3600_000L } }
        // 1) internet varsa hemen ntfy üzerinden
        val ok = isOnline() && publish(m, cipher)
        // 2) yakın cihaz ağı açıksa (karşı taraf yakındaysa) Bluetooth ile de bırak; çift gelenler kimlikle elenir
        if (!ok && !Mesh.running.value && app.depremkalkani.ui.Perms.hasNearby(ctx)) runCatching { Mesh.start() }
        if (Mesh.running.value) Mesh.sendCircle(cipher)
        if (!ok) {
            synchronized(pending) { pending += m to cipher }   // internet gelince otomatik gider
            if (type != CType.READ && !isLoc(type) && Mesh.connectedCount == 0) { queuedCipher[cipher] = msg.getString("id"); queued.value = queued.value + msg.getString("id") }
            // 3) internet de Bluetooth bağlantısı da yoksa son çare SMS
            if (type != CType.READ && !isLoc(type) && Mesh.connectedCount == 0) smsFallback(m, type, text)
        }
    }

    private fun isLoc(t: CType) = t == CType.LOCREQ || t == CType.LOCOK || t == CType.LOCOFF

    private fun isOnline(): Boolean = runCatching {
        val cm = ctx.getSystemService(android.net.ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }.getOrDefault(true)

    private fun smsFallback(m: Member, type: CType, text: String) {
        if (m.phone.isBlank() || !prefs.isPro) return
        if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.SEND_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        runCatching {
            @Suppress("DEPRECATION")
            val sm = if (android.os.Build.VERSION.SDK_INT >= 31) ctx.getSystemService(android.telephony.SmsManager::class.java) else android.telephony.SmsManager.getDefault()
            val body = "Deprem Kalkanı • ${prefs.nick.ifBlank { "Anonim" }}: " +
                (if (type == CType.TEXT) text else type.label + (if (text.isNotBlank() && text != type.label) " - $text" else "")) +
                (if (Geo.known) " https://maps.google.com/?q=${"%.5f".format(java.util.Locale.US, Geo.lat!!)},${"%.5f".format(java.util.Locale.US, Geo.lon!!)}" else "")
            sm.sendMultipartTextMessage(m.phone.trim(), null, sm.divideMessage(body), null, null)
        }
    }

    /** Ekranda görülen gelen yakın mesajları için karşıya "görüldü" bilgisi gönderir. */
    fun markSeen() {
        val todo = events.value.filter { !it.mine && it.id !in acked && it.type != CType.HELLO && it.type != CType.READ }
        if (todo.isEmpty()) return
        todo.forEach { e ->
            acked += e.id
            members.value.firstOrNull { it.id == e.memberId && !it.group }?.let { send(it, CType.READ, e.id) }
        }
        prefs.sp.edit().putStringSet("acked_ids", HashSet(acked.toList().takeLast(300))).apply()
    }

    /** Akış kopsa/gecikse bile uygulama açıkken yeni mesajları hemen çek. */
    suspend fun pollNow() = withContext(Dispatchers.IO) {
        val ms = members.value
        if (ms.isEmpty()) return@withContext
        if (synchronized(pending) { pending.isNotEmpty() } && isOnline()) flushPending()   // internet geldiyse sıradakileri hemen yolla
        val since = prefs.sp.getLong("circle_since", System.currentTimeMillis() / 1000 - 6 * 3600)
        val url = "${server()}/${ms.joinToString(",") { topic(it) }}/json?poll=1&since=$since"
        runCatching {
            Sources.client.newCall(Request.Builder().url(url).header("User-Agent", "DepremKalkani/1.0").build()).execute().use { r ->
                if (r.isSuccessful) {
                    r.body?.string()?.lineSequence()?.forEach { line ->
                        runCatching {
                            val o = JSONObject(line)
                            if (o.optString("event") == "message") {
                                prefs.sp.edit().putLong("circle_since", o.getLong("time") + 1).apply()
                                onCipher(o.getString("message"), o.optString("topic"))
                            }
                        }
                    }
                }
            }
        }
        Unit
    }

    fun send(m: Member, type: CType, text: String = "") { scope.launch { sendTo(m, type, text) } }

    fun sendAll(type: CType, text: String = "") { members.value.forEach { send(it, type, text) } }

    fun recentCiphers(): List<String> = synchronized(recent) { recent.map { it.second } }

    private fun flushPending() {
        val list = synchronized(pending) { pending.toList().also { pending.clear() } }
        list.forEach { (m, c) ->
            if (publish(m, c)) queuedCipher.remove(c)?.let { id -> queued.value = queued.value - id }
            else synchronized(pending) { pending += m to c }
        }
    }

    // ------------------------------------------------------------------ alım
    /** Mesh veya ntfy'den gelen şifreli metin. */
    fun onCipher(cipher: String, topicHint: String? = null) {
        for (m in members.value) {
            if (topicHint != null && topic(m) != topicHint) continue
            val plain = decrypt(m.secret, cipher) ?: continue
            val o = runCatching { JSONObject(plain) }.getOrNull() ?: return
            if (o.optString("f") == Mesh.myId) return
            val id = o.optString("id")
            if (events.value.any { it.id == id }) return
            handle(m, o); return
        }
    }

    private fun handle(m: Member, o: JSONObject) {
        val type = runCatching { CType.valueOf(o.getString("ty")) }.getOrNull() ?: return
        if (type == CType.READ) {   // karşı taraf mesajı gördü: sessizce say
            val key = o.optString("tx")
            reads.value = reads.value + (key to ((reads.value[key] ?: emptySet()) + m.name))
            return
        }
        if (m.group) {
            if (isLoc(type)) return
            val gn = o.optString("n").ifBlank { "Biri" }
            val gts = o.optLong("ts", System.currentTimeMillis())
            val glat = if (o.has("la")) o.getDouble("la") else null
            val glon = if (o.has("lo")) o.getDouble("lo") else null
            scopeMain {
                update(m.id) { it.copy(connected = true) }
                addEvent(CEvent(o.getString("id"), m.id, gn, type, o.optString("tx"), gts, false))
            }
            notifyEvent(m.id, gn + " (" + m.name + ")", type, o.optString("tx"), glat, glon)
            return
        }
        if (isLoc(type)) { handleLoc(m, type, o.optString("tx"), o.optString("f")); return }
        val nick = o.optString("n").ifBlank { m.name }
        val ts = o.optLong("ts", System.currentTimeMillis())
        val name = if (m.name == "Davet bekliyor" || m.name.isBlank()) nick else m.name
        val lat = if (o.has("la")) o.getDouble("la") else null
        val lon = if (o.has("lo")) o.getDouble("lo") else null
        scopeMain {
            update(m.id) {
                var u = it.copy(name = name, connected = true)
                val devId = o.optString("f"); if (devId.isNotBlank()) u = u.copy(dev = devId)
                if (type == CType.SAFE || type == CType.HELP || type == CType.SOS) u = u.copy(status = type, statusTs = ts, lat = lat ?: u.lat, lon = lon ?: u.lon)
                else if (lat != null && lon != null) u = u.copy(lat = lat, lon = lon)
                u
            }
            addEvent(CEvent(o.getString("id"), m.id, name, type, o.optString("tx"), ts, false))
        }
        notifyEvent(m.id, name, type, o.optString("tx"), lat, lon)
        if (type == CType.HELLO && !m.reqSent) requestProvince(m.id)
    }

    // ------------------------------------------------------------------ il paylaşımı (konum değil, yalnızca il adı)
    fun myProvince(): String? = if (Geo.known) CrowdFelt.provinceOf(Geo.lat!!, Geo.lon!!) else null

    /** Yakın eklenince karşıya otomatik "ilini görmek istiyorum" isteği gider; karşı taraf onaylarsa il gelir. */
    fun requestProvince(id: String) {
        val m = members.value.firstOrNull { it.id == id } ?: return
        if (m.reqSent) return
        scopeMain { update(id) { it.copy(reqSent = true) } }
        send(m, CType.LOCREQ, "")
    }

    private fun sendProvince(m: Member) { send(m, CType.LOCOK, myProvince() ?: "") }

    /** Bu kişiyle ilimi paylaş / paylaşma. */
    fun setShare(id: String, on: Boolean) {
        val m = members.value.firstOrNull { it.id == id } ?: return
        update(id) { it.copy(shareWith = on, incomingReq = false, noAuto = if (on) false else it.noAuto) }
        if (on) sendProvince(m) else send(m, CType.LOCOFF, "")
    }

    /** Kişiyi izleyenlerden çıkar: paylaşım biter ve yeni isteklere otomatik onay uygulanmaz. */
    fun removeWatcher(id: String) {
        val m = members.value.firstOrNull { it.id == id } ?: return
        update(id) { it.copy(shareWith = false, incomingReq = false, noAuto = true) }
        send(m, CType.LOCOFF, "")
    }

    fun declineRequest(id: String) = update(id) { it.copy(incomingReq = false) }

    fun shareNone() {
        prefs.shareProvAuto = false
        members.value.filter { it.shareWith || it.incomingReq }.forEach { removeWatcher(it.id) }
    }

    fun approveAllPending() { members.value.filter { it.incomingReq && !it.noAuto }.forEach { setShare(it.id, true) } }

    fun setManualProv(id: String, prov: String) = update(id) { it.copy(manualProv = prov) }

    private fun handleLoc(m: Member, type: CType, text: String, dev: String) {
        when (type) {
            CType.LOCREQ -> scopeMain {
                if (m.noAuto) return@scopeMain
                if (prefs.shareProvAuto) setShare(m.id, true)
                else {
                    update(m.id) { it.copy(incomingReq = true, dev = dev.ifBlank { it.dev }, connected = true) }
                    notifyProvRequest(m)
                }
            }
            CType.LOCOK -> scopeMain { update(m.id) { it.copy(theirProv = text, connected = true) } }
            CType.LOCOFF -> scopeMain { update(m.id) { it.copy(theirProv = "") } }
            else -> {}
        }
    }

    private fun notifyProvRequest(m: Member) {
        if (!Notifs.canPost(ctx)) return
        val b = NotificationCompat.Builder(ctx, Notifs.CH_CIRCLE)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle("${m.name} ilini görmek istiyor")
            .setContentText("Yakınlarım ekranından paylaşıp paylaşmayacağına sen karar ver. Yalnızca il adı paylaşılır.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true)
            .setContentIntent(Notifs.openAppIntent(ctx))
        runCatching { NotificationManagerCompat.from(ctx).notify(("lq" + m.id).hashCode(), b.build()) }
    }

    /** İlim değiştiyse (ya da 6 saatte bir) paylaştığım kişilere güncel ili gönder. */
    fun broadcastProvince() {
        val share = members.value.filter { it.shareWith }
        if (share.isEmpty()) return
        val now = System.currentTimeMillis()
        val cur = myProvince() ?: ""
        val last = prefs.sp.getString("prov_sent", "") ?: ""
        val lastTs = prefs.sp.getLong("prov_sent_ts", 0L)
        if (cur == last && now - lastTs < 6 * 3600_000L) return
        prefs.sp.edit().putString("prov_sent", cur).putLong("prov_sent_ts", now).apply()
        share.forEach { sendProvince(it) }
    }

    /** Yakınımın bulunduğu ilde deprem olursa bildirim ("Güvende misin? sor" düğmesiyle). */
    fun checkQuake(q: Quake) {
        if (q.mag < prefs.circleQuakeMag || !Notifs.canPost(ctx)) return
        val qProv = q.province.ifBlank { CrowdFelt.provinceOf(q.lat, q.lon) ?: "" }
        if (qProv.isBlank()) return
        val done = (prefs.sp.getStringSet("cq_done", emptySet()) ?: emptySet()).toMutableSet()
        for (m in members.value) {
            if (m.prov.isBlank() || !m.prov.equals(qProv, ignoreCase = true)) continue
            val k = q.id + "|" + m.id
            if (!done.add(k)) continue
            val body = "${q.place} • ${java.text.SimpleDateFormat("HH:mm", java.util.Locale("tr")).format(java.util.Date(q.time))}"
            val b = NotificationCompat.Builder(ctx, Notifs.CH_CIRCLE)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("${m.name} (${m.prov}): M${"%.1f".format(java.util.Locale("tr"), q.mag)} deprem")
                .setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText("$body\nBulunduğu ilde deprem oldu. Güvende mi diye sorabilirsin."))
                .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_MESSAGE).setAutoCancel(true)
                .setContentIntent(Notifs.openAppIntent(ctx))
                .addAction(0, "Güvende misin? sor", actionIntent(m.id, CType.CHECK, ("q" + m.id).hashCode()))
            runCatching { NotificationManagerCompat.from(ctx).notify(("cq" + k).hashCode(), b.build()) }
        }
        prefs.sp.edit().putStringSet("cq_done", HashSet(done.toList().takeLast(200))).apply()
    }

    private val lastReq = HashMap<String, Long>()

    /** Elle yenileme (aşağı çek): yeni mesajları çek, ili bilinmeyenlere isteği yeniden gönder, ilimi tekrar yolla. */
    suspend fun syncNow() {
        runCatching { LocationHelper.refresh(ctx) }
        pollNow()
        val now = System.currentTimeMillis()
        members.value.filter { !it.group && it.prov.isBlank() && it.theirProv.isBlank() && !it.noAuto }.forEach { m ->
            if (now - (lastReq[m.id] ?: 0L) > 60_000L) { lastReq[m.id] = now; send(m, CType.LOCREQ, "") }
        }
        prefs.sp.edit().putLong("prov_sent_ts", 0L).apply()
        broadcastProvince()
        delay(400); pollNow()
    }

    private fun scopeMain(f: () -> Unit) { CoroutineScope(Dispatchers.Main).launch { f() } }

    private fun actionIntent(memberId: String, type: CType, req: Int): PendingIntent =
        PendingIntent.getBroadcast(ctx, req, Intent(ctx, CircleActionReceiver::class.java)
            .putExtra("member", memberId).putExtra("type", type.name), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun safeActionIntent(): PendingIntent = actionIntent("all", CType.SAFE, 9001)

    private fun notifyEvent(memberId: String, name: String, type: CType, text: String, lat: Double?, lon: Double?) {
        if (!Notifs.canPost(ctx)) return
        if (type == CType.READ || (type == CType.TEXT && !prefs.circleNotif)) return
        val d = if (lat != null && lon != null) Geo.distanceFromMe(lat, lon) else null
        val (title, body) = when (type) {
            CType.READ, CType.LOCREQ, CType.LOCOK, CType.LOCOFF -> return
            CType.CHECK -> "$name: Güvende misin?" to "Yakının durumunu soruyor. Tek dokunuşla cevap ver."
            CType.SAFE -> "$name güvende ✓" to (text.ifBlank { "Güvendeyim" })
            CType.HELP -> "$name yardım istiyor!" to text.ifBlank { "Yardım lazım" }
            CType.SOS -> "$name ENKAZ ALTINDA!" to text.ifBlank { "Enkaz altındayım, yardım edin!" }
            CType.HELLO -> "$name bağlandı" to "Artık birbirinizin durumunu görebilirsiniz."
            CType.TEXT -> name to text
        }
        val b = NotificationCompat.Builder(ctx, Notifs.CH_CIRCLE)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title)
            .setContentText(body + (d?.let { " • ~${fmtKm(it)} uzakta" } ?: ""))
            .setStyle(NotificationCompat.BigTextStyle().bigText(body + (d?.let { " • ~${fmtKm(it)} uzakta" } ?: "")))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true)
            .setContentIntent(Notifs.openAppIntent(ctx))
        if (type == CType.CHECK) {
            b.addAction(0, "Güvendeyim", actionIntent(memberId, CType.SAFE, memberId.hashCode()))
            b.addAction(0, "Yardım lazım", actionIntent(memberId, CType.HELP, memberId.hashCode() + 1))
        }
        runCatching { NotificationManagerCompat.from(ctx).notify(("c$memberId$type").hashCode(), b.build()) }
    }

    private fun fmtKm(km: Double) = if (km < 1) "${(km * 1000).toInt()} m" else "${km.toInt()} km"

    // ------------------------------------------------------------- internet dinleme
    fun stop() { activeCall?.cancel() }

    suspend fun subscribeLoop() {
        var backoff = 2000L
        while (currentCoroutineContext().isActive) {
            val ms = members.value
            if (ms.isEmpty()) { delay(5000); continue }
            val since = prefs.sp.getLong("circle_since", System.currentTimeMillis() / 1000 - 6 * 3600)
            val url = "${server()}/${ms.joinToString(",") { topic(it) }}/json?since=$since"
            val call = stream.newCall(Request.Builder().url(url).header("User-Agent", "DepremKalkani/1.0").build())
            activeCall = call
            coroutineScope {
                val watcher = launch { members.drop(1).first(); call.cancel() } // kişi listesi değişirse yeniden bağlan
                runCatching {
                    withContext(Dispatchers.IO) {
                        call.execute().use { r ->
                            if (!r.isSuccessful) error("HTTP ${r.code}")
                            backoff = 2000L
                            flushPending()
                            val src = r.body!!.source()
                            while (!src.exhausted()) {
                                val line = src.readUtf8Line() ?: break
                                runCatching {
                                    val o = JSONObject(line)
                                    if (o.optString("event") == "message") {
                                        prefs.sp.edit().putLong("circle_since", o.getLong("time") + 1).apply()
                                        onCipher(o.getString("message"), o.optString("topic"))
                                    }
                                }
                            }
                        }
                    }
                }
                watcher.cancel()
            }
            if (!currentCoroutineContext().isActive) break
            delay(backoff); backoff = minOf(backoff * 2, 60_000L)
        }
    }
}
