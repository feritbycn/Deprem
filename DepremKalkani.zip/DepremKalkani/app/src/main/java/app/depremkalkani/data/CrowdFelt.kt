package app.depremkalkani.data

import android.content.Context
import app.depremkalkani.dk
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlin.math.floor

/**
 * "Deprem hissettim" toplu raporu. Kendi sunucumuz yok; açık kaynak ntfy aktarma sunucusunda
 * bölge hücresi (0,5° ≈ 55 km) başına herkese açık bir konu kullanılır. Her cihaz hücresine
 * (yaklaşık konum + rastgele cihaz kimliği) bir oy yazar; yakındaki 9 hücre okunup son 15 dk'daki
 * FARKLI cihazlar sayılır. Eşiği aşınca bildirim gönderilir.
 * Sınır: herkese açık ve doğrulamasız olduğundan kötü niyetli kişiler sahte oy yazabilir.
 */
object CrowdFelt {
    data class Stat(val count: Int, val region: String, val ts: Long)

    val stat = MutableStateFlow<Stat?>(null)
    private const val WINDOW_MS = 15 * 60_000L
    private const val RADIUS_KM = 60.0

    private val CENTERS: Map<String, Pair<Double, Double>> = mapOf(
        "Adana" to (37.00 to 35.32), "Adıyaman" to (37.76 to 38.28), "Afyonkarahisar" to (38.76 to 30.54),
        "Ağrı" to (39.72 to 43.05), "Aksaray" to (38.37 to 34.03), "Amasya" to (40.65 to 35.83),
        "Ankara" to (39.93 to 32.86), "Antalya" to (36.90 to 30.70), "Ardahan" to (41.11 to 42.70),
        "Artvin" to (41.18 to 41.82), "Aydın" to (37.85 to 27.84), "Balıkesir" to (39.65 to 27.89),
        "Bartın" to (41.64 to 32.34), "Batman" to (37.88 to 41.13), "Bayburt" to (40.26 to 40.23),
        "Bilecik" to (40.14 to 29.98), "Bingöl" to (38.88 to 40.50), "Bitlis" to (38.40 to 42.11),
        "Bolu" to (40.73 to 31.61), "Burdur" to (37.72 to 30.29), "Bursa" to (40.19 to 29.06),
        "Çanakkale" to (40.15 to 26.41), "Çankırı" to (40.60 to 33.62), "Çorum" to (40.55 to 34.95),
        "Denizli" to (37.78 to 29.09), "Diyarbakır" to (37.91 to 40.24), "Düzce" to (40.84 to 31.16),
        "Edirne" to (41.68 to 26.56), "Elazığ" to (38.67 to 39.22), "Erzincan" to (39.75 to 39.49),
        "Erzurum" to (39.90 to 41.27), "Eskişehir" to (39.78 to 30.52), "Gaziantep" to (37.07 to 37.38),
        "Giresun" to (40.91 to 38.39), "Gümüşhane" to (40.46 to 39.48), "Hakkari" to (37.57 to 43.74),
        "Hatay" to (36.20 to 36.16), "Iğdır" to (39.92 to 44.04), "Isparta" to (37.76 to 30.55),
        "İstanbul" to (41.01 to 28.98), "İzmir" to (38.42 to 27.14), "Kahramanmaraş" to (37.58 to 36.94),
        "Karabük" to (41.20 to 32.62), "Karaman" to (37.18 to 33.22), "Kars" to (40.60 to 43.10),
        "Kastamonu" to (41.38 to 33.78), "Kayseri" to (38.72 to 35.49), "Kilis" to (36.72 to 37.12),
        "Kırıkkale" to (39.85 to 33.51), "Kırklareli" to (41.74 to 27.22), "Kırşehir" to (39.15 to 34.17),
        "Kocaeli" to (40.77 to 29.94), "Konya" to (37.87 to 32.48), "Kütahya" to (39.42 to 29.98),
        "Malatya" to (38.35 to 38.31), "Manisa" to (38.61 to 27.43), "Mardin" to (37.31 to 40.74),
        "Mersin" to (36.81 to 34.64), "Muğla" to (37.22 to 28.36), "Muş" to (38.74 to 41.49),
        "Nevşehir" to (38.62 to 34.71), "Niğde" to (37.97 to 34.68), "Ordu" to (40.98 to 37.88),
        "Osmaniye" to (37.07 to 36.25), "Rize" to (41.02 to 40.52), "Sakarya" to (40.69 to 30.44),
        "Samsun" to (41.29 to 36.33), "Şanlıurfa" to (37.16 to 38.79), "Siirt" to (37.93 to 41.94),
        "Sinop" to (42.03 to 35.15), "Sivas" to (39.75 to 37.02), "Şırnak" to (37.52 to 42.46),
        "Tekirdağ" to (40.98 to 27.51), "Tokat" to (40.31 to 36.55), "Trabzon" to (41.00 to 39.72),
        "Tunceli" to (39.11 to 39.55), "Uşak" to (38.68 to 29.41), "Van" to (38.49 to 43.38),
        "Yalova" to (40.65 to 29.27), "Yozgat" to (39.82 to 34.81), "Zonguldak" to (41.45 to 31.79),
    )

    /** Konuma en yakın il adı; Türkiye dışındaysa null. */
    fun provinceOf(lat: Double, lon: Double): String? {
        val best = CENTERS.minByOrNull { Geo.distanceKm(lat, lon, it.value.first, it.value.second) } ?: return null
        return if (Geo.distanceKm(lat, lon, best.value.first, best.value.second) <= 150.0) best.key else null
    }

    /** Bildirim/ekran cümlesi: "İstanbul, Türkiye yakınlarında 7 kullanıcı deprem hissettiğini bildirdi." */
    fun sentence(region: String, count: Int) =
        "$count kullanıcı ($region) deprem hissettiğini bildiriyor"

    /** Aynı bölge anahtarı: Türkiye'de il adı, dışında 0,5° hücre. Farklı iller birbirine sayılmaz. */
    fun areaKey(lat: Double, lon: Double): String = provinceOf(lat, lon) ?: ("hucre:" + cell(lat, lon))
    fun areaLabel(lat: Double, lon: Double): String = provinceOf(lat, lon) ?: "Bulunduğun bölge"

    private fun regionLabel(lat: Double, lon: Double): String = areaLabel(lat, lon)

    private fun cell(lat: Double, lon: Double, di: Int = 0, dj: Int = 0) =
        "dkfelt_${floor(lat * 2).toInt() + di}_${floor(lon * 2).toInt() + dj}"

    private fun server(ctx: Context) = ctx.dk.prefs.sp.getString("circle_server", "https://ntfy.sh")!!.trim().trimEnd('/')

    /** Oyunu yazar. felt=true "Hissettim", false "Hissetmedim". Konum yoksa false döner. */
    suspend fun report(ctx: Context, felt: Boolean): Boolean {
        LocationHelper.refresh(ctx)
        if (!Geo.known) return false
        val lat = Geo.lat!!; val lon = Geo.lon!!
        // aynı cihaz 10 dk içinde tekrar "hissettim" derse yeniden gönderilmez (sayıyı şişirmesin)
        val lastKey = if (felt) "felt_last_yes" else "felt_last_no"
        val prev = ctx.dk.prefs.sp.getLong(lastKey, 0L)
        if (System.currentTimeMillis() - prev < 10 * 60_000L) return true
        ctx.dk.prefs.sp.edit().putLong(lastKey, System.currentTimeMillis()).apply()
        val o = JSONObject().apply {
            put("d", app.depremkalkani.mesh.Mesh.myId); put("f", if (felt) 1 else 0)
            put("la", Math.round(lat * 10) / 10.0); put("lo", Math.round(lon * 10) / 10.0)
            put("r", regionLabel(lat, lon)); put("k", areaKey(lat, lon)); put("t", System.currentTimeMillis())
        }
        if (felt) runCatching { app.depremkalkani.mesh.Mesh.send(app.depremkalkani.mesh.MsgType.FELT, "Deprem hissettim", withLocation = true) }
        return withContext(Dispatchers.IO) {
            runCatching {
                val req = Request.Builder().url("${server(ctx)}/${cell(lat, lon)}")
                    .post(o.toString().toRequestBody("text/plain".toMediaType())).header("User-Agent", Mark.UA).build()
                Sources.client.newCall(req).execute().use { it.isSuccessful }
            }.getOrDefault(false)
        }
    }

    /** Yakın hücreleri okur, durumu hesaplar ve [stat]'a yazar. */
    suspend fun refresh(ctx: Context): Stat? = withContext(Dispatchers.IO) {
        if (!Geo.known) return@withContext null
        val lat = Geo.lat!!; val lon = Geo.lon!!
        val topics = buildList { for (i in -2..2) for (j in -2..2) add(cell(lat, lon, i, j)) }.joinToString(",")
        val text = runCatching {
            val req = Request.Builder().url("${server(ctx)}/$topics/json?poll=1&since=15m").header("User-Agent", Mark.UA).build()
            Sources.client.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
        }.getOrNull() ?: return@withContext stat.value
        val now = System.currentTimeMillis()
        val latest = HashMap<String, JSONObject>()
        for (line in text.lineSequence()) {
            runCatching {
                val m = JSONObject(line)
                if (m.optString("event") != "message") return@runCatching
                val v = JSONObject(m.getString("message"))
                val id = v.getString("d"); val t = v.optLong("t", now)
                if (now - t > WINDOW_MS || t > now + 120_000L) return@runCatching
                val old = latest[id]
                if (old == null || old.optLong("t") <= t) latest[id] = v
            }
        }
        val myKey = areaKey(lat, lon)
        val felt = latest.values.filter { it.optInt("f") == 1 && it.optString("k") == myKey }
        val region = regionLabel(lat, lon)
        val s = Stat(felt.size, region, now)
        stat.value = s
        s
    }

    /** Arka plan kontrolü: eşik aşıldıysa (ve 30 dk içinde bildirilmediyse) bildirim gönderir. */
    suspend fun check(ctx: Context) {
        val prefs = ctx.dk.prefs
        if (!prefs.feltNotif) return
        val s = refresh(ctx) ?: return
        if (s.count >= prefs.feltThreshold) {
            val last = prefs.sp.getLong("felt_notified_ts", 0L)
            if (System.currentTimeMillis() - last > 30 * 60_000L) {
                prefs.sp.edit().putLong("felt_notified_ts", System.currentTimeMillis()).apply()
                Notifs.notifyFelt(ctx, s.region, s.count)
            }
        }
    }
}
