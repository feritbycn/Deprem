package app.depremkalkani.data

import android.content.Context
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

enum class RegionMode(val label: String) {
    TURKEY("Tüm Türkiye"), WORLD("Dünya geneli"), PROVINCES("Seçtiğim iller"), RADIUS("Konumuma yakın")
}

enum class AlertSound(val label: String, val raw: String?) {
    CALM("Sakin uyarı (önerilen)", "calm_alert"), SYSTEM("Sistem varsayılanı", null), SIREN("Siren", "siren"), SOS("SOS", "sos"), NUCLEAR("Nükleer alarm", "nuclear")
}

class Contact(val name: String, val phone: String)

class Prefs(ctx: Context) {
    private val appCtx: Context = ctx.applicationContext
    val sp = ctx.getSharedPreferences("dk", Context.MODE_PRIVATE)

    private fun bool(k: String, d: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) { sp.edit().putBoolean(k, value).apply() }
    }
    private fun int(k: String, d: Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) { sp.edit().putInt(k, value).apply() }
    }
    private fun long(k: String, d: Long) = object : ReadWriteProperty<Any?, Long> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getLong(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) { sp.edit().putLong(k, value).apply() }
    }
    private fun float(k: String, d: Float) = object : ReadWriteProperty<Any?, Float> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getFloat(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) { sp.edit().putFloat(k, value).apply() }
    }
    private fun str(k: String, d: String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) { sp.edit().putString(k, value).apply() }
    }
    private fun set(k: String, d: Set<String>) = object : ReadWriteProperty<Any?, Set<String>> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getStringSet(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Set<String>) { sp.edit().putStringSet(k, HashSet(value)).apply() }
    }

    // --- bildirim
    var monitorOn by bool("monitor_on", true)
    var notifMinMag by float("notif_min_mag", 4.0f)
    var alertSound by str("alert_sound", AlertSound.CALM.name)
    var vibrate by bool("vibrate", true)
    var nightMode by bool("night_mode", false)       // gece 23-07 arası yalnızca M5+ çal
    var sources by set("sources", setOf(Sources.AFAD, Sources.KANDILLI))
    var regionMode by str("region_mode", RegionMode.TURKEY.name)
    var provinces by set("provinces", emptySet())
    var radiusKm by int("radius_km", 300)

    var meshNotif by bool("mesh_notif", true)          // yakındaki kullanıcılardan gelen mesaj bildirimleri
    var circleNotif by bool("circle_notif", true)      // yakınlarımdan gelen düz mesaj bildirimleri

    // --- kitle "hissettim" bildirimi ve sismik dalga
    var feltNotif by bool("felt_notif", true)
    var feltThreshold by int("felt_threshold", 5)      // bu sayıdan FAZLA kullanıcı bildirirse haber ver
    var waveAlertKm by int("wave_alert_km", 500)       // tam ekran sismik dalga uyarısı için en uzak merkez üssü
    var waveTestKm by int("wave_test_km", 80)
    var waveSound by bool("wave_sound", true)          // sismik dalga ekranında sakin uyarı sesi
    var waveVibrate by bool("wave_vibrate", true)      // sismik dalga ekranında kısa titreşim
    var speakOn by bool("speak_on", true)              // depremi sesli oku
    var speakMinMag by float("speak_min_mag", 0f)      // 0 = hepsi
    var speakMaxKm by int("speak_max_km", 0)           // 0 = mesafe sınırı yok          // test depreminin sana uzaklığı

    // --- liste/harita filtresi
    var listMinMag by float("list_min_mag", 2.0f)

    // --- acil durum
    var whistleMaxVolume by bool("whistle_max", true)
    var whistleSos by bool("whistle_sos", true)        // 3'lü kısa düdük düzeni
    var rescueFlash by bool("rescue_flash", true)
    var rescueBeacon by bool("rescue_beacon", true)
    var shakeDetect by bool("shake_detect", false)
    var nick by str("nick", "")
    var nickAsked by bool("nick_asked", false)
    var accountName by str("acc_name", "")
    var accountEmail by str("acc_email", "")
    var familyCode by str("family_code", "")
    var emergencyNote by str("emg_note", "")           // kan grubu, ilaç, alerji...
    var c1n by str("c1n", ""); var c1p by str("c1p", "")
    var c2n by str("c2n", ""); var c2p by str("c2p", "")
    var c3n by str("c3n", ""); var c3p by str("c3p", "")
    val contacts: List<Contact>
        get() = listOf(Contact(c1n, c1p), Contact(c2n, c2p), Contact(c3n, c3p)).filter { it.phone.isNotBlank() }

    // --- pro
    private var proRaw by bool("is_pro", false)
    private var proToken by str("pro_tok", "")
    var proSig by str("pro_sig", "")
    var launchCount by int("launch_count", 0)
    var firstLaunch by long("first_launch", 0L)
    var reviewAskedAt by long("review_at", 0L)
    var reviewAskCount by int("review_n", 0)
    var fsiAsked by bool("fsi_asked", false)
    var battAsked by bool("batt_asked", false)
    var loginAsked by bool("login_asked", false)
    /** Pro yalnızca imzalı kayıt geçerliyse açıktır (düz bayrak düzenlemesi işe yaramaz). */
    val isPro: Boolean get() = proRaw && app.depremkalkani.billing.Guard.proMac(appCtx, proToken) == proSig
    fun grantPro(token: String) { proToken = token; proSig = app.depremkalkani.billing.Guard.proMac(appCtx, token); proRaw = true }
    fun revokePro() { proRaw = false; proToken = ""; proSig = "" }
    var onboarded by bool("onboarded", false)

    // --- yardımcı
    var seenIds: Set<String>
        get() = sp.getStringSet("seen_ids", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("seen_ids", HashSet(v)).apply() }

    var bagChecked by set("bag_checked", emptySet())
    var feltIds by set("felt_ids", emptySet())

    val sound get() = runCatching { AlertSound.valueOf(alertSound) }.getOrDefault(AlertSound.CALM)
    val region get() = runCatching { RegionMode.valueOf(regionMode) }.getOrDefault(RegionMode.TURKEY)
    val pollSeconds get() = if (isPro) 15L else 30L
}
