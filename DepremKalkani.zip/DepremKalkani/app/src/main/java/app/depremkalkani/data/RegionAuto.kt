package app.depremkalkani.data

/**
 * "Bölgem" filtresi: ayarlardan bağımsız, telefonun konumundan otomatik karar verir.
 *  - Türkiye'deysen (ya da konum bilinmiyorsa): Türkiye ve çevresi, yalnızca yerel kurumlar (AFAD, Kandilli).
 *  - Başka ülkedeysen: konumuna 1000 km içindeki depremler, tüm kaynaklardan.
 */
object RegionAuto {
    private fun inTurkeyBox(lat: Double, lon: Double) = lat in 34.5..43.0 && lon in 24.5..45.5

    fun userInTurkey(): Boolean = !Geo.known || inTurkeyBox(Geo.lat!!, Geo.lon!!)

    fun label(): String = if (userInTurkey()) "Türkiye" else "1000 km"

    fun inMyRegion(q: Quake): Boolean =
        if (userInTurkey()) QuakeRepository.inTurkeyArea(q) && (q.source == Sources.AFAD || q.source == Sources.KANDILLI || q.source == "TEST")
        else (Geo.distanceFromMe(q) ?: Double.MAX_VALUE) <= 1000.0
}
