package app.depremkalkani.data

import java.text.SimpleDateFormat
import java.util.*

/** Uygulamayla birlikte gelen, internet olmasa da görünen önemli depremler (tarihî kayıtlar). */
object Seed {
    private fun t(s: String): Long = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        .apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(s)!!.time

    val notable: List<Quake> = listOf(
        Quake("H-2023-1", "TARIHI", t("2023-02-06 01:17"), 37.17, 37.03, 8.6, 7.8, "Pazarcık (Kahramanmaraş) — Kahramanmaraş depremi", "Kahramanmaraş"),
        Quake("H-2023-2", "TARIHI", t("2023-02-06 10:24"), 38.02, 37.20, 7.0, 7.5, "Elbistan (Kahramanmaraş)", "Kahramanmaraş"),
        Quake("H-2020-2", "TARIHI", t("2020-10-30 11:51"), 37.90, 26.78, 10.0, 6.9, "Sisam / Seferihisar açıkları (İzmir)", "İzmir"),
        Quake("H-2020-1", "TARIHI", t("2020-01-24 17:55"), 38.43, 39.06, 8.0, 6.8, "Sivrice (Elazığ)", "Elazığ"),
        Quake("H-2011-1", "TARIHI", t("2011-10-23 10:41"), 38.72, 43.36, 17.0, 7.1, "Tabanlı / Erciş (Van)", "Van"),
        Quake("H-1999-2", "TARIHI", t("1999-11-12 16:57"), 40.77, 31.15, 10.0, 7.2, "Düzce", "Düzce"),
        Quake("H-1999-1", "TARIHI", t("1999-08-17 00:01"), 40.75, 29.86, 17.0, 7.6, "Gölcük (Kocaeli) — Marmara depremi", "Kocaeli"),
    )
}
