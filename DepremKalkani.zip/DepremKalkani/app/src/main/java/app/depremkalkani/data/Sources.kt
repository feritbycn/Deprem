package app.depremkalkani.data

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * Veriler ARACI SUNUCU OLMADAN, doğrudan resmi kurumların açık servislerinden çekilir:
 *  - AFAD      : https://deprem.afad.gov.tr/apiv2/event/filter
 *  - Kandilli  : http://www.koeri.boun.edu.tr/scripts/lst0.asp
 *  - EMSC      : https://www.seismicportal.eu/fdsnws/event/1/query
 *  - USGS      : https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/
 */
object Sources {
    const val AFAD = "AFAD"
    const val KANDILLI = "KANDILLI"
    const val EMSC = "EMSC"
    const val USGS = "USGS"
    val ALL = listOf(AFAD, KANDILLI, EMSC, USGS)

    fun label(s: String) = when (s) {
        AFAD -> "AFAD"; KANDILLI -> "Kandilli"; EMSC -> "EMSC"; USGS -> "USGS"; "TARIHI" -> "Tarihî"; else -> s
    }

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun get(url: String): ByteArray {
        val req = Request.Builder().url(url).header("User-Agent", "DepremKalkani/1.0").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code} $url")
            return r.body!!.bytes()
        }
    }

    private fun fmt(p: String, tz: String = "UTC") =
        SimpleDateFormat(p, Locale.US).apply { timeZone = TimeZone.getTimeZone(tz) }

    // ---------------------------------------------------------------- AFAD
    fun fetchAfad(): List<Quake> {
        val f = fmt("yyyy-MM-dd'T'HH:mm:ss")
        val now = System.currentTimeMillis()
        val url = "https://deprem.afad.gov.tr/apiv2/event/filter" +
            "?start=${f.format(Date(now - 3 * 86400_000L))}&end=${f.format(Date(now + 86400_000L))}" +
            "&orderby=timedesc&limit=1000&format=json"
        val arr = JSONArray(String(get(url), Charsets.UTF_8))
        val parse = fmt("yyyy-MM-dd'T'HH:mm:ss")
        val out = ArrayList<Quake>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            runCatching {
                val t = parse.parse(o.getString("date").take(19))!!.time
                val prov = o.optString("province").takeIf { it != "null" } ?: ""
                val district = o.optString("district").takeIf { it != "null" } ?: ""
                val loc = o.optString("location")
                val place = if (district.isNotBlank() && prov.isNotBlank()) "$district ($prov)" else loc
                out += Quake(
                    id = "AFAD-" + o.optString("eventID", t.toString()),
                    source = AFAD, time = t,
                    lat = o.getString("latitude").toDouble(), lon = o.getString("longitude").toDouble(),
                    depthKm = o.optString("depth", "0").toDoubleOrNull() ?: 0.0,
                    mag = o.getString("magnitude").toDouble(),
                    place = place.ifBlank { loc }, province = prov,
                    url = "https://deprem.afad.gov.tr/event-detail/" + o.optString("eventID"),
                )
            }
        }
        return out
    }

    // ------------------------------------------------------------ KANDILLI
    private val kRegex = Regex(
        """^(\d{4}\.\d{2}\.\d{2})\s+(\d{2}:\d{2}:\d{2})\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+?)\s*$"""
    )
    private val kTail = Regex("""\s+(İlksel|Ilksel|REVIZE.*)$""", RegexOption.IGNORE_CASE)

    fun fetchKandilli(): List<Quake> {
        val bytes = runCatching { get("https://www.koeri.boun.edu.tr/scripts/lst0.asp") }
            .getOrElse { get("http://www.koeri.boun.edu.tr/scripts/lst0.asp") }
        val text = String(bytes, Charset.forName("ISO-8859-9"))
        val f = fmt("yyyy.MM.dd HH:mm:ss", "Europe/Istanbul")
        val out = ArrayList<Quake>()
        for (raw in text.lineSequence()) {
            val line = kTail.replace(raw.trim(), "")
            val m = kRegex.find(line) ?: continue
            runCatching {
                val g = m.groupValues
                val t = f.parse("${g[1]} ${g[2]}")!!.time
                val md = g[6].toDoubleOrNull(); val ml = g[7].toDoubleOrNull(); val mw = g[8].toDoubleOrNull()
                val mag = listOf(ml, mw, md).firstOrNull { it != null && it > 0.0 } ?: return@runCatching
                val place = g[9].trim()
                val provRaw = Regex("""\(([^)]+)\)""").findAll(place).lastOrNull()?.groupValues?.get(1)?.trim() ?: ""
                val prov = TURKEY_PROVINCES.firstOrNull { it.asciiUpper() == provRaw.asciiUpper() } ?: provRaw.toTitle()
                val name = place.substringBefore('(').trim(' ', '-').toTitle()
                val disp = if (provRaw.isNotBlank()) "$name ($prov)" else name
                out += Quake("KDL-${t / 1000}-${g[3]}", KANDILLI, t, g[3].toDouble(), g[4].toDouble(),
                    g[5].toDouble(), mag, disp, if (prov in TURKEY_PROVINCES) prov else "",
                    "http://www.koeri.boun.edu.tr/scripts/lst0.asp")
            }
        }
        return out
    }

    private fun String.toTitle(): String =
        lowercase(Locale("tr")).split(' ', '-').joinToString(" ") { w ->
            w.replaceFirstChar { it.titlecase(Locale("tr")) }
        }.replace(" (", " (")

    // ---------------------------------------------------------------- EMSC
    fun fetchEmsc(): List<Quake> {
        val url = "https://www.seismicportal.eu/fdsnws/event/1/query?limit=300&format=json&orderby=time&minmag=2.5"
        val feats = JSONObject(String(get(url))).getJSONArray("features")
        val f = fmt("yyyy-MM-dd'T'HH:mm:ss")
        val out = ArrayList<Quake>()
        for (i in 0 until feats.length()) {
            runCatching {
                val p = feats.getJSONObject(i).getJSONObject("properties")
                val t = f.parse(p.getString("time").take(19))!!.time
                val unid = p.optString("unid", t.toString())
                out += Quake("EMSC-$unid", EMSC, t, p.getDouble("lat"), p.getDouble("lon"),
                    kotlin.math.abs(p.optDouble("depth", 0.0)), p.getDouble("mag"),
                    p.optString("flynn_region", "Bilinmiyor").toTitleKeep(),
                    url = "https://www.emsc-csem.org/Earthquake_information/earthquake.php?id=$unid")
            }
        }
        return out
    }

    private fun String.toTitleKeep() = lowercase().split(' ').joinToString(" ") { w ->
        w.replaceFirstChar { it.titlecase() }
    }

    // ---------------------------------------------------------------- USGS
    fun fetchUsgs(): List<Quake> {
        val url = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojson"
        val feats = JSONObject(String(get(url))).getJSONArray("features")
        val out = ArrayList<Quake>()
        for (i in 0 until feats.length()) {
            runCatching {
                val ft = feats.getJSONObject(i)
                val p = ft.getJSONObject("properties")
                val c = ft.getJSONObject("geometry").getJSONArray("coordinates")
                out += Quake("USGS-${ft.getString("id")}", USGS, p.getLong("time"), c.getDouble(1), c.getDouble(0),
                    c.optDouble(2, 0.0), p.getDouble("mag"), p.optString("place", "Bilinmiyor"),
                    url = p.optString("url").ifBlank { null })
            }
        }
        return out
    }

    fun fetch(source: String): List<Quake> = when (source) {
        AFAD -> fetchAfad(); KANDILLI -> fetchKandilli(); EMSC -> fetchEmsc(); USGS -> fetchUsgs()
        else -> emptyList()
    }
}
