package app.depremkalkani.data

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Telefonun kendi metin okuma motoruyla (internet gerekmez) depremi sesli okur. Alarm ses seviyesini kullanır. */
object Speaker {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val queue = ArrayList<String>()
    private var errorCb: (String) -> Unit = {}

    fun speak(ctx: Context, text: String, onError: (String) -> Unit = {}) {
        errorCb = onError
        val t = tts
        if (t != null && ready) { say(t, text); return }
        synchronized(queue) { queue += text }
        if (t == null) {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                val engine = tts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    val r = engine.setLanguage(Locale("tr", "TR"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
                        errorCb("Türkçe ses verisi yüklü değil. Telefon Ayarları → Metin okuma (Text-to-speech) bölümünden Türkçe'yi indir.")
                    engine.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    ready = true
                    val pending = synchronized(queue) { queue.toList().also { queue.clear() } }
                    pending.forEach { say(engine, it) }
                } else {
                    errorCb("Metin okuma motoru başlatılamadı. Telefonda bir metin okuma uygulaması (Google) yüklü olmalı.")
                    tts = null
                    synchronized(queue) { queue.clear() }
                }
            }
        }
    }

    fun stop() { runCatching { tts?.stop() } }

    private fun say(t: TextToSpeech, text: String) {
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dk-" + System.currentTimeMillis())
    }

    fun sentence(q: Quake, distKm: Double?): String {
        val mag = "%.1f".format(Locale.US, q.mag).replace('.', ',')
        if (q.source == "TEST") return "Bu bir test depremidir. $mag büyüklüğünde deprem, sana ${distKm?.toInt() ?: 80} kilometre uzaklıkta."
        val where = q.province.ifBlank { q.place }.replace(Regex("\\(.*?\\)"), "").trim().ifBlank { "bilinmeyen bölge" }
        return "Dikkat. $where bölgesinde $mag büyüklüğünde deprem oldu." +
            (distKm?.let { " Sana yaklaşık ${it.toInt()} kilometre uzaklıkta." } ?: "")
    }

    /** Ayarlara uyuyorsa sesli okur. */
    fun maybeSpeak(ctx: Context, q: Quake, p: Prefs, distKm: Double?) {
        if (!p.speakOn) return
        if (q.mag < p.speakMinMag) return
        if (p.speakMaxKm > 0 && distKm != null && distKm > p.speakMaxKm) return
        if (System.currentTimeMillis() - q.time > 15 * 60_000L) return
        speak(ctx, sentence(q, distKm))
    }
}
