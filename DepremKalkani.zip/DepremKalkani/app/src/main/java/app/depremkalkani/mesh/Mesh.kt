package app.depremkalkani.mesh

import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.depremkalkani.R
import app.depremkalkani.data.Geo
import app.depremkalkani.data.Notifs
import app.depremkalkani.data.Prefs
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class MsgType(val label: String) {
    TEXT("Mesaj"), CIRCLE("Yakın"), FELT("Deprem hissettim"), SOS("ENKAZ ALTINDAYIM"), SAFE("Güvendeyim"), ACK("Görüldü"), INJURED("Yaralıyım"), NEED("Su / yiyecek / ilaç lazım")
}

data class MeshMsg(
    val id: String, val from: String, val nick: String, val type: MsgType, val text: String,
    val lat: Double?, val lon: Double?, val ts: Long, val ttl: Int, val family: String, val to: String = "",
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("f", from); put("n", nick); put("ty", type.name); put("tx", text)
        if (lat != null && lon != null) { put("la", lat); put("lo", lon) }
        put("ts", ts); put("ttl", ttl); put("fam", family); put("to", to)
    }
    companion object {
        fun from(o: JSONObject) = MeshMsg(
            o.getString("id"), o.getString("f"), o.optString("n"),
            runCatching { MsgType.valueOf(o.getString("ty")) }.getOrDefault(MsgType.TEXT), o.optString("tx"),
            if (o.has("la")) o.getDouble("la") else null, if (o.has("lo")) o.getDouble("lo") else null,
            o.getLong("ts"), o.optInt("ttl", 0), o.optString("fam"), o.optString("to"),
        )
    }
}

data class Peer(val endpointId: String, val nick: String, val devId: String, val connected: Boolean)

/**
 * İNTERNETSİZ yakın cihaz iletişimi (Google Nearby Connections, P2P_CLUSTER).
 * Bluetooth + Wi-Fi Direct üzerinden, hücresel/internet olmadan çalışır.
 * Mesajlar "taşma" (flooding) yöntemiyle komşu telefonlardan komşulara aktarılır (TTL=8 atlama):
 * uygulamayı kullanan telefonlar zincir oluşturursa menzil uzar. Menzil tek atlamada açık alanda
 * yaklaşık 30-100 m, enkaz/beton içinde çok daha azdır. Garantili bir kurtarma yöntemi DEĞİLDİR.
 */
object Mesh {
    private const val SERVICE_ID = "app.depremkalkani.mesh.v1"
    private const val MAX_MSGS = 300
    private const val TTL = 8

    private lateinit var ctx: Context
    private lateinit var prefs: Prefs

    val running = MutableStateFlow(false)
    val peers = MutableStateFlow<Map<String, Peer>>(emptyMap())
    val messages = MutableStateFlow<List<MeshMsg>>(emptyList())
    val error = MutableStateFlow<String?>(null)
    /** mesaj kimliği -> görenlerin adları */
    val acks = MutableStateFlow<Map<String, Set<String>>>(emptyMap())
    private val ackedMsgs = HashSet<String>()

    private val seen = LinkedHashSet<String>()
    private val pending = HashSet<String>()
    lateinit var myId: String
        private set

    fun init(c: Context, p: Prefs) {
        ctx = c.applicationContext; prefs = p
        val sp = p.sp
        myId = sp.getString("dev_id", null) ?: UUID.randomUUID().toString().take(8).also { sp.edit().putString("dev_id", it).apply() }
        runCatching {
            val a = JSONArray(sp.getString("mesh_msgs", "[]"))
            val list = (0 until a.length()).map { MeshMsg.from(a.getJSONObject(it)) }
            messages.value = list; list.forEach { seen += it.id }
        }
    }

    private val client get() = Nearby.getConnectionsClient(ctx)
    private val myName get() = (prefs.nick.ifBlank { "Anonim" }.replace("|", "")) + "|" + myId

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var watchdog: Job? = null

    fun start() {
        if (running.value) return
        error.value = null
        prefs.sp.edit().putBoolean("mesh_on", true).apply()
        begin()
        running.value = true
        // Bluetooth/konum sonradan açılırsa ya da bağlantı takılırsa radyoyu yeniden başlat
        watchdog?.cancel()
        watchdog = scope.launch {
            while (isActive) {
                delay(20_000)
                if (running.value && connectedCount == 0) restartRadio()
            }
        }
    }

    private fun begin() {
        val adv = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        val dis = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        client.startAdvertising(myName, SERVICE_ID, lifecycle, adv).addOnFailureListener { fail(it) }
        client.startDiscovery(SERVICE_ID, discovery, dis).addOnFailureListener { fail(it) }
    }

    /** Ekrandaki gelen yakın mesajları için karşıya "görüldü" gönder. */
    fun markSeen() {
        messages.value.filter { it.from != myId && System.currentTimeMillis() - it.ts < 2 * 3600_000L && it.id !in ackedMsgs && it.type != MsgType.FELT && it.type != MsgType.CIRCLE && it.type != MsgType.ACK }.forEach { o ->
            ackedMsgs += o.id
            val a = MeshMsg(UUID.randomUUID().toString(), myId, prefs.nick.ifBlank { "Anonim" }, MsgType.ACK, o.id, null, null, System.currentTimeMillis(), TTL, "")
            seen += a.id
            broadcast(a, except = null)
        }
    }

    fun rescan() { if (running.value) restartRadio() }

    private fun restartRadio() {
        runCatching { client.stopAdvertising(); client.stopDiscovery() }
        pending.clear()
        peers.value = peers.value.filterValues { it.connected }
        runCatching { begin() }
    }

    fun stop() {
        watchdog?.cancel()
        prefs.sp.edit().putBoolean("mesh_on", false).apply()
        runCatching { client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints() }
        peers.value = emptyMap(); pending.clear(); running.value = false
    }

    /** Uygulama/servis açılırken, kullanıcı taramayı daha önce açtıysa kendiliğinden başlat. */
    fun autoStart(hasPerms: Boolean) {
        if (hasPerms && prefs.sp.getBoolean("mesh_on", false) && !running.value) start()
    }

    private fun fail(e: Exception) {
        // ALREADY_ADVERTISING / ALREADY_DISCOVERING hataları zararsızdır
        val m = e.message ?: ""
        if (!m.contains("8001") && !m.contains("8002")) error.value = "Yakın cihaz tarama başlatılamadı: $m"
    }

    // ----------------------------------------------------------------- gönderim
    fun send(type: MsgType, text: String, withLocation: Boolean = true, to: String = ""): MeshMsg {
        val m = MeshMsg(
            id = UUID.randomUUID().toString(), from = myId, nick = prefs.nick.ifBlank { "Anonim" },
            type = type, text = text,
            lat = if (withLocation) Geo.lat else null, lon = if (withLocation) Geo.lon else null,
            ts = System.currentTimeMillis(), ttl = TTL, family = prefs.familyCode.trim().lowercase(), to = to,
        )
        store(m)
        broadcast(m, except = null)
        return m
    }

    /** Yakınlarım şifreli mesajını mesh'e bırakır (saklanmaz, sohbette görünmez). */
    fun sendCircle(cipher: String) {
        val m = MeshMsg(UUID.randomUUID().toString(), myId, "", MsgType.CIRCLE, cipher, null, null, System.currentTimeMillis(), TTL, "")
        seen += m.id
        broadcast(m, except = null)
    }

    private fun broadcast(m: MeshMsg, except: String?) {
        val targets = peers.value.values.filter { it.connected && it.endpointId != except }.map { it.endpointId }
        if (targets.isEmpty()) return
        val p = Payload.fromBytes(m.toJson().toString().toByteArray())
        client.sendPayload(targets, p)
    }

    private fun store(m: MeshMsg) {
        seen += m.id
        val list = (messages.value + m).sortedBy { it.ts }.takeLast(MAX_MSGS)
        messages.value = list
        runCatching {
            val a = JSONArray(); list.forEach { a.put(it.toJson()) }
            prefs.sp.edit().putString("mesh_msgs", a.toString()).apply()
        }
    }

    fun clearAll() {
        messages.value = emptyList(); seen.clear()
        prefs.sp.edit().remove("mesh_msgs").apply()
    }

    // ------------------------------------------------------------------ alım
    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val m = runCatching { MeshMsg.from(JSONObject(String(bytes))) }.getOrNull() ?: return
            if (m.id in seen) return
            if (m.type == MsgType.ACK) {   // "görüldü" bilgisi: sayıya ekle ve zincirle ilet
                seen += m.id
                if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
                acks.value = acks.value + (m.text to ((acks.value[m.text] ?: emptySet()) + m.nick.ifBlank { "Anonim" }))
                return
            }
            if (m.type == MsgType.CIRCLE) {   // yakınlarım: şifreli, sohbette gösterilmez; yalnız aktarılır ve çözülmeye çalışılır
                seen += m.id
                if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
                app.depremkalkani.data.Circles.onCipher(m.text)
                return
            }
            if (m.type == MsgType.FELT) {   // aynı cihazdan 10 dk içinde gelen tekrarları yok say
                val dup = messages.value.any { it.type == MsgType.FELT && it.from == m.from && kotlin.math.abs(m.ts - it.ts) < 10 * 60_000L }
                if (dup) { seen += m.id; return }
            }
            store(m)
            // ilet: TTL varsa komşulara yay
            if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
            notifyIncoming(m)
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private fun forMe(m: MeshMsg): Boolean {
        if (m.to.isNotBlank() && m.to != myId) return false
        val fam = prefs.familyCode.trim().lowercase()
        // aile kodlu mesaj yalnızca aynı kodu kullananlara bildirim yapar; SOS herkese açıktır
        return m.type == MsgType.SOS || m.family.isBlank() || m.family == fam
    }

    private fun notifyIncoming(m: MeshMsg) {
        if (!forMe(m) || !Notifs.canPost(ctx)) return
        if (!prefs.meshNotif && m.type != MsgType.SOS) return   // SOS çağrıları her zaman bildirilir
        if (System.currentTimeMillis() - m.ts > 10 * 60_000L) return   // eski (sakla-ve-ilet) mesajlar için bildirim yağdırma
        if (m.type == MsgType.FELT) {   // yalnızca eşik aşılırsa, 30 dk'da en fazla bir kez
            val last = prefs.sp.getLong("mesh_felt_notified", 0L)
            if (!prefs.feltNotif || feltNearby() < prefs.feltThreshold || System.currentTimeMillis() - last < 30 * 60_000L) return
            prefs.sp.edit().putLong("mesh_felt_notified", System.currentTimeMillis()).apply()
        }
        val d = if (m.lat != null && m.lon != null) Geo.distanceFromMe(m.lat, m.lon) else null
        val title = when (m.type) {
            MsgType.SOS -> "SOS • ${m.nick} yardım istiyor!"
            MsgType.INJURED -> "${m.nick} yaralı"
            MsgType.NEED -> "${m.nick} malzeme istiyor"
            MsgType.SAFE -> "${m.nick} güvende"
            MsgType.FELT -> "Kullanıcılar deprem hissedildiğini bildiriyor"
            MsgType.CIRCLE, MsgType.ACK -> ""
            MsgType.TEXT -> m.nick
        }
        val body = if (m.type == MsgType.FELT) app.depremkalkani.data.CrowdFelt.sentence(if (Geo.known) app.depremkalkani.data.CrowdFelt.areaLabel(Geo.lat!!, Geo.lon!!) else "yakınında", feltNearby()) else buildString {
            if (m.text.isNotBlank()) append(m.text)
            if (d != null) { if (isNotEmpty()) append(" • "); append("~${if (d < 1) "${(d * 1000).toInt()} m" else "${d.toInt()} km"} uzakta") }
        }.ifBlank { m.type.label }
        val n = NotificationCompat.Builder(ctx, Notifs.CH_MESH)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true)
            .setContentIntent(Notifs.openAppIntent(ctx)).build()
        runCatching { NotificationManagerCompat.from(ctx).notify(if (m.type == MsgType.FELT) 7002 else m.id.hashCode(), n) }
    }

    // ------------------------------------------------------------ bağlantı
    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            val (nick, dev) = splitName(info.endpointName)
            peers.value = peers.value + (id to Peer(id, nick, dev, false))
            client.acceptConnection(id, payloadCb)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            pending.remove(id)
            if (result.status.isSuccess) {
                peers.value[id]?.let { peers.value = peers.value + (id to it.copy(connected = true)) }
                // yeni gelen cihaza son 24 saatteki SOS/durum mesajlarını aktar (sakla-ve-ilet)
                val cutoff = System.currentTimeMillis() - 24 * 3600_000L
                app.depremkalkani.data.Circles.recentCiphers().takeLast(20).forEach {
                    client.sendPayload(id, Payload.fromBytes(MeshMsg(UUID.randomUUID().toString(), myId, "", MsgType.CIRCLE, it, null, null, System.currentTimeMillis(), TTL, "").toJson().toString().toByteArray()))
                }
                messages.value.filter { it.ts > cutoff && it.ttl > 0 }.takeLast(60).forEach {
                    client.sendPayload(id, Payload.fromBytes(it.copy(ttl = it.ttl - 1).toJson().toString().toByteArray()))
                }
            } else {
                peers.value = peers.value - id
            }
        }

        override fun onDisconnected(id: String) {
            peers.value = peers.value - id; pending.remove(id)
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            val (_, dev) = splitName(info.endpointName)
            if (dev == myId || id in pending || peers.value[id]?.connected == true) return
            pending += id
            // iki cihaz aynı anda bağlanmaya çalışıp çakışmasın: küçük kimlikli hemen, diğeri 4 sn sonra dener
            val wait = if (myId < dev) 0L else 4000L
            scope.launch {
                delay(wait)
                if (peers.value.containsKey(id)) return@launch
                client.requestConnection(myName, id, lifecycle).addOnFailureListener { pending.remove(id) }
            }
        }
        override fun onEndpointLost(id: String) { pending.remove(id) }
    }

    private fun splitName(n: String): Pair<String, String> {
        val i = n.lastIndexOf('|')
        return if (i < 0) n to n else n.substring(0, i) to n.substring(i + 1)
    }

    /** Son 30 dk içinde, farklı cihazlardan gelen "hissettim" bildirimi sayısı */
    fun feltNearby(): Int {
        val cut = System.currentTimeMillis() - 30 * 60_000L
        val key = if (Geo.known) app.depremkalkani.data.CrowdFelt.areaKey(Geo.lat!!, Geo.lon!!) else null
        return messages.value.filter {
            it.type == MsgType.FELT && it.ts > cut &&
                (key == null || (it.lat != null && it.lon != null && app.depremkalkani.data.CrowdFelt.areaKey(it.lat, it.lon) == key))
        }.map { it.from }.distinct().size
    }

    val connectedCount get() = peers.value.values.count { it.connected }
}
