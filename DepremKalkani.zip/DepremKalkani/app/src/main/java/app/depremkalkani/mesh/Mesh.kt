package app.depremkalkani.mesh

import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.depremkalkani.R
import app.depremkalkani.data.Geo
import app.depremkalkani.data.Notifs
import app.depremkalkani.data.Prefs
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class MsgType(val label: String) {
    TEXT("Mesaj"), CIRCLE("Yakın"), FELT("Deprem hissettim"), SOS("ENKAZ ALTINDAYIM"), SAFE("Güvendeyim"), ACK("Görüldü"), INJURED("Yaralıyım"), NEED("Su / yiyecek / ilaç lazım"), LOCREQ("Tam konum isteği"), LOCOK("Tam konum"), VOICE("Sesli mesaj"), LOC("Konumumu paylaşıyorum"),
    WIFIREQ("Wi-Fi arıyor"), WIFIOK("Wi-Fi paylaşıldı"), WIFIACK("Wi-Fi'ye bağlandı")
}

data class MeshMsg(
    val id: String, val from: String, val nick: String, val type: MsgType, val text: String,
    val lat: Double?, val lon: Double?, val ts: Long, val ttl: Int, val family: String, val to: String = "", val au: String? = null,
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("f", from); put("n", nick); put("ty", type.name); put("tx", text)
        if (lat != null && lon != null) { put("la", lat); put("lo", lon) }
        put("ts", ts); put("ttl", ttl); put("fam", family); put("to", to)
        if (au != null) put("au", au)
    }
    companion object {
        fun from(o: JSONObject) = MeshMsg(
            o.getString("id"), o.getString("f"), app.depremkalkani.data.NickGuard.clean(o.optString("n")),
            runCatching { MsgType.valueOf(o.getString("ty")) }.getOrDefault(MsgType.TEXT), o.optString("tx"),
            if (o.has("la")) o.getDouble("la") else null, if (o.has("lo")) o.getDouble("lo") else null,
            o.getLong("ts"), o.optInt("ttl", 0), o.optString("fam"), o.optString("to"), if (o.has("au")) o.getString("au") else null,
        )
    }
}

/** Wi-Fi isteği (yalnız bellekte): isteyenin açık anahtarı yanıtı şifrelemek için kullanılır. */
data class WifiReq(val id: String, val from: String, val nick: String, val pub: String, val ts: Long)
/** Bana paylaşılan hotspot bilgisi (yalnız bellekte tutulur, kaydedilmez). */
data class WifiOffer(val from: String, val nick: String, val ssid: String, val pass: String, val ts: Long)

data class Peer(val endpointId: String, val nick: String, val devId: String, val connected: Boolean)

/**
 * İNTERNETSİZ yakın cihaz iletişimi (Google Nearby Connections, P2P_CLUSTER).
 * Bluetooth + Wi-Fi Direct üzerinden, hücresel/internet olmadan çalışır.
 * Mesajlar "taşma" (flooding) yöntemiyle komşu telefonlardan komşulara aktarılır (TTL=8 atlama):
 * uygulamayı kullanan telefonlar zincir oluşturursa menzil uzar. Menzil tek atlamada açık alanda
 * yaklaşık 30-100 m, enkaz/beton içinde çok daha azdır. Garantili bir kurtarma yöntemi DEĞİLDİR.
 */
object Mesh {
    private const val SERVICE_ID = "app.depremkalkani.mesh.v1"
    private const val MAX_MSGS = 300
    private const val TTL = 8
    private val LEGACY_WIFI_TEXT = setOf("Wi-Fi arıyor", "Wi-Fi paylaşıldı", "Wi-Fi'ye bağlandı", "Wi-Fi'ye bağlandı ✓")
    private const val WIFI_REQ_TTL = 60 * 60_000L   // Wi-Fi isteği 1 saat geçerli: sonradan yaklaşan kişi de görebilsin

    private lateinit var ctx: Context
    private lateinit var prefs: Prefs

    val running = MutableStateFlow(false)
    val peers = MutableStateFlow<Map<String, Peer>>(emptyMap())
    val messages = MutableStateFlow<List<MeshMsg>>(emptyList())
    val error = MutableStateFlow<String?>(null)
    /** "Yeniden tara" sürerken true (cihaz bulunana ya da süre dolana kadar) */
    val scanning = MutableStateFlow(false)
    private var scanJob: Job? = null
    /** mesaj kimliği -> görenlerin cihaz kimlikleri */
    val acks = MutableStateFlow<Map<String, Set<String>>>(emptyMap())
    private val ackedMsgs = HashSet<String>()

    val wifiRequests = MutableStateFlow<List<WifiReq>>(emptyList())
    val wifiOffer = MutableStateFlow<WifiOffer?>(null)
    private var wifiPriv: java.security.PrivateKey? = null
    private var wifiReqAt = 0L

    private val seen = LinkedHashSet<String>()
    private val pending = HashSet<String>()
    lateinit var myId: String
        private set

    fun init(c: Context, p: Prefs) {
        ctx = c.applicationContext; prefs = p
        val sp = p.sp
        myId = sp.getString("dev_id", null) ?: UUID.randomUUID().toString().take(8).also { sp.edit().putString("dev_id", it).apply() }
        runCatching {
            val a = JSONArray(sp.getString("mesh_msgs", "[]"))
            val list = (0 until a.length()).map { MeshMsg.from(a.getJSONObject(it)) }
            messages.value = list; list.forEach { seen += it.id }
        }
    }

    private val client get() = Nearby.getConnectionsClient(ctx)
    private val myName get() = (prefs.nick.ifBlank { "Anonim" }.replace("|", "")) + "|" + myId

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, e -> android.util.Log.w("DK", "coroutine", e) })
    private var watchdog: Job? = null

    fun start() {
        if (running.value) return
        error.value = null
        prefs.sp.edit().putBoolean("mesh_on", true).apply()
        begin()
        running.value = true
        // Bluetooth/konum sonradan açılırsa ya da bağlantı takılırsa radyoyu yeniden başlat
        watchdog?.cancel()
        watchdog = scope.launch {
            while (isActive) {
                delay(45_000)
                if (running.value && connectedCount == 0 && pending.isEmpty() && retries.isEmpty()) restartRadio()
            }
        }
    }

    private fun begin() {
        try {
            val adv = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
            val dis = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
            client.startAdvertising(myName, SERVICE_ID, lifecycle, adv).addOnFailureListener { fail(it) }
            client.startDiscovery(SERVICE_ID, discovery, dis).addOnFailureListener { fail(it) }
        } catch (e: Exception) { fail(e) }   // Google Play hizmetleri eksik/eski telefonlarda çökmesin
    }

    /** Ekrandaki gelen yakın mesajları için karşıya "görüldü" gönder. */
    fun markSeen() {
        messages.value.filter { it.from != myId && System.currentTimeMillis() - it.ts < 2 * 3600_000L && it.id !in ackedMsgs && it.type != MsgType.FELT && it.type != MsgType.CIRCLE && it.type != MsgType.ACK && it.type != MsgType.LOCREQ && it.type != MsgType.LOCOK && it.type != MsgType.VOICE && it.type != MsgType.WIFIREQ && it.type != MsgType.WIFIOK && it.type != MsgType.WIFIACK }.forEach { o ->
            ackedMsgs += o.id
            val a = MeshMsg(UUID.randomUUID().toString(), myId, prefs.nick.ifBlank { "Anonim" }, MsgType.ACK, o.id, null, null, System.currentTimeMillis(), TTL, "")
            seen += a.id
            broadcast(a, except = null)
        }
    }

    /** Sesli mesaj dinlendi bilgisi (yalnız dinleyince gider). */
    fun sendHeard(id: String) {
        val a = MeshMsg(UUID.randomUUID().toString(), myId, prefs.nick.ifBlank { "Anonim" }, MsgType.ACK, id, null, null, System.currentTimeMillis(), 1, "")
        seen += a.id
        broadcast(a, except = null)
    }

    fun rescan() {
        if (!running.value || scanning.value) return
        error.value = null
        scanning.value = true
        restartRadio()
        scanJob?.cancel()
        scanJob = scope.launch {
            var i = 0
            while (i < 24 && peers.value.isEmpty()) { delay(500); i++ }   // en çok ~12 sn; cihaz bulunursa erken biter
            delay(600)
            scanning.value = false
        }
    }

    private fun restartRadio() {
        runCatching { client.stopAdvertising(); client.stopDiscovery() }
        pending.clear(); known.clear(); retries.clear()
        peers.value = peers.value.filterValues { it.connected }
        runCatching { begin() }
    }

    fun stop() {
        watchdog?.cancel(); scanJob?.cancel(); scanning.value = false
        prefs.sp.edit().putBoolean("mesh_on", false).apply()
        runCatching { client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints() }
        peers.value = emptyMap(); pending.clear(); known.clear(); retries.clear(); running.value = false
    }

    /** Uygulama/servis açılırken, kullanıcı taramayı daha önce açtıysa kendiliğinden başlat. */
    fun autoStart(hasPerms: Boolean) {
        if (hasPerms && prefs.sp.getBoolean("mesh_on", false) && !running.value) start()
    }

    private fun fail(e: Exception) {
        // ALREADY_ADVERTISING / ALREADY_DISCOVERING hataları zararsızdır
        val m = e.message ?: ""
        if (m.contains("8001") || m.contains("8002")) return
        error.value = when {
            m.contains("8034") || m.contains("LOCATION") -> "Konum izni eksik: Uygulama izinlerinden Konum'u 'Yalnızca uygulama kullanılırken izin ver' yap ve 'Yaklaşık konum'u da aç. Sonra 'Yeniden tara'ya bas."
            m.contains("8035") || m.contains("BLUETOOTH") || m.contains("NEARBY") -> "Yakındaki cihazlar / Bluetooth izni eksik: Uygulama izinlerinden 'Yakındaki cihazlar'ı aç."
            m.contains("8030") || m.contains("8031") || m.contains("8032") -> "Bluetooth ya da Wi-Fi kapalı olabilir; ikisini de açıp 'Yeniden tara'ya bas."
            else -> "Yakın cihaz tarama başlatılamadı: $m"
        }
    }

    // ----------------------------------------------------------------- gönderim
    fun send(type: MsgType, text: String, withLocation: Boolean = true, to: String = "", au: String? = null): MeshMsg {
        // SOS yakındaki herkese yayınlandığı için tam konum verilmez: kapalıysa konumsuz, açıksa ~200 m yuvarlanmış
        // Konum yalnız kullanıcı "Konumumu paylaş" dediğinde (LOC), tam konum onayında (LOCOK), kitle bildiriminde (FELT) ya da SOS ayarı açıkken gider.
        val loc = withLocation && Geo.known && (type == MsgType.LOC || type == MsgType.LOCOK || type == MsgType.FELT || (type == MsgType.SOS && prefs.sosShareNearby))
        val coarse = type == MsgType.SOS || type == MsgType.LOC
        fun r(v: Double?) = if (v != null && coarse) Math.round(v / 0.002) * 0.002 else v
        val m = MeshMsg(
            id = UUID.randomUUID().toString(), from = myId, nick = prefs.nick.ifBlank { "Anonim" },
            type = type, text = text,
            lat = if (loc) r(Geo.lat) else null, lon = if (loc) r(Geo.lon) else null,
            ts = System.currentTimeMillis(), ttl = TTL, family = prefs.familyCode.trim().lowercase(), to = to, au = au,
        )
        store(m)
        broadcast(m, except = null)
        return m
    }

    /** Yanıtlanmış tam konum istekleri (id). */
    val answered = MutableStateFlow<Set<String>>(emptySet())

    /** Gönüllü: SOS gönderenden tam konumunu ister (yalnız o cihaza yönelik). */
    fun requestLocation(sos: MeshMsg) {
        send(MsgType.LOCREQ, "Gönüllü tam konumunu istiyor. Paylaşırsan yalnız ona gider.", withLocation = false, to = sos.from)
    }

    /** SOS sahibi onaylar: tam konum yalnız isteyen cihaza yönelik gönderilir. */
    fun approveLocation(req: MeshMsg) {
        if (Geo.known) send(MsgType.LOCOK, "Tam konum paylaşıldı", withLocation = true, to = req.from)
        answered.value = answered.value + req.id
    }

    /** Yakındakilerden Wi-Fi ister. Dakikada en fazla bir kez. */
    fun requestWifi(): Boolean {
        val now = System.currentTimeMillis()
        if (now - wifiReqAt < 60_000L) return false
        wifiReqAt = now
        val kp = WifiCrypto.newKeyPair()
        wifiPriv = kp.priv
        send(MsgType.WIFIREQ, "Wi-Fi arıyor", withLocation = false, au = kp.pubB64)   // anahtar text'te değil au'da: eski sürümler kod gibi göstermesin
        return true
    }

    /** Kayıtlı hotspot bilgisini her isteyene yalnız ona şifreli olarak gönderir. */
    fun shareWifi(reqs: List<WifiReq>, ssid: String, pass: String): Int {
        var n = 0
        reqs.forEach { r ->
            val kp = WifiCrypto.newKeyPair()
            val enc = runCatching { WifiCrypto.encrypt(kp.priv, r.pub, JSONObject().put("s", ssid).put("p", pass).toString()) }.getOrNull() ?: return@forEach
            val m = MeshMsg(UUID.randomUUID().toString(), myId, prefs.nick.ifBlank { "Anonim" }, MsgType.WIFIOK, "Wi-Fi paylaşıldı", null, null,
                System.currentTimeMillis(), TTL, "", to = r.from, au = kp.pubB64 + "|" + enc)
            seen += m.id
            broadcast(m, except = null)
            n++
        }
        wifiRequests.value = emptyList()
        return n
    }

    private val wifiKnown = HashMap<String, WifiReq>()
    /** Olaylar'daki "Wi-Fi arıyor" kartına dokunulunca isteği paylaşma penceresine geri getirir. */
    fun openWifiReq(msgId: String): Boolean {
        val r = wifiKnown[msgId] ?: return false
        if (System.currentTimeMillis() - r.ts > WIFI_REQ_TTL) return false
        wifiRequests.value = listOf(r)
        return true
    }

    fun clearWifiRequests() { wifiRequests.value = emptyList() }
    fun dismissWifiOffer() { wifiOffer.value = null }
    fun sendWifiAck(to: String) { send(MsgType.WIFIACK, "Wi-Fi'ye bağlandı ✓", withLocation = false, to = to) }

    private fun onWifiReq(m: MeshMsg) {
        val pub = m.au
        if (m.from == myId || pub.isNullOrBlank()) return
        val now = System.currentTimeMillis()
        if (now - m.ts > WIFI_REQ_TTL) return
        val req = WifiReq(m.id, m.from, m.nick, pub, m.ts)
        wifiKnown[m.id] = req
        wifiRequests.value = (wifiRequests.value.filter { it.from != m.from } + req).filter { now - it.ts < WIFI_REQ_TTL }
    }

    fun hasActiveSos() = messages.value.any { it.from == myId && it.type == MsgType.SOS && System.currentTimeMillis() - it.ts < 2 * 3600_000L }

    /** Yakınlarım şifreli mesajını mesh'e bırakır (saklanmaz, sohbette görünmez). */
    fun sendCircle(cipher: String) {
        val m = MeshMsg(UUID.randomUUID().toString(), myId, "", MsgType.CIRCLE, cipher, null, null, System.currentTimeMillis(), TTL, "")
        seen += m.id
        broadcast(m, except = null)
    }

    private fun broadcast(m: MeshMsg, except: String?) {
        val targets = peers.value.values.filter { it.connected && it.endpointId != except }.map { it.endpointId }
        if (targets.isEmpty()) return
        val p = Payload.fromBytes(m.toJson().toString().toByteArray())
        client.sendPayload(targets, p)
    }

    /** Sesli mesaj: yalnız doğrudan bağlı cihazlara (aktarılmaz). target=null → gönüllü modundaki bağlı cihazlar. */
    fun sendVoice(file: java.io.File, secs: Int, target: String?): Boolean {
        val bytes = runCatching { file.readBytes() }.getOrNull() ?: return false
        if (bytes.size > Voice.MAX_BYTES) return false
        val ids = peers.value.values.filter { it.connected && (target == null || it.devId == target) }.map { it.endpointId }
        if (ids.isEmpty()) return false
        val id = UUID.randomUUID().toString()
        runCatching { file.copyTo(Voice.file(ctx, id), overwrite = true) }
        val m = MeshMsg(id, myId, prefs.nick.ifBlank { "Anonim" }, MsgType.VOICE, "$secs sn sesli mesaj", null, null,
            System.currentTimeMillis(), 0, "", to = target ?: "", au = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))
        client.sendPayload(ids, Payload.fromBytes(m.toJson().toString().toByteArray()))
        store(m)
        return true
    }

    private fun store(m0: MeshMsg) {
        val m = m0.copy(au = null)
        seen += m.id
        val list = (messages.value + m).sortedBy { it.ts }.takeLast(MAX_MSGS)
        messages.value = list
        runCatching {
            val a = JSONArray(); list.forEach { a.put(it.toJson()) }
            prefs.sp.edit().putString("mesh_msgs", a.toString()).apply()
        }
    }

    fun clearAll() {
        messages.value = emptyList(); seen.clear()
        prefs.sp.edit().remove("mesh_msgs").apply()
    }

    // ------------------------------------------------------------------ alım
    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val m = runCatching { MeshMsg.from(JSONObject(String(bytes))) }.getOrNull() ?: return
            if (m.id in seen) return
            if (m.type == MsgType.ACK) {   // "görüldü" bilgisi: sayıya ekle ve zincirle ilet
                seen += m.id
                if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
                acks.value = acks.value + (m.text to ((acks.value[m.text] ?: emptySet()) + m.from))   // cihaz kimliği (ad gösterilmez)
                return
            }
            if (m.type == MsgType.CIRCLE) {   // yakınlarım: şifreli, sohbette gösterilmez; yalnız aktarılır ve çözülmeye çalışılır
                seen += m.id
                if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
                app.depremkalkani.data.Circles.onCipher(m.text)
                return
            }
            if ((m.type == MsgType.LOCREQ || m.type == MsgType.LOCOK || m.type == MsgType.WIFIOK || m.type == MsgType.WIFIACK) && m.to != myId) {   // başkasına yönelik: yalnız aktar, saklama
                seen += m.id
                if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
                return
            }
            if (m.type == MsgType.WIFIOK) {   // bana paylaşılan Wi-Fi: çöz, yalnız bellekte tut; kayda şifresiz özet yazılır
                seen += m.id
                val au = m.au
                val priv = wifiPriv
                if (au == null || priv == null) return
                val parts = au.split("|")
                if (parts.size != 2) return
                val plain = WifiCrypto.decrypt(priv, parts[0], parts[1]) ?: return
                val o = runCatching { JSONObject(plain) }.getOrNull() ?: return
                wifiOffer.value = WifiOffer(m.from, m.nick, o.optString("s"), o.optString("p"), System.currentTimeMillis())
                val safe = m.copy(text = "Wi-Fi paylaşıldı", au = null)
                store(safe); notifyIncoming(safe)
                return
            }
            if (m.type == MsgType.VOICE) {   // ses: yalnız bana yönelikse ya da gönüllüysem; aktarılmaz
                seen += m.id
                val a = m.au
                val ok = a != null && (m.to == myId || (m.to.isBlank() && prefs.volunteer))
                if (!ok) return
                try { Voice.file(ctx, m.id).writeBytes(android.util.Base64.decode(a, android.util.Base64.DEFAULT)) } catch (_: Throwable) { return }
                store(m); notifyIncoming(m)
                return
            }
            if (m.type == MsgType.FELT) {   // aynı cihazdan 10 dk içinde gelen tekrarları yok say
                val dup = messages.value.any { it.type == MsgType.FELT && it.from == m.from && kotlin.math.abs(m.ts - it.ts) < 10 * 60_000L }
                if (dup) { seen += m.id; return }
            }
            if (m.type == MsgType.TEXT && m.text in LEGACY_WIFI_TEXT) {   // Wi-Fi mesajını tanımayan sürümden gelen düz metin: sohbete ve bildirime girmesin
                seen += m.id
                if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
                return
            }
            if (m.type == MsgType.TEXT && m.text.length > 80 && m.text.startsWith("MFkw") && !m.text.contains(" ")) {   // eski sürümden gelen ham anahtar: göster/bildirme, yalnız aktar
                seen += m.id
                if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
                return
            }
            store(m)
            // ilet: TTL varsa komşulara yay
            if (m.ttl > 0) broadcast(m.copy(ttl = m.ttl - 1), except = endpointId)
            notifyIncoming(m)
            if (m.type == MsgType.WIFIREQ) onWifiReq(m)
            if (m.type == MsgType.LOCREQ && prefs.sosAutoLoc && hasActiveSos()) approveLocation(m)
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private fun forMe(m: MeshMsg): Boolean {
        if (m.to.isNotBlank() && m.to != myId) return false
        val fam = prefs.familyCode.trim().lowercase()
        // aile kodlu mesaj yalnızca aynı kodu kullananlara bildirim yapar; SOS herkese açıktır
        return m.type == MsgType.SOS || m.family.isBlank() || m.family == fam
    }

    private fun notifyIncoming(m: MeshMsg) {
        if (!forMe(m) || !Notifs.canPost(ctx)) return
        val always = m.type == MsgType.SOS || m.type == MsgType.LOCREQ || m.type == MsgType.LOCOK || m.type == MsgType.VOICE || m.type == MsgType.WIFIREQ || m.type == MsgType.WIFIOK || m.type == MsgType.WIFIACK
        if (!prefs.meshNotif && !always) return   // SOS çağrıları her zaman bildirilir
        if (System.currentTimeMillis() - m.ts > (if (m.type == MsgType.WIFIREQ) WIFI_REQ_TTL else 10 * 60_000L)) return   // eski (sakla-ve-ilet) mesajlar için bildirim yağdırma
        if (m.type == MsgType.FELT) {   // yalnızca eşik aşılırsa, 30 dk'da en fazla bir kez
            val last = prefs.sp.getLong("mesh_felt_notified", 0L)
            if (!prefs.feltNotif || feltNearby() < prefs.feltThreshold || System.currentTimeMillis() - last < 30 * 60_000L) return
            prefs.sp.edit().putLong("mesh_felt_notified", System.currentTimeMillis()).apply()
        }
        val d = if (m.lat != null && m.lon != null) Geo.distanceFromMe(m.lat, m.lon) else null
        val title = when (m.type) {
            MsgType.SOS -> "SOS • ${m.nick} yardım istiyor!"
            MsgType.INJURED -> "${m.nick} yaralı"
            MsgType.NEED -> "${m.nick} malzeme istiyor"
            MsgType.SAFE -> "${m.nick} güvende"
            MsgType.FELT -> "Kullanıcılar deprem hissedildiğini bildiriyor"
            MsgType.VOICE -> "${m.nick} sesli mesaj gönderdi"
            MsgType.LOCREQ -> "${m.nick} tam konumunu istiyor"
            MsgType.LOCOK -> "${m.nick} tam konumunu paylaştı"
            MsgType.LOC -> "${m.nick} konumunu paylaştı"
            MsgType.WIFIREQ -> "📶 ${m.nick} Wi-Fi arıyor"
            MsgType.WIFIOK -> "✅ ${m.nick} Wi-Fi paylaştı"
            MsgType.WIFIACK -> "🔗 ${m.nick} Wi-Fi'ye bağlandı"
            MsgType.CIRCLE, MsgType.ACK -> ""
            MsgType.TEXT -> m.nick
        }
        val body = if (m.type == MsgType.FELT) app.depremkalkani.data.CrowdFelt.sentence(if (Geo.known) app.depremkalkani.data.CrowdFelt.areaLabel(Geo.lat!!, Geo.lon!!) else "yakınında", feltNearby()) else buildString {
            if (m.type == MsgType.WIFIREQ) append("Yakınında biri Wi-Fi arıyor. Paylaşmak için dokun.") else if (m.text.isNotBlank()) append(m.text)
            if (d != null) { if (isNotEmpty()) append(" • "); append("~${if (d < 1) "${(d * 1000).toInt()} m" else "${d.toInt()} km"} uzakta") }
            if (m.type == MsgType.SOS && prefs.volunteer) append("\nGönüllü: önce 112/AFAD'ı ara, tek başına enkaza girme.")
        }.ifBlank { m.type.label }
        val n = NotificationCompat.Builder(ctx, if (m.type == MsgType.TEXT || m.type == MsgType.VOICE) Notifs.chatChannel(prefs) else Notifs.CH_MESH)
            .setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true)
            .setContentIntent(if (m.type == MsgType.FELT) Notifs.openFeltIntent(ctx) else Notifs.openDestIntent(ctx, "mesh")).build()
        runCatching { NotificationManagerCompat.from(ctx).notify(if (m.type == MsgType.FELT) 7002 else m.id.hashCode(), n) }
    }

    // ------------------------------------------------------------ bağlantı
    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            val (nick, dev) = splitName(info.endpointName)
            peers.value = peers.value + (id to Peer(id, nick, dev, false))
            client.acceptConnection(id, payloadCb)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            pending.remove(id)
            if (result.status.isSuccess) {
                retries.remove(id)
                peers.value[id]?.let { peers.value = peers.value + (id to it.copy(connected = true)) }
                // yeni gelen cihaza son 24 saatteki SOS/durum mesajlarını aktar (sakla-ve-ilet)
                val cutoff = System.currentTimeMillis() - 24 * 3600_000L
                app.depremkalkani.data.Circles.recentCiphers().takeLast(20).forEach {
                    client.sendPayload(id, Payload.fromBytes(MeshMsg(UUID.randomUUID().toString(), myId, "", MsgType.CIRCLE, it, null, null, System.currentTimeMillis(), TTL, "").toJson().toString().toByteArray()))
                }
                messages.value.filter { it.ts > cutoff && it.ttl > 0 }.takeLast(60).forEach {
                    client.sendPayload(id, Payload.fromBytes(it.copy(ttl = it.ttl - 1).toJson().toString().toByteArray()))
                }
            } else {
                // bağlantı kurulamadı: bulunan cihazı listede tut, birkaç kez yeniden dene
                error.value = "Bağlantı kurulamadı (kod ${result.status.statusCode}); yeniden deneniyor…"
                peers.value[id]?.let { peers.value = peers.value + (id to it.copy(connected = false)) }
                retryLater(id)
            }
        }

        override fun onDisconnected(id: String) {
            pending.remove(id)
            peers.value[id]?.let { peers.value = peers.value + (id to it.copy(connected = false)) }
            retryLater(id)
        }
    }

    private val known = HashMap<String, Pair<String, String>>()   // endpointId -> (nick, devId) bulunan cihazlar
    private val retries = HashMap<String, Int>()

    private fun retryLater(id: String) {
        val n = (retries[id] ?: 0) + 1
        retries[id] = n
        if (n > 6 || !known.containsKey(id)) { if (n > 6) retries.remove(id); return }
        requestConn(id, 2500L * n)
    }

    private fun requestConn(id: String, delayMs: Long) {
        if (id in pending) return
        pending += id
        scope.launch {
            delay(delayMs)
            if (peers.value[id]?.connected == true || !known.containsKey(id)) { pending.remove(id); return@launch }
            client.requestConnection(myName, id, lifecycle).addOnFailureListener {
                pending.remove(id); retryLater(id)
            }
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            val (nick, dev) = splitName(info.endpointName)
            if (dev == myId) return
            known[id] = nick to dev
            if (peers.value[id] == null) peers.value = peers.value + (id to Peer(id, nick, dev, false))   // "Bulunan" hemen görünsün
            if (peers.value[id]?.connected == true) return
            // iki cihaz aynı anda bağlanmaya çalışıp çakışmasın: küçük kimlikli hemen, diğeri 4 sn sonra dener
            requestConn(id, if (myId < dev) 0L else 4000L)
        }
        override fun onEndpointLost(id: String) {
            known.remove(id); pending.remove(id)
            if (peers.value[id]?.connected != true) peers.value = peers.value - id
        }
    }

    private fun splitName(n: String): Pair<String, String> {
        val i = n.lastIndexOf('|')
        return if (i < 0) n to n else n.substring(0, i) to n.substring(i + 1)
    }

    /** Son 30 dk içinde, farklı cihazlardan gelen "hissettim" bildirimi sayısı */
    fun feltNearby(): Int {
        val cut = System.currentTimeMillis() - 30 * 60_000L
        val key = if (Geo.known) app.depremkalkani.data.CrowdFelt.areaKey(Geo.lat!!, Geo.lon!!) else null
        return messages.value.filter {
            it.type == MsgType.FELT && it.ts > cut &&
                (key == null || (it.lat != null && it.lon != null && app.depremkalkani.data.CrowdFelt.areaKey(it.lat, it.lon) == key))
        }.map { it.from }.distinct().size
    }

    val connectedCount get() = peers.value.values.count { it.connected }
}
