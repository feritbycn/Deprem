package app.depremkalkani.mesh

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.PlaybackParams
import android.os.Build
import java.io.File

/** Kısa sesli mesaj: AMR-NB (~12 kbps), en çok 10 sn (~15 KB). Alıcıda 2 saat saklanır, sonra silinir. */
object Voice {
    const val MAX_SECONDS = 10
    const val KEEP_MS = 2 * 3600_000L
    const val MAX_BYTES = 21_000

    fun dir(ctx: Context) = File(ctx.cacheDir, "voice").also { it.mkdirs() }
    fun file(ctx: Context, id: String) = File(dir(ctx), "$id.3gp")

    /** Süresi dolanları siler. */
    fun purge(ctx: Context) {
        val now = System.currentTimeMillis()
        dir(ctx).listFiles()?.forEach { if (now - it.lastModified() > KEEP_MS) it.delete() }
    }

    fun minutesLeft(ctx: Context, id: String): Long? {
        val f = file(ctx, id); if (!f.exists()) return null
        val left = KEEP_MS - (System.currentTimeMillis() - f.lastModified())
        return if (left <= 0) null else left / 60_000L + 1
    }

    class Recorder(private val ctx: Context) {
        private var rec: MediaRecorder? = null
        val out: File = File(dir(ctx), "rec_tmp.3gp")

        fun start(): Boolean = try {
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
            r.setAudioSamplingRate(8000)
            r.setAudioEncodingBitRate(12200)
            r.setMaxDuration(MAX_SECONDS * 1000)
            r.setOutputFile(out.absolutePath)
            r.prepare(); r.start()
            rec = r; true
        } catch (_: Throwable) { release(); false }

        fun stop(): Boolean {
            val r = rec ?: return false
            rec = null
            return try { r.stop(); r.release(); out.exists() && out.length() > 0 } catch (_: Throwable) { runCatching { r.release() }; false }
        }

        fun release() { runCatching { rec?.release() }; rec = null }
    }

    class Player {
        private var mp: MediaPlayer? = null
        fun play(f: File, speed: Float, onDone: () -> Unit) {
            stop()
            runCatching {
                val p = MediaPlayer()
                p.setDataSource(f.absolutePath); p.prepare()
                p.setOnCompletionListener { onDone() }
                p.start()
                if (speed != 1f) p.playbackParams = PlaybackParams().setSpeed(speed)
                mp = p
            }.onFailure { onDone() }
        }
        fun stop() { runCatching { mp?.stop() }; runCatching { mp?.release() }; mp = null }
    }
}
