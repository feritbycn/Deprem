package app.depremkalkani.mesh

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.WifiNetworkSuggestion
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Base64
import androidx.annotation.RequiresApi
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Wi-Fi isteyen kişinin açık anahtarı ile paylaşan kişinin geçici anahtarından ortak sır türetir; ara telefonlar şifreyi okuyamaz. */
object WifiCrypto {
    class Kp(val priv: PrivateKey, val pubB64: String)

    fun newKeyPair(): Kp {
        val g = KeyPairGenerator.getInstance("EC")
        g.initialize(ECGenParameterSpec("secp256r1"))
        val kp = g.generateKeyPair()
        return Kp(kp.private, Base64.encodeToString(kp.public.encoded, Base64.NO_WRAP))
    }

    private fun key(priv: PrivateKey, otherPubB64: String): SecretKeySpec {
        val pub = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(otherPubB64, Base64.NO_WRAP)))
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(priv)
        ka.doPhase(pub, true)
        return SecretKeySpec(MessageDigest.getInstance("SHA-256").digest(ka.generateSecret()), "AES")
    }

    fun encrypt(priv: PrivateKey, otherPubB64: String, plain: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(priv, otherPubB64), GCMParameterSpec(128, iv))
        return Base64.encodeToString(iv + c.doFinal(plain.toByteArray()), Base64.NO_WRAP)
    }

    fun decrypt(priv: PrivateKey, otherPubB64: String, data: String): String? = runCatching {
        val raw = Base64.decode(data, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(priv, otherPubB64), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        String(c.doFinal(raw, 12, raw.size - 12))
    }.getOrNull()
}

/** Hotspot bilgisi girişini kolaylaştıran yardımcılar: panodan yapıştır, panoya kopyala, ad ve şifre öner. */
object WifiHelp {
    fun paste(ctx: Context): String? = runCatching {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }.getOrNull()

    fun copy(ctx: Context, label: String, text: String) {
        runCatching {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText(label, text))
        }
    }

    /** Rastgele hotspot adı (DK-1234) ve 12 karakterlik şifre; karışabilecek harfler (0, O, 1, l, I) kullanılmaz. */
    fun suggest(): Pair<String, String> {
        val r = SecureRandom()
        val alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
        val name = "DK-" + (1000 + r.nextInt(9000))
        val pass = (1..12).map { alphabet[r.nextInt(alphabet.length)] }.joinToString("")
        return name to pass
    }
}

/** Paylaşılan hotspot'a bağlanma (Android 10+: yalnız bu uygulama için geçici bağlantı). */
object WifiLink {
    private var cb: ConnectivityManager.NetworkCallback? = null
    private val main = Handler(Looper.getMainLooper())

    fun online(ctx: Context): Boolean = runCatching {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }.getOrDefault(false)

    fun connect(ctx: Context, ssid: String, pass: String, onResult: (Boolean, String) -> Unit) {
        try {
            release(ctx)
            if (Build.VERSION.SDK_INT >= 29) connectQ(ctx, ssid, pass, onResult) else connectLegacy(ctx, ssid, pass, onResult)
        } catch (e: Exception) {
            onResult(false, "Bağlanılamadı: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    @RequiresApi(29)
    private fun connectQ(ctx: Context, ssid: String, pass: String, onResult: (Boolean, String) -> Unit) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val b = WifiNetworkSpecifier.Builder().setSsid(ssid)
        if (pass.isNotEmpty()) b.setWpa2Passphrase(pass)
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).setNetworkSpecifier(b.build()).build()
        val c = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runCatching { cm.bindProcessToNetwork(network) }
                main.post { onResult(true, "Bağlandı, ama yalnızca Deprem Kalkanı için: telefonun genel Wi-Fi'si bağlı görünmez ve tarayıcı gibi diğer uygulamalar bu ağı kullanmaz. Hepsi için \"Bilgiyi göster\"e basıp ağı Wi-Fi ayarlarından seç ya da yöntem 1'i kullan.") }
            }
            override fun onUnavailable() {
                main.post { onResult(false, "Bağlanılamadı. Android'in çıkardığı pencerede ağı onaylaman gerekebilir. Paylaşanın hotspot'u açık mı? 2,4 GHz bandı daha uyumludur.") }
            }
            override fun onLost(network: Network) {
                runCatching { cm.bindProcessToNetwork(null) }
            }
        }
        cb = c
        cm.requestNetwork(req, c, 45_000)
    }

    @Suppress("DEPRECATION")
    private fun connectLegacy(ctx: Context, ssid: String, pass: String, onResult: (Boolean, String) -> Unit) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val conf = WifiConfiguration()
        conf.SSID = "\"" + ssid + "\""
        conf.preSharedKey = "\"" + pass + "\""
        val id = wm.addNetwork(conf)
        if (id == -1) { onResult(false, "Wi-Fi ağı eklenemedi."); return }
        wm.disconnect(); wm.enableNetwork(id, true); wm.reconnect()
        onResult(true, "Bağlanılıyor…")
    }

    /** Android 11+: "Ağ ekle" penceresini açar; Kaydet'e dokununca telefon ağa kendisi bağlanır (tüm uygulamalar kullanır). */
    @RequiresApi(30)
    fun addNetworkIntent(ssid: String, pass: String): Intent {
        val sug = WifiNetworkSuggestion.Builder().setSsid(ssid).setWpa2Passphrase(pass).build()
        return Intent(Settings.ACTION_WIFI_ADD_NETWORKS).putParcelableArrayListExtra(Settings.EXTRA_WIFI_NETWORK_LIST, arrayListOf(sug))
    }

    @Suppress("DEPRECATION")
    fun connectedTo(ctx: Context, ssid: String): Boolean = runCatching {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        wm.isWifiEnabled && caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && wm.connectionInfo?.ssid?.trim('"') == ssid
    }.getOrDefault(false)

    /** Hotspot açık mı? Gizli API (yansıtma) ile okunur; Android sürümü izin vermezse null (bilinmiyor). */
    fun hotspotOn(ctx: Context): Boolean? = runCatching {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val m = WifiManager::class.java.getDeclaredMethod("isWifiApEnabled")
        m.isAccessible = true
        m.invoke(wm) as Boolean
    }.getOrNull()

    @Suppress("DEPRECATION")
    fun wifiOn(ctx: Context): Boolean = runCatching {
        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    }.getOrDefault(true)

    /** Wi-Fi kapalıyken kullanıcıyı açması için ilgili ayar paneline götürür (Android 10+ uygulamalar Wi-Fi'yi kendisi açamaz). */
    fun openWifiPanel(ctx: Context) {
        val i = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)
        runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun release(ctx: Context) {
        val c = cb ?: return
        cb = null
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        runCatching { cm.unregisterNetworkCallback(c) }
        runCatching { cm.bindProcessToNetwork(null) }
    }

    /** Sessiz sistem önerisi: pencere açmaz; kullanıcı onaylarsa telefon ağa kendisi (tüm uygulamalar için) bağlanır. */
    fun suggest(ctx: Context, ssid: String, pass: String): Boolean = runCatching {
        if (Build.VERSION.SDK_INT < 29) return@runCatching false
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val sug = WifiNetworkSuggestion.Builder().setSsid(ssid).setWpa2Passphrase(pass).setIsAppInteractionRequired(false).build()
        wm.removeNetworkSuggestions(emptyList())
        val st = wm.addNetworkSuggestions(listOf(sug))
        st == WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS || st == WifiManager.STATUS_NETWORK_SUGGESTIONS_ERROR_ADD_DUPLICATE
    }.getOrDefault(false)

    fun openWifiSettings(ctx: Context) {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun openHotspotSettings(ctx: Context) {
        val tries = listOf(
            Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
        )
        for (i in tries) { if (runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return }
    }
}
