package app.depremkalkani.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.depremkalkani.R
import app.depremkalkani.data.Notifs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.sqrt

/**
 * Telefonun ivmeölçeri ile yerel sarsıntı algılayıcı + canlı sismograf.
 * Yöntem: yüksek geçirgen süzgeç (yerçekimi çıkarılır) + STA/LTA oranı.
 * NOT: Tek telefonla yapılan algılama yanlış alarm verebilir (telefon düşse, masa sarsılsa).
 * Bu yüzden "olası sarsıntı" olarak sunulur; resmî deprem bilgisi AFAD/Kandilli'dendir.
 */
object SeismoEngine {
    val wave = MutableStateFlow(FloatArray(0))          // son ~10 sn (m/s²)
    val running = MutableStateFlow(false)
    val sta = MutableStateFlow(0f)
    val lta = MutableStateFlow(0f)
    val lastTrigger = MutableStateFlow(0L)
    val peak = MutableStateFlow(0f)
    val available = MutableStateFlow(true)

    private val users = HashSet<String>()
    private var sm: SensorManager? = null
    private var appCtx: Context? = null
    private val buf = FloatArray(500)
    private var pos = 0
    private val g = FloatArray(3)
    private var staV = 0f
    private var ltaV = 0.05f
    private var count = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var uiTick = 0

    @Synchronized
    fun acquire(ctx: Context, who: String) {
        users += who
        if (running.value) return
        appCtx = ctx.applicationContext
        sm = ctx.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val acc = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (acc == null) { available.value = false; return }
        sm?.registerListener(listener, acc, 20_000) // ~50 Hz
        running.value = true
        count = 0
    }

    @Synchronized
    fun release(who: String) {
        users -= who
        if (users.isEmpty() && running.value) {
            sm?.unregisterListener(listener)
            running.value = false
        }
    }

    private val listener = object : SensorEventListener {
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        override fun onSensorChanged(e: SensorEvent) {
            val a = 0.96f
            for (i in 0..2) g[i] = a * g[i] + (1 - a) * e.values[i]
            val x = e.values[0] - g[0]; val y = e.values[1] - g[1]; val z = e.values[2] - g[2]
            val amp = sqrt(x * x + y * y + z * z)
            buf[pos] = amp; pos = (pos + 1) % buf.size
            staV += (amp - staV) / 25f      // ~0,5 sn
            ltaV += (amp - ltaV) / 1500f    // ~30 sn
            count++
            if (amp > peak.value) peak.value = amp
            if (++uiTick % 5 == 0) {
                val out = FloatArray(buf.size) { buf[(pos + it) % buf.size] }
                wave.value = out; sta.value = staV; lta.value = ltaV
            }
            val now = System.currentTimeMillis()
            if (count > 1500 && staV > 0.45f && staV / maxOf(ltaV, 0.02f) > 6f && now - lastTrigger.value > 90_000) {
                lastTrigger.value = now
                handler.post { notifyShake() }
            }
        }
    }

    fun resetPeak() { peak.value = 0f }

    private fun notifyShake() {
        val c = appCtx ?: return
        if (!Notifs.canPost(c)) return
        val n = NotificationCompat.Builder(c, Notifs.CH_SHAKE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Sarsıntı algılandı!")
            .setContentText("Olası deprem. Güvendeysen \"Güvendeyim\" bildir; resmî bilgi için listeyi kontrol et.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(Notifs.openAppIntent(c))
            .build()
        runCatching { NotificationManagerCompat.from(c).notify(777, n) }
    }
}
