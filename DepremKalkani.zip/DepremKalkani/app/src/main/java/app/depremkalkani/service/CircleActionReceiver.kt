package app.depremkalkani.service

import kotlinx.coroutines.CoroutineExceptionHandler
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import app.depremkalkani.data.CType
import app.depremkalkani.data.Circles
import app.depremkalkani.dk
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Bildirimdeki "Güvendeyim" / "Yardım lazım" düğmeleri. */
class CircleActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        ctx.dk // uygulama nesnesini (Circles, Mesh) başlatır
        val type = runCatching { CType.valueOf(intent.getStringExtra("type") ?: "SAFE") }.getOrDefault(CType.SAFE)
        val id = intent.getStringExtra("member") ?: "all"
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO + CoroutineExceptionHandler { _, e -> android.util.Log.w("DK", "coroutine", e) }).launch {
            try {
                val targets = if (id == "all") Circles.members.value else Circles.members.value.filter { it.id == id }
                targets.forEach { Circles.sendTo(it, type, "") }
            } finally { pr.finish() }
        }
        NotificationManagerCompat.from(ctx).cancelAll()
    }
}
