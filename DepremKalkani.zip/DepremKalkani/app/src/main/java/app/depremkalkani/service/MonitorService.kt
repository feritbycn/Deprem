package app.depremkalkani.service

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import app.depremkalkani.R
import app.depremkalkani.dk
import app.depremkalkani.data.*
import app.depremkalkani.sensor.SeismoEngine
import kotlinx.coroutines.*
import java.util.Calendar

/**
 * Arka planda seçili kaynaklardan (AFAD, Kandilli, EMSC, USGS) veri çeker ve
 * kullanıcının bölge/büyüklük filtresine uyan YENİ depremler için bildirim gönderir.
 * Aracı sunucu gerekmez; bu yüzden telefonda kalıcı bildirimle (ön plan servisi) çalışır.
 */
class MonitorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        if (job?.isActive != true) {
            job = scope.launch { loop() }
            scope.launch { Circles.subscribeLoop() }
        }
        if (dk.prefs.shakeDetect) SeismoEngine.acquire(this, "svc")
        return START_STICKY
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, Notifs.CH_MONITOR)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Deprem Kalkanı çalışıyor")
            .setContentText("Depremler canlı takip ediliyor")
            .setOngoing(true)
            .setContentIntent(Notifs.openAppIntent(this))
            .build()

    private suspend fun loop() {
        val prefs = dk.prefs
        val repo = dk.repo
        var first = prefs.seenIds.isEmpty()
        while (currentCoroutineContext().isActive) {
            if (!prefs.monitorOn) { delay(10_000); continue }
            runCatching {
                LocationHelper.refresh(this@MonitorService)
                val list = repo.refresh(prefs.sources.ifEmpty { setOf(Sources.AFAD) })
                val seen = prefs.seenIds.toMutableSet()
                val now = System.currentTimeMillis()
                val fresh = list.filter { it.id !in seen && now - it.time < 45 * 60_000L }
                for (q in fresh.sortedBy { it.time }) {
                    seen += q.id
                    if (first) continue // ilk çalıştırmada eski depremler için bildirim yağdırma
                    if (QuakeRepository.matches(q, prefs) && allowedAtThisHour(q, prefs)) Notifs.notifyQuake(this@MonitorService, q, prefs)
                }
                // eski kayıtları da "görüldü" say
                list.forEach { seen += it.id }
                prefs.seenIds = seen.toList().takeLast(600).toSet()
                first = false
            }
            delay(prefs.pollSeconds * 1000)
        }
    }

    private fun allowedAtThisHour(q: Quake, p: Prefs): Boolean {
        if (!p.nightMode) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = h >= 23 || h < 7
        return !night || q.mag >= 5.0
    }

    override fun onDestroy() {
        Circles.stop(); job?.cancel(); scope.cancel()
        SeismoEngine.release("svc")
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "stop"
        fun start(ctx: Context) {
            val i = Intent(ctx, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, MonitorService::class.java)) }
    }
}
