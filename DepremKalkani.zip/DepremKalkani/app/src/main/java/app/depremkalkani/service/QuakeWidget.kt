package app.depremkalkani.service

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import app.depremkalkani.MainActivity
import app.depremkalkani.R
import app.depremkalkani.data.Prefs
import app.depremkalkani.data.Quake
import app.depremkalkani.data.QuakeRepository
import org.json.JSONArray
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ana ekran widget'ı: son depremler. Veriyi uygulamanın önbelleğinden (quakes.json) okur. */
class QuakeWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_REFRESH) {
            val pr = goAsync()
            Thread {
                runCatching { refreshNow(ctx) }
                update(ctx)
                pr.finish()
            }.start()
        }
    }

    companion object {
        const val ACTION_REFRESH = "app.depremkalkani.WIDGET_REFRESH"

        fun update(ctx: Context) {
            runCatching {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, QuakeWidget::class.java))
                if (ids.isEmpty()) return
                val rv = build(ctx)
                for (id in ids) mgr.updateAppWidget(id, rv)
            }
        }

        private fun refreshNow(ctx: Context) {
            val dk = ctx.applicationContext as? app.depremkalkani.DepremApp ?: return
            val p = Prefs(ctx)
            kotlinx.coroutines.runBlocking {
                dk.repo.refresh(p.sources.ifEmpty { setOf(app.depremkalkani.data.Sources.AFAD) })
            }
        }

        private fun load(ctx: Context): List<Quake> = runCatching {
            val f = File(ctx.filesDir, "quakes.json")
            if (f.exists()) Quake.listFromJson(JSONArray(f.readText())) else emptyList()
        }.getOrDefault(emptyList())

        private fun magColor(m: Double) = when {
            m >= 6.0 -> Color.parseColor("#FF1744")
            m >= 5.0 -> Color.parseColor("#FF5722")
            m >= 4.0 -> Color.parseColor("#FFA726")
            m >= 3.0 -> Color.parseColor("#FFD54F")
            else -> Color.parseColor("#9CCC65")
        }

        private fun ago(t: Long): String {
            val m = ((System.currentTimeMillis() - t) / 60_000L).coerceAtLeast(0)
            return when {
                m < 1 -> "şimdi"
                m < 60 -> "$m dk"
                m < 1440 -> "${m / 60} sa"
                else -> "${m / 1440} g"
            }
        }

        fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_quakes)
            val prefs = Prefs(ctx)
            val all = load(ctx).sortedByDescending { it.time }
            val mine = all.filter { runCatching { QuakeRepository.matches(it, prefs) }.getOrDefault(true) }
            val list = (if (mine.isNotEmpty()) mine else all).take(if (prefs.isPro) 5 else 3)
            val rowIds = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4)
            val magIds = intArrayOf(R.id.mag0, R.id.mag1, R.id.mag2, R.id.mag3, R.id.mag4)
            val placeIds = intArrayOf(R.id.place0, R.id.place1, R.id.place2, R.id.place3, R.id.place4)
            val agoIds = intArrayOf(R.id.ago0, R.id.ago1, R.id.ago2, R.id.ago3, R.id.ago4)
            for (i in 0 until 5) {
                val q = list.getOrNull(i)
                if (q == null) { rv.setViewVisibility(rowIds[i], 8); continue }
                rv.setViewVisibility(rowIds[i], 0)
                rv.setTextViewText(magIds[i], String.format(Locale.US, "%.1f", q.mag))
                rv.setTextColor(magIds[i], magColor(q.mag))
                rv.setTextViewText(placeIds[i], q.place)
                rv.setTextViewText(agoIds[i], ago(q.time))
            }
            rv.setViewVisibility(R.id.empty, if (list.isEmpty()) 0 else 8)
            rv.setTextViewText(R.id.upd, SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))

            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            rv.setOnClickPendingIntent(R.id.root, open)
            val ref = PendingIntent.getBroadcast(
                ctx, 1, Intent(ctx, QuakeWidget::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            rv.setOnClickPendingIntent(R.id.refresh, ref)
            return rv
        }
    }
}
