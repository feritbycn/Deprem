package app.depremkalkani.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.*
import androidx.core.app.NotificationCompat
import app.depremkalkani.R
import app.depremkalkani.dk
import app.depremkalkani.data.Notifs
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.mesh.MsgType
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

object RescueState {
    val active = MutableStateFlow(false)
    val whistle = MutableStateFlow(false)
    val flash = MutableStateFlow(false)
}

/**
 * Enkaz altı / acil durum modu: düdük (isteğe bağlı SON SES), flaş SOS ışığı,
 * titreşim ve yakındaki cihazlara periyodik SOS yayını. Ekran kapalıyken de çalışır.
 */
class RescueService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, e -> android.util.Log.w("DK", "coroutine", e) })
    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private var flashJob: Job? = null
    private var beaconJob: Job? = null
    private var savedAlarm = -1
    private var savedMusic = -1
    private var torchId: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopAll(); stopSelf(); return START_NOT_STICKY }
            else -> {
                val stop = PendingIntent.getService(this, 1, Intent(this, RescueService::class.java).setAction(ACTION_STOP),
                    PendingIntent.FLAG_IMMUTABLE)
                val n: Notification = NotificationCompat.Builder(this, Notifs.CH_RESCUE)
                    .setSmallIcon(R.drawable.ic_notif).setContentTitle("Acil durum modu AÇIK")
                    .setContentText("Düdük / flaş / SOS yayını çalışıyor").setOngoing(true)
                    .setContentIntent(Notifs.openAppIntent(this))
                    .addAction(0, "DURDUR", stop).build()
                if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                else startForeground(2, n)
                val whistle = intent?.getBooleanExtra(EXTRA_WHISTLE, true) ?: true
                val flash = intent?.getBooleanExtra(EXTRA_FLASH, true) ?: true
                val beacon = intent?.getBooleanExtra(EXTRA_BEACON, true) ?: true
                begin(whistle, flash, beacon)
            }
        }
        return START_NOT_STICKY
    }

    private fun begin(whistle: Boolean, flash: Boolean, beacon: Boolean) {
        stopAll(keepService = true)
        RescueState.active.value = true
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dk:rescue").apply { acquire(6 * 3600_000L) }
        if (whistle) startWhistle()
        if (flash) startFlash()
        if (beacon) startBeacon()
    }

    private fun startWhistle() {
        val prefs = dk.prefs
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (prefs.whistleMaxVolume) {
            savedAlarm = am.getStreamVolume(AudioManager.STREAM_ALARM)
            savedMusic = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            runCatching { am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0) }
            runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0) }
        }
        val res = if (prefs.whistleSos) R.raw.whistle_sos else R.raw.whistle
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            val afd = resources.openRawResourceFd(res)
            setDataSource(afd.fileDescriptor, afd.startOffset, afd.length); afd.close()
            isLooping = true
            setVolume(1f, 1f)
            prepare(); start()
        }
        RescueState.whistle.value = true
        vibrate()
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        val pattern = longArrayOf(0, 450, 350, 450, 350, 450, 2500)
        runCatching {
            if (Build.VERSION.SDK_INT >= 31) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                v.vibrate(VibrationEffect.createWaveform(pattern, 0))
            }
        }
    }

    private fun startFlash() {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        torchId = runCatching {
            cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        }.getOrNull()
        val id = torchId ?: return
        RescueState.flash.value = true
        flashJob = scope.launch {
            val u = 220L
            suspend fun on(ms: Long) { runCatching { cm.setTorchMode(id, true) }; delay(ms); runCatching { cm.setTorchMode(id, false) }; delay(u) }
            while (isActive) {
                repeat(3) { on(u) }; delay(u * 2)      // ...
                repeat(3) { on(u * 3) }; delay(u * 2)  // ---
                repeat(3) { on(u) }; delay(u * 8)      // ...
            }
        }
    }

    private fun startBeacon() {
        val prefs = dk.prefs
        Mesh.start()
        beaconJob = scope.launch {
            while (isActive) {
                LocationHelper.refresh(this@RescueService)
                val note = prefs.emergencyNote.take(80)
                Mesh.send(MsgType.SOS, "Enkaz altındayım, yardım edin! $note".trim())
                app.depremkalkani.data.Circles.members.value.forEach { app.depremkalkani.data.Circles.sendTo(it, app.depremkalkani.data.CType.SOS, note) }
                delay(20_000)
            }
        }
    }

    private fun stopAll(keepService: Boolean = false) {
        flashJob?.cancel(); beaconJob?.cancel()
        torchId?.let { id -> runCatching { (getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(id, false) } }
        runCatching { player?.stop(); player?.release() }; player = null
        runCatching {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (savedAlarm >= 0) am.setStreamVolume(AudioManager.STREAM_ALARM, savedAlarm, 0)
            if (savedMusic >= 0) am.setStreamVolume(AudioManager.STREAM_MUSIC, savedMusic, 0)
        }
        savedAlarm = -1; savedMusic = -1
        runCatching { if (wake?.isHeld == true) wake?.release() }
        runCatching {
            if (Build.VERSION.SDK_INT >= 31) (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator.cancel()
            else @Suppress("DEPRECATION") (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel()
        }
        RescueState.active.value = false; RescueState.whistle.value = false; RescueState.flash.value = false
    }

    override fun onDestroy() { stopAll(); scope.cancel(); super.onDestroy() }

    companion object {
        const val ACTION_STOP = "stop"
        const val EXTRA_WHISTLE = "whistle"; const val EXTRA_FLASH = "flash"; const val EXTRA_BEACON = "beacon"
        fun start(ctx: Context, whistle: Boolean, flash: Boolean, beacon: Boolean) {
            val i = Intent(ctx, RescueService::class.java)
                .putExtra(EXTRA_WHISTLE, whistle).putExtra(EXTRA_FLASH, flash).putExtra(EXTRA_BEACON, beacon)
            ctx.startForegroundService(i)
        }
        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, RescueService::class.java).setAction(ACTION_STOP))
        }
    }
}
