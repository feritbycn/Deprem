package app.depremkalkani.ui

import android.graphics.Color as AColor
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.core.app.NotificationManagerCompat
import app.depremkalkani.data.*
import kotlinx.coroutines.delay
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.util.Locale
import kotlin.math.log10
import kotlin.math.max

private const val S_WAVE_KMS = 3.5   // S dalgası ~3,5 km/sn (kabuk ortalaması)

/**
 * Tam ekran sismik dalga uyarısı: yıldız = merkez üssü, kırmızı daire = S dalgasının şu an ulaştığı yarıçap,
 * mavi nokta = sen. Geri sayım mesafe/hızdan HESAPLANIR (tahmindir); sarsıntı şiddeti kaba bir kestirimdir.
 */
@Composable
fun AlertScreen(q: Quake, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(250) } }

    val dist = Geo.distanceFromMe(q)
    val elapsed = (now - q.time) / 1000.0
    val radiusKm = max(0.0, elapsed * S_WAVE_KMS)
    val remaining = dist?.let { max(0, Math.round(it / S_WAVE_KMS - elapsed).toInt()) }
    val score = dist?.let { q.mag - 1.8 * log10(max(it, 5.0)) }
    val (intensity, intensityColor) = when {
        score == null -> "Konumun bilinmiyor" to Color(0xFFB0B8D8)
        score >= 3.0 -> "Şiddetli sarsıntı bekleyin" to Color(0xFFFF4D4D)
        score >= 2.0 -> "Orta şiddette sarsıntı bekleyin" to Color(0xFFFFA726)
        score >= 1.0 -> "Hafif sarsıntı bekleyin" to Color(0xFFFFD54F)
        else -> "Hafif veya hiç titreme beklemeyin" to Color(0xFF4CAF50)
    }
    val dir = if (dist != null && Geo.known) Geo.compass(Geo.bearingDeg(Geo.lat!!, Geo.lon!!, q.lat, q.lon)) else null

    val view = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true)
            overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS) // koyu harita
            controller.setZoom(8.0); controller.setCenter(GeoPoint(q.lat, q.lon))
        }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) view.onResume() else if (e == Lifecycle.Event.ON_PAUSE) view.onPause()
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); view.onPause(); view.onDetach() }
    }

    // sabit katman: yıldız, ben, çizgi — ilk çizimde zoom'u iki noktayı kapsayacak şekilde ayarla
    LaunchedEffect(q.id) {
        if (Geo.known) {
            val box = org.osmdroid.util.BoundingBox.fromGeoPoints(listOf(GeoPoint(q.lat, q.lon), GeoPoint(Geo.lat!!, Geo.lon!!)))
            view.post { runCatching { view.zoomToBoundingBox(box.increaseByScale(2.2f), false) } }
        }
    }
    LaunchedEffect(radiusKm, Geo.known) {
        view.overlays.clear()
        val c = GeoPoint(q.lat, q.lon)
        if (Geo.known) view.overlays += Polyline(view).apply {
            setPoints(listOf(GeoPoint(Geo.lat!!, Geo.lon!!), c)); outlinePaint.color = AColor.parseColor("#FF3B30"); outlinePaint.strokeWidth = 4f
        }
        view.overlays += Polygon(view).apply {
            points = Polygon.pointsAsCircle(c, radiusKm * 1000.0)
            fillPaint.color = AColor.argb(70, 160, 0, 30)
            outlinePaint.color = AColor.parseColor("#FF1E1E"); outlinePaint.strokeWidth = 7f
        }
        view.overlays += Marker(view).apply {
            position = c; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            icon = androidx.core.content.ContextCompat.getDrawable(ctx, app.depremkalkani.R.drawable.ic_star_epicenter)
            title = "M%.1f  %s".format(Locale.US, q.mag, q.place)
        }
        if (Geo.known) view.overlays += Marker(view).apply {
            position = GeoPoint(Geo.lat!!, Geo.lon!!); setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER); title = "Sen"
            icon = ShapeDrawable(OvalShape()).apply {
                val px = (18 * ctx.resources.displayMetrics.density).toInt(); intrinsicWidth = px; intrinsicHeight = px
                paint.color = AColor.parseColor("#3D7BFF")
            }
        }
        view.invalidate()
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0A0F1F)).systemBarsPadding()) {
        Column(
            Modifier.fillMaxWidth().background(Color(0xFF10151F)).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Deprem M%.1f (tahmini) • %s".format(Locale.US, q.mag, q.place) +
                    (dist?.let { ". Sana ${fmtDist(it)} uzaklıkta" + (dir?.let { d -> ", yön: $d" } ?: "") } ?: ""),
                color = Color(0xFFE6E9F5), fontSize = 17.sp, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                when {
                    remaining == null -> "Konum alınamadı"
                    remaining <= 0 -> "Sismik dalga ulaştı"
                    else -> "$remaining saniyede sismik dalga"
                },
                color = Color(0xFFFF2D2D), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            Text(intensity, color = intensityColor, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text("Kestirim: büyüklük ve mesafeden hesaplanır, gerçek sarsıntıyı garanti etmez.", color = Color(0xFF8E9ABF), fontSize = 11.sp, textAlign = TextAlign.Center)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView({ view }, Modifier.fillMaxSize())
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFF10151F)).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton({
                NotificationManagerCompat.from(ctx).cancel(q.id.hashCode()); onClose()
            }, Modifier.weight(1f), shape = RoundedCornerShape(28.dp)) { Text("Alarmı durdur", maxLines = 1) }
            FilledTonalButton(onClose, Modifier.weight(1f), shape = RoundedCornerShape(28.dp)) { Text("Çıkış") }
            FilledTonalButton({ Share.text(ctx, Share.quakeText(q)) }, Modifier.weight(1f), shape = RoundedCornerShape(28.dp)) { Text("Paylaş") }
        }
    }
}
