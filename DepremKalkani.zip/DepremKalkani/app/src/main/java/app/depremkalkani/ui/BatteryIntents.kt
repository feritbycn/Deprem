package app.depremkalkani.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Pil kısıtlamasını kaldırma yolu. Bazı telefonlarda genel "Pil optimizasyonu" listesi uygulamayı hiç göstermez;
 * bu yüzden önce doğrudan "Bu uygulama için izin ver" penceresi, olmazsa liste, o da olmazsa uygulama bilgi sayfası açılır.
 */
object BatteryIntents {
    fun best(ctx: Context): Intent {
        val pkg = Uri.parse("package:${ctx.packageName}")
        val options = listOf(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg),
        )
        return options.firstOrNull { it.resolveActivity(ctx.packageManager) != null } ?: options.last()
    }

    /** Listeyi de aç (kullanıcı elle bakmak isterse). */
    fun list(): Intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
}
