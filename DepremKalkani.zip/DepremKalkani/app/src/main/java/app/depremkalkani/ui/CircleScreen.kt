package app.depremkalkani.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.data.*
import app.depremkalkani.dk
import app.depremkalkani.service.MonitorService
import kotlinx.coroutines.launch

@Composable
fun CircleScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val scope = rememberCoroutineScope()
    val members by Circles.members.collectAsState()
    val events by Circles.events.collectAsState()
    val smsPerm = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {}
    val isPro by ctx.dk.billing.isPro.collectAsState()
    var smsAsk by remember { mutableStateOf(false) }
    var limitDlg by remember { mutableStateOf(false) }
    var inviteNameDlg by remember { mutableStateOf(false) }
    var inviteDlg by remember { mutableStateOf<String?>(null) }
    var addDlg by remember { mutableStateOf(false) }
    var editDlg by remember { mutableStateOf<Member?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    var server by remember { mutableStateOf(prefs.sp.getString("circle_server", "https://ntfy.sh") ?: "https://ntfy.sh") }
    var nick by remember { mutableStateOf(prefs.nick) }

    var refreshing by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { runCatching { Circles.pollNow() }; kotlinx.coroutines.delay(5000) } }
    PullToRefreshBox(isRefreshing = refreshing, onRefresh = { refreshing = true; scope.launch { kotlinx.coroutines.delay(900); refreshing = false }; scope.launch { runCatching { Circles.syncNow() } } }, modifier = Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Yakınlarım", style = MaterialTheme.typography.headlineLarge)
        PermBanner("notif", "Bildirim izni kapalı: yakınlarının mesajlarını ve \"Güvendeyim\" bildirimlerini göremezsin.", Perms.notification,
            { Perms.notification.isEmpty() || Perms.has(ctx, Perms.notification) })
        if (isPro && members.any { it.phone.isNotBlank() }) PermBanner("sms", "SMS izni kapalı: internet ve yakın cihaz yokken yakınlarına SMS gönderemem.", arrayOf(android.Manifest.permission.SEND_SMS),
            { Perms.has(ctx, arrayOf(android.Manifest.permission.SEND_SMS)) })
        Text("Aile ve tanıdıklarını ekle. Deprem olunca tek dokunuşla \"Güvendeyim\" de ya da onlara \"Güvende misin?\" sor; cevap bildirim olarak gelir.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (members.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Hepsine: Güvendeyim", { Circles.sendAll(CType.SAFE, "Güvendeyim"); msg = "Gönderiliyor…"; toast(ctx, "Yakınlarına gönderildi ✓ (internet yoksa sıraya alındı)") }, Modifier.weight(1f), color = DK.Teal)
                BigButton("Hepsine: Güvende misin?", { Circles.sendAll(CType.CHECK); msg = "Soru gönderiliyor…"; toast(ctx, "\"Güvende misin?\" sorusu gönderildi ✓") }, Modifier.weight(1f), outlined = true)
            }
            BigButton("Hepsine: Yardım lazım", { Circles.sendAll(CType.HELP, "Yardım lazım"); msg = "Gönderiliyor…"; toast(ctx, "Yakınlarına gönderildi ✓ (internet yoksa sıraya alındı)") }, color = DK.Danger, outlined = true)
        }
        msg?.let { Text(it, color = DK.Teal, fontSize = 13.sp) }

        if (members.isEmpty()) Card2 {
            Text("Henüz kimse ekli değil", style = MaterialTheme.typography.titleMedium)
            Text("1) \"Davet kodu oluştur\"a bas, kodu WhatsApp/SMS ile gönder.\n2) Karşı taraf uygulamada \"Kodla ekle\" der.\n3) Bağlandığınızda birbirinizin durumunu görürsünüz. Bunu afetten ÖNCE, internet varken yap.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        members.forEach { m -> MemberCard(m, onEdit = { editDlg = m }) }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("Davet kodu oluştur", { if (!isPro && members.size >= 3) limitDlg = true else inviteNameDlg = true }, Modifier.weight(1f))
            BigButton("Kodla ekle", { if (!isPro && members.size >= 3) limitDlg = true else addDlg = true }, Modifier.weight(1f), outlined = true)
        }

        if (members.isNotEmpty()) ProvinceShareCard(members)

        if (events.isNotEmpty()) {
            SectionTitle("Son hareketler")
            Card2 {
                events.takeLast(15).reversed().forEach { e ->
                    Text((if (e.mine) "Sen, ${e.name} kişisine: " else "${e.name}: ") + e.type.label + (if (e.text.isNotBlank() && e.type == CType.TEXT) " • ${e.text}" else "") + "  (${Notifs.ago(e.ts)})",
                        fontSize = 13.sp, modifier = Modifier.padding(vertical = 3.dp))
                }
            }
        }

        Card2 {
            Text("Nasıl iletilir?", style = MaterialTheme.typography.titleMedium)
            Text("• İnternet varken: şifreli mesaj bir aktarma sunucusu (varsayılan ntfy.sh) üzerinden karşı telefona gider.\n" +
                "• İnternet yokken: Yakındakiler taraması açıksa, yakındaki Deprem Kalkanı telefonları üzerinden zincirleme gider.\n" +
                "• Her yolda mesaj, davet kodundaki anahtarla şifrelenir; sunucu içeriği okuyamaz.\n" +
                "• Karşı telefonda uygulamanın canlı takip servisi çalışmalı (Ayarlar › Canlı bildirim açık, pil kısıtlaması kapalı).\n" +
                "• İkisi de olmazsa kişi kartındaki SMS düğmesini kullan.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(nick, { nick = it; prefs.nick = it }, label = { Text("Adın (yakınların görür)") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            OutlinedTextField(server, { server = it; prefs.sp.edit().putString("circle_server", it).apply() },
                label = { Text("Aktarma sunucusu (ntfy)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }
    }

    if (limitDlg) AlertDialog(onDismissRequest = { limitDlg = false }, title = { Text("Yakın sınırı") },

        text = { Text("Ücretsiz sürümde en fazla 3 yakın eklenebilir. Pro ile sınırsız yakın ekleyebilirsin. Mevcut yakınların her zaman çalışmaya devam eder.") },

        confirmButton = { TextButton({ limitDlg = false }) { Text("Tamam") } })

    if (smsAsk) ExplainDialog("SMS izni", "İnternet ve yakın cihaz yokken yakınlarına acil durum SMS'i gönderebilmek için (Pro özelliği). Sadece sen mesaj gönderdiğinde ve başka yol kalmadığında kullanılır.",

        onOk = { smsAsk = false; smsPerm.launch(android.Manifest.permission.SEND_SMS) }, onCancel = { smsAsk = false })

    if (inviteNameDlg) {
        var rel by remember { mutableStateOf("") }
        var ph by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { inviteNameDlg = false },
            title = { Text("Kimi ekliyorsun?") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RelationField(rel) { rel = it }
                OutlinedTextField(ph, { ph = it }, label = { Text("Telefonu (internet yoksa SMS ile ulaşır)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            } },
            confirmButton = { TextButton({
                val (mm, code) = Circles.createInvite(rel.trim().ifBlank { "Davet bekliyor" }); inviteDlg = code
                if (ph.isNotBlank()) Circles.rename(mm.id, mm.name, ph)
                if (ph.isNotBlank() && !Perms.has(ctx, arrayOf(android.Manifest.permission.SEND_SMS))) smsAsk = true
                inviteNameDlg = false; MonitorService.start(ctx)
            }) { Text("Kod oluştur") } },
            dismissButton = { TextButton({ inviteNameDlg = false }) { Text("Vazgeç") } })
    }

    inviteDlg?.let { code ->
        AlertDialog(onDismissRequest = { inviteDlg = null },
            title = { Text("Davet kodu") },
            text = {
                Column {
                    Text("Bu kodu yalnızca eklemek istediğin kişiye gönder. Kodu bilen herkes mesajlarınızı okuyabilir.", fontSize = 13.sp)
                    Text(code, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp), fontWeight = FontWeight.Medium)
                }
            },
            confirmButton = { TextButton({ Share.text(ctx, "Deprem Kalkanı yakın daveti. Uygulamada Yakınlarım › Kodla ekle:\n$code") }) { Text("Paylaş") } },
            dismissButton = { TextButton({
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("kod", code)); inviteDlg = null
            }) { Text("Kopyala") } })
    }

    if (addDlg) {
        var code by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        var rel by remember { mutableStateOf("") }
        var ph2 by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { addDlg = false },
            title = { Text("Kodla ekle") },
            text = { Column {
                OutlinedTextField(code, { code = it }, label = { Text("Davet kodu (DK1.…)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                RelationField(rel) { rel = it }
                OutlinedTextField(ph2, { ph2 = it }, label = { Text("Telefonu (internet yoksa SMS ile ulaşır)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            } },
            confirmButton = { TextButton({
                scope.launch {
                    val r = Circles.acceptInvite(code, rel, ph2)
                    if (r == null) { addDlg = false; MonitorService.start(ctx); msg = "Eklendi. Karşı tarafa bağlandığını bildirdik." } else err = r
                }
            }) { Text("Ekle") } },
            dismissButton = { TextButton({ addDlg = false }) { Text("Vazgeç") } })
    }

    editDlg?.let { m ->
        var n by remember { mutableStateOf(m.name) }
        var ph by remember { mutableStateOf(m.phone) }
        var mp by remember { mutableStateOf(m.manualProv) }
        var provDlg by remember { mutableStateOf(false) }
        if (provDlg) AlertDialog(onDismissRequest = { provDlg = false }, title = { Text("Bulunduğu il") },
            text = { androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(TURKEY_PROVINCES.size) { i -> val p = TURKEY_PROVINCES[i]
                    TextButton({ mp = p; provDlg = false }, Modifier.fillMaxWidth()) { Text(p, Modifier.fillMaxWidth()) } }
            } },
            confirmButton = { TextButton({ provDlg = false }) { Text("Kapat") } },
            dismissButton = { TextButton({ mp = ""; provDlg = false }) { Text("Temizle") } })
        AlertDialog(onDismissRequest = { editDlg = null },
            title = { Text("Kişiyi düzenle") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text("İsim / yakınlık (Anne, Baba, Ayşe…)") }, singleLine = true)
                OutlinedTextField(ph, { ph = it }, label = { Text("Telefon (SMS yedeği için)") }, singleLine = true)
                OutlinedButton({ provDlg = true }, Modifier.fillMaxWidth()) { Text(if (mp.isBlank()) "Bulunduğu ili elle seç" else "Bulunduğu il: $mp") }
                Text("Kişi ilini paylaşırsa paylaştığı il önceliklidir; paylaşmıyorsa buradaki il kullanılır.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton({ Circles.remove(m.id); editDlg = null }) { Text("Kişiyi sil", color = MaterialTheme.colorScheme.error) }
            } },
            confirmButton = { TextButton({ Circles.rename(m.id, n, ph); Circles.setManualProv(m.id, mp); editDlg = null }) { Text("Kaydet") } },
            dismissButton = { TextButton({ editDlg = null }) { Text("Kapat") } })
    }
}

@Composable
private fun MemberCard(m: Member, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val (label, color) = when (m.status) {
        CType.SAFE -> "Güvende ✓ • ${Notifs.ago(m.statusTs)}" to DK.Teal
        CType.HELP -> "YARDIM İSTİYOR • ${Notifs.ago(m.statusTs)}" to DK.Accent2
        CType.SOS -> "ENKAZ ALTINDA • ${Notifs.ago(m.statusTs)}" to DK.Danger
        else -> if (m.lastAsked > 0) "Yanıt bekleniyor • sordun: ${Notifs.ago(m.lastAsked)}" to MaterialTheme.colorScheme.onSurfaceVariant
                else (if (m.connected) "Bağlı" else "Davet bekleniyor") to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card2(onClick = onEdit) {
        Text(m.name, style = MaterialTheme.typography.titleMedium)
        Text(label, color = color, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(if (m.prov.isNotBlank()) "📍 ${m.prov}" + (if (m.theirProv.isBlank()) " (elle yazdın)" else " (paylaştı)") else "📍 İl bilgisi yok",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            OutlinedButton({ Circles.send(m, CType.CHECK); toast(ctx, "${m.name} kişisine soru gönderildi ✓") }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Güvende misin?", fontSize = 12.sp, maxLines = 1) }
            Button({ Circles.send(m, CType.SAFE, "Güvendeyim"); toast(ctx, "${m.name} kişisine \"Güvendeyim\" gönderildi ✓") }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DK.Teal, contentColor = Color(0xFF00201C))) { Text("Güvendeyim", fontSize = 12.sp, maxLines = 1) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (m.lat != null && m.lon != null) TextButton({ Share.geo(ctx, m.lat, m.lon, m.name) }) {
                val d = Geo.distanceFromMe(m.lat, m.lon)
                Text("Son konumu aç" + (d?.let { " (~${fmtDist(it)})" } ?: ""), fontSize = 12.sp)
            }
            if (m.phone.isNotBlank()) TextButton({ Share.sms(ctx, listOf(m.phone), Share.myStatusText(prefs, "Güvendeyim")) }) { Text("SMS ile haber ver", fontSize = 12.sp) }
        }
    }
}

/** İsim ya da yakınlık yazılır; hızlı seçim düğmeleri de var. */
@Composable
fun RelationField(value: String, onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(value, onChange, label = { Text("İsim veya yakınlık (Anne, Baba, Ayşe…)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Anne", "Baba", "Eşim", "Kardeşim", "Çocuğum", "Dedem", "Babaanne", "Anneanne", "Arkadaşım").forEach { r ->
                AssistChip({ onChange(r) }, { Text(r) })
            }
        }
    }
}


/** "Konumunu kimler görüyor": yalnızca il adı paylaşılır; kişi başına aç/kapat, kaldır ve genel otomatik onay. */
@Composable
private fun ProvinceShareCard(members: List<Member>) {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    var auto by remember { mutableStateOf(prefs.shareProvAuto) }
    var qMag by remember { mutableFloatStateOf(prefs.circleQuakeMag) }
    val watching = members.count { it.shareWith }
    Card2 {
        Text("Konumunu kimler görüyor", style = MaterialTheme.typography.titleMedium)
        Text(if (watching == 0) "Şu an hiçbir yakının ilini görmüyor." else "$watching yakının bulunduğun ili görüyor. Tam konum değil, yalnızca il adı paylaşılır.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        members.filter { it.incomingReq }.forEach { m ->
            Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text("${m.name} ilini görmek istiyor", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ Circles.setShare(m.id, true) }) { Text("Paylaş") }
                    TextButton({ Circles.declineRequest(m.id) }) { Text("Şimdi değil") }
                }
            }
        }

        members.forEach { m ->
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(m.name, Modifier.weight(1f))
                if (m.shareWith || m.incomingReq) TextButton({ Circles.removeWatcher(m.id) }) { Text("Kaldır", fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
                Switch(m.shareWith, { Circles.setShare(m.id, it) })
            }
        }

        SwitchRow("İl bilgisini yakınlarımla paylaş", "Açıksa yakınlarının istekleri sorulmadan onaylanır. Kapalıysa (önerilen) her istekte sen karar verirsin.", auto) {
            auto = it; prefs.shareProvAuto = it
            if (it) Circles.approveAllPending()
        }
        if (watching > 0 || members.any { it.incomingReq }) OutlinedButton({ Circles.shareNone(); auto = false }, Modifier.fillMaxWidth()) { Text("Hiçbiriyle paylaşma") }

        Text("Yakınlarımın ilinde deprem olunca bildir: en az M${"%.1f".format(java.util.Locale.US, qMag)}", modifier = Modifier.padding(top = 8.dp), fontSize = 13.sp)
        Slider(qMag, { qMag = Math.round(it * 2) / 2f; prefs.circleQuakeMag = qMag }, valueRange = 2f..6f, steps = 7)
        Text("Kapatınca yeni il bilgisi gitmez; daha önce gönderilen il karşı telefonda kalabilir. Bir yakının ilini paylaşmıyorsa kişi kartından ili elle seçebilirsin.",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
