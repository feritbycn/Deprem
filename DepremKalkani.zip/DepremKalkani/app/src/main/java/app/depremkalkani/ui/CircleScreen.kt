package app.depremkalkani.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.data.*
import app.depremkalkani.dk
import app.depremkalkani.service.MonitorService
import kotlinx.coroutines.launch

@Composable
fun CircleScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val scope = rememberCoroutineScope()
    val members by Circles.members.collectAsState()
    val events by Circles.events.collectAsState()
    val smsPerm = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {}
    val isPro by ctx.dk.billing.isPro.collectAsState()
    var smsAsk by remember { mutableStateOf(false) }
    var limitDlg by remember { mutableStateOf(false) }
    var inviteNameDlg by remember { mutableStateOf(false) }
    var inviteDlg by remember { mutableStateOf<String?>(null) }
    var addDlg by remember { mutableStateOf(false) }
    var groupDlg by remember { mutableStateOf(false) }
    var kindDlg by remember { mutableStateOf(false) }
    var scanCode by remember { mutableStateOf("") }
    var addKindDlg by remember { mutableStateOf(false) }
    var useQr by remember { mutableStateOf(true) }          // davet şekli: QR kod mu, sadece kod mu
    var inviteShowQr by remember { mutableStateOf(true) }
    var editDlg by remember { mutableStateOf<Member?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    var server by remember { mutableStateOf(prefs.sp.getString("circle_server", "https://ntfy.sh") ?: "https://ntfy.sh") }
    var nick by remember { mutableStateOf(prefs.nick) }

    var refreshing by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { runCatching { Circles.pollNow() }; kotlinx.coroutines.delay(5000) } }
    PullToRefreshBox(isRefreshing = refreshing, onRefresh = { refreshing = true; scope.launch { kotlinx.coroutines.delay(900); refreshing = false }; scope.launch { runCatching { Circles.syncNow() } } }, modifier = Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Yakınlarım", style = MaterialTheme.typography.headlineLarge)
        PermBanner("notif", "Bildirim izni kapalı: yakınlarının mesajlarını ve \"Güvendeyim\" bildirimlerini göremezsin.", Perms.notification,
            { Perms.notification.isEmpty() || Perms.has(ctx, Perms.notification) })
        if (isPro && members.any { it.phone.isNotBlank() }) PermBanner("sms", "SMS izni kapalı: internet ve yakın cihaz yokken yakınlarına SMS gönderemem.", arrayOf(android.Manifest.permission.SEND_SMS),
            { Perms.has(ctx, arrayOf(android.Manifest.permission.SEND_SMS)) })
        Text("Aile ve tanıdıklarını ekle. Deprem olunca tek dokunuşla \"Güvendeyim\" de ya da onlara \"Güvende misin?\" sor; cevap bildirim olarak gelir.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (members.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton("Hepsine: Güvendeyim", { Circles.sendAll(CType.SAFE, "Güvendeyim"); msg = "Gönderiliyor…"; toast(ctx, "Yakınlarına gönderildi ✓ (internet yoksa sıraya alındı)") }, Modifier.weight(1f), color = DK.Teal)
                BigButton("Hepsine: Güvende misin?", { Circles.sendAll(CType.CHECK); msg = "Soru gönderiliyor…"; toast(ctx, "\"Güvende misin?\" sorusu gönderildi ✓") }, Modifier.weight(1f), outlined = true)
            }
            BigButton("Hepsine: Yardım lazım", { Circles.sendAll(CType.HELP, "Yardım lazım"); msg = "Gönderiliyor…"; toast(ctx, "Yakınlarına gönderildi ✓ (internet yoksa sıraya alındı)") }, color = DK.Danger, outlined = true)
        }
        msg?.let { Text(it, color = DK.Teal, fontSize = 13.sp) }

        if (members.isEmpty()) Card2 {
            Text("Henüz kimse ekli değil", style = MaterialTheme.typography.titleMedium)
            Text("1) \"Davet kodu oluştur\"a bas, kodu WhatsApp/SMS ile gönder. Kalabalık aile için \"Grup oluştur\" ile tek kod, herkes aynı mesajları görür.\n2) Karşı taraf uygulamada \"Kodla ekle\" der.\n3) Bağlandığınızda birbirinizin durumunu görürsünüz. Bunu afetten ÖNCE, internet varken yap.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        members.forEach { m ->
            if (m.group) GroupCard(m, events, onEdit = { editDlg = m }, onShare = { inviteDlg = Circles.groupCode(m) })
            else MemberCard(m, onEdit = { editDlg = m })
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("Davet oluştur", { if (!isPro && members.size >= 3) limitDlg = true else kindDlg = true }, Modifier.weight(1f))
            BigButton("Kodla ekle", { if (!isPro && members.size >= 3) limitDlg = true else addKindDlg = true }, Modifier.weight(1f), outlined = true)
        }

        if (members.any { !it.group }) ProvinceShareCard(members.filter { !it.group })

        if (events.isNotEmpty()) {
            SectionTitle("Son hareketler")
            Card2 {
                events.takeLast(15).reversed().forEach { e ->
                    Text((if (e.mine) "Sen, ${e.name} kişisine: " else "${e.name}: ") + e.type.label + (if (e.text.isNotBlank() && e.type == CType.TEXT) " • ${e.text}" else "") + "  (${Notifs.ago(e.ts)})",
                        fontSize = 13.sp, modifier = Modifier.padding(vertical = 3.dp))
                }
            }
        }

        Card2 {
            Text("Nasıl iletilir?", style = MaterialTheme.typography.titleMedium)
            Text("• İnternet varken: şifreli mesaj bir aktarma sunucusu (varsayılan ntfy.sh) üzerinden karşı telefona gider.\n" +
                "• İnternet yokken: Yakındakiler taraması açıksa, yakındaki Deprem Kalkanı telefonları üzerinden zincirleme gider.\n" +
                "• Her yolda mesaj, davet kodundaki anahtarla şifrelenir; sunucu içeriği okuyamaz.\n" +
                "• Karşı telefonda uygulamanın canlı takip servisi çalışmalı (Ayarlar › Canlı bildirim açık, pil kısıtlaması kapalı).\n" +
                "• İkisi de olmazsa kişi kartındaki SMS düğmesini kullan.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(nick, { nick = it; prefs.nick = it }, label = { Text("Adın (yakınların görür)") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            OutlinedTextField(server, { server = it; prefs.sp.edit().putString("circle_server", it).apply() },
                label = { Text("Aktarma sunucusu (ntfy)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }
    }

    if (limitDlg) AlertDialog(onDismissRequest = { limitDlg = false }, title = { Text("Yakın sınırı") },

        text = { Text("Ücretsiz sürümde en fazla 3 yakın eklenebilir. Pro ile sınırsız yakın ekleyebilirsin. Mevcut yakınların her zaman çalışmaya devam eder.") },

        confirmButton = { TextButton({ limitDlg = false }) { Text("Tamam") } })

    if (smsAsk) ExplainDialog("SMS izni", "İnternet ve yakın cihaz yokken yakınlarına acil durum SMS'i gönderebilmek için (Pro özelliği). Sadece sen mesaj gönderdiğinde ve başka yol kalmadığında kullanılır.",

        onOk = { smsAsk = false; smsPerm.launch(android.Manifest.permission.SEND_SMS) }, onCancel = { smsAsk = false })

    if (inviteNameDlg) {
        var rel by remember { mutableStateOf("") }
        var ph by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { inviteNameDlg = false },
            title = { Text("Kimi ekliyorsun?") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RelationField(rel) { rel = it }
                OutlinedTextField(ph, { ph = it }, label = { Text("Telefonu (internet yoksa SMS ile ulaşır)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Davet şekli", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(useQr, { useQr = true }, label = { Text("QR kod ile") })
                    FilterChip(!useQr, { useQr = false }, label = { Text("Sadece kod") })
                }
            } },
            confirmButton = { TextButton({
                val (mm, code) = Circles.createInvite(rel.trim().ifBlank { "Davet bekliyor" }); inviteShowQr = useQr; inviteDlg = code
                if (ph.isNotBlank()) Circles.rename(mm.id, mm.name, ph)
                if (ph.isNotBlank() && !Perms.has(ctx, arrayOf(android.Manifest.permission.SEND_SMS))) smsAsk = true
                inviteNameDlg = false; MonitorService.start(ctx)
            }) { Text("Oluştur") } },
            dismissButton = { TextButton({ inviteNameDlg = false }) { Text("Vazgeç") } })
    }

    inviteDlg?.let { code ->
        AlertDialog(onDismissRequest = { inviteDlg = null },
            title = { Text("Davet kodu") },
            text = {
                Column {
                    Text(if (code.startsWith("DKG1")) "Bu grup kodunu alan HERKES grubun tüm mesajlarını okur ve yazar. Yalnızca güvendiğin kişilere gönder. Kod yanlış kişiye giderse grup kartından kodu yenileyebilirsin."
                         else "Bu kodu yalnızca eklemek istediğin kişiye gönder. Kodu bilen herkes mesajlarınızı okuyabilir.", fontSize = 13.sp)
                    if (inviteShowQr) {
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.Center) { QrImage(code) }
                        Text("Karşı taraf Yakınlarım > Kodla ekle > QR kodu okut diyerek bunu okutabilir.", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    Text(code, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp), fontWeight = FontWeight.Medium)
                }
            },
            confirmButton = { TextButton({ Share.text(ctx, (if (code.startsWith("DKG1")) "Deprem Kalkanı grup daveti." else "Deprem Kalkanı yakın daveti.") + " Uygulamada Yakınlarım, Kodla ekle:\n$code") }) { Text("Paylaş") } },
            dismissButton = { TextButton({
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("kod", code)); inviteDlg = null
            }) { Text("Kopyala") } })
    }

    if (addKindDlg) AlertDialog(onDismissRequest = { addKindDlg = false }, title = { Text("Nasıl eklemek istersin?") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Karşı taraf sana QR kod gösteriyorsa kamerayla okut. Kodu mesajla aldıysan yapıştır.", fontSize = 13.sp)
            BigButton("QR kodu okut", {
                addKindDlg = false
                scanInviteQr(ctx, { v -> scanCode = v; addDlg = true }, { m -> msg = m })
            }, color = DK.Teal)
            BigButton("Kodu yapıştır", { addKindDlg = false; scanCode = ""; addDlg = true }, outlined = true)
        } },
        confirmButton = {}, dismissButton = { TextButton({ addKindDlg = false }) { Text("Vazgeç") } })

    if (kindDlg) AlertDialog(onDismissRequest = { kindDlg = false }, title = { Text("Kimi davet ediyorsun?") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Tek kişi: yalnızca o kişiyle özel, şifreli bir kanal kurulur.\nGrup: aileni, akrabalarını ya da arkadaşlarını tek bağlantıyla toplarsın; herkes aynı mesajları görür.", fontSize = 13.sp)
            BigButton("Tek kişi", { kindDlg = false; inviteNameDlg = true })
            BigButton("Grup", { kindDlg = false; groupDlg = true }, outlined = true)
        } },
        confirmButton = {}, dismissButton = { TextButton({ kindDlg = false }) { Text("Vazgeç") } })

    if (groupDlg) {
        var gname by remember { mutableStateOf("") }
        val limits = if (isPro) listOf(5, 10, 20) else listOf(3, 5)
        var glimit by remember { mutableIntStateOf(limits.last()) }
        AlertDialog(onDismissRequest = { groupDlg = false },
            title = { Text("Grup oluştur") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(gname, { gname = it }, label = { Text("Grup adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Aile", "Akrabalar", "Arkadaşlar", "Mahalle", "Apartman").forEach { r -> AssistChip({ gname = r }, { Text(r) }) }
                }
                Text("Beklenen en çok kişi", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    limits.forEach { l -> FilterChip(glimit == l, { glimit = l }, label = { Text("$l kişi") }) }
                }
                if (!isPro) Text("Ücretsizde grup 5 kişiye kadar; Pro ile 20 kişiye kadar. Sınır yumuşaktır: aşılırsa seni uyarırız.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Davet şekli", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(useQr, { useQr = true }, label = { Text("QR kod ile") })
                    FilterChip(!useQr, { useQr = false }, label = { Text("Sadece kod") })
                }
                Text("Kodu alan herkes gruptaki tüm mesajları görür. Grupta konum paylaşılmaz; yalnızca \"Yardım lazım\" ve SOS çağrılarında konum gider.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } },
            confirmButton = { TextButton({
                val (_, code) = Circles.createGroup(gname.trim().ifBlank { "Grubum" }, glimit); inviteShowQr = useQr; inviteDlg = code
                groupDlg = false; MonitorService.start(ctx)
            }) { Text("Oluştur") } },
            dismissButton = { TextButton({ groupDlg = false }) { Text("Vazgeç") } })
    }

    if (addDlg) {
        var code by remember { mutableStateOf(scanCode) }
        var err by remember { mutableStateOf<String?>(null) }
        var rel by remember { mutableStateOf("") }
        var ph2 by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { addDlg = false },
            title = { Text("Kodla ekle") },
            text = { Column {
                OutlinedTextField(code, { code = it }, label = { Text("Davet kodu (DK1… veya DKG1…)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                RelationField(rel) { rel = it }
                OutlinedTextField(ph2, { ph2 = it }, label = { Text("Telefonu (internet yoksa SMS ile ulaşır)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            } },
            confirmButton = { TextButton({
                scope.launch {
                    val r = Circles.acceptInvite(code, rel, ph2)
                    if (r == null) { addDlg = false; MonitorService.start(ctx); msg = "Eklendi. Karşı tarafa bağlandığını bildirdik." } else err = r
                }
            }) { Text("Ekle") } },
            dismissButton = { TextButton({ addDlg = false }) { Text("Vazgeç") } })
    }

    editDlg?.takeIf { it.group }?.let { m ->
        var n by remember { mutableStateOf(m.name) }
        var renewed by remember { mutableStateOf<String?>(null) }
        AlertDialog(onDismissRequest = { editDlg = null },
            title = { Text("Grup: ${m.name}") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text("Grup adı (yalnızca sende)") }, singleLine = true)
                OutlinedButton({ inviteDlg = Circles.groupCode(m); editDlg = null }, Modifier.fillMaxWidth()) { Text("Davet kodunu göster / paylaş") }
                if (m.owner) {
                    OutlinedButton({ renewed = Circles.renewGroup(m.id) }, Modifier.fillMaxWidth()) { Text("Kodu yenile (birini çıkarmak için)") }
                    Text("Yenileyince eski kodu bilenler yeni kanalı okuyamaz. Grupta kalmasını istediklerine yeni kodu gönder; onlar da \"Kodla ekle\" ile yeniden katılsın.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    renewed?.let { c -> Text("Yeni kod hazır.", color = DK.Teal, fontSize = 12.sp)
                        TextButton({ inviteDlg = c; editDlg = null }) { Text("Yeni kodu paylaş") } }
                }
                TextButton({ Circles.remove(m.id); editDlg = null }) { Text(if (m.owner) "Grubu sil (sadece sende)" else "Gruptan çık", color = MaterialTheme.colorScheme.error) }
            } },
            confirmButton = { TextButton({ Circles.rename(m.id, n, ""); editDlg = null }) { Text("Kaydet") } },
            dismissButton = { TextButton({ editDlg = null }) { Text("Kapat") } })
    }

    editDlg?.takeIf { !it.group }?.let { m ->
        var n by remember { mutableStateOf(m.name) }
        var ph by remember { mutableStateOf(m.phone) }
        var mp by remember { mutableStateOf(m.manualProv) }
        var provDlg by remember { mutableStateOf(false) }
        if (provDlg) AlertDialog(onDismissRequest = { provDlg = false }, title = { Text("Bulunduğu il") },
            text = { androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(TURKEY_PROVINCES.size) { i -> val p = TURKEY_PROVINCES[i]
                    TextButton({ mp = p; provDlg = false }, Modifier.fillMaxWidth()) { Text(p, Modifier.fillMaxWidth()) } }
            } },
            confirmButton = { TextButton({ provDlg = false }) { Text("Kapat") } },
            dismissButton = { TextButton({ mp = ""; provDlg = false }) { Text("Temizle") } })
        AlertDialog(onDismissRequest = { editDlg = null },
            title = { Text("Kişiyi düzenle") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text("İsim / yakınlık (Anne, Baba, Ayşe…)") }, singleLine = true)
                OutlinedTextField(ph, { ph = it }, label = { Text("Telefon (SMS yedeği için)") }, singleLine = true)
                OutlinedButton({ provDlg = true }, Modifier.fillMaxWidth()) { Text(if (mp.isBlank()) "Bulunduğu ili elle seç" else "Bulunduğu il: $mp") }
                Text("Kişi ilini paylaşırsa paylaştığı il önceliklidir; paylaşmıyorsa buradaki il kullanılır.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton({ Circles.remove(m.id); editDlg = null }) { Text("Kişiyi sil", color = MaterialTheme.colorScheme.error) }
            } },
            confirmButton = { TextButton({ Circles.rename(m.id, n, ph); Circles.setManualProv(m.id, mp); editDlg = null }) { Text("Kaydet") } },
            dismissButton = { TextButton({ editDlg = null }) { Text("Kapat") } })
    }
}

@Composable
private fun MemberCard(m: Member, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val (label, color) = when (m.status) {
        CType.SAFE -> "Güvende ✓ • ${Notifs.ago(m.statusTs)}" to DK.Teal
        CType.HELP -> "YARDIM İSTİYOR • ${Notifs.ago(m.statusTs)}" to DK.Accent2
        CType.SOS -> "ENKAZ ALTINDA • ${Notifs.ago(m.statusTs)}" to DK.Danger
        else -> if (m.lastAsked > 0) "Yanıt bekleniyor • sordun: ${Notifs.ago(m.lastAsked)}" to MaterialTheme.colorScheme.onSurfaceVariant
                else (if (m.connected) "Bağlı" else "Davet bekleniyor") to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card2(onClick = onEdit) {
        Text(m.name, style = MaterialTheme.typography.titleMedium)
        Text(label, color = color, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(if (m.prov.isNotBlank()) "📍 ${m.prov}" + (if (m.theirProv.isBlank()) " (elle yazdın)" else " (paylaştı)") else "📍 İl bilgisi yok",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            OutlinedButton({ Circles.send(m, CType.CHECK); toast(ctx, "${m.name} kişisine soru gönderildi ✓") }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Güvende misin?", fontSize = 12.sp, maxLines = 1) }
            Button({ Circles.send(m, CType.SAFE, "Güvendeyim"); toast(ctx, "${m.name} kişisine \"Güvendeyim\" gönderildi ✓") }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DK.Teal, contentColor = Color(0xFF00201C))) { Text("Güvendeyim", fontSize = 12.sp, maxLines = 1) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (m.lat != null && m.lon != null) TextButton({ Share.geo(ctx, m.lat, m.lon, m.name) }) {
                val d = Geo.distanceFromMe(m.lat, m.lon)
                Text("Son konumu aç" + (d?.let { " (~${fmtDist(it)})" } ?: ""), fontSize = 12.sp)
            }
            if (m.phone.isNotBlank()) TextButton({ Share.sms(ctx, listOf(m.phone), Share.myStatusText(prefs, "Güvendeyim")) }) { Text("SMS ile haber ver", fontSize = 12.sp) }
        }
    }
}

@Composable
private fun GroupCard(m: Member, events: List<CEvent>, onEdit: () -> Unit, onShare: () -> Unit) {
    val ctx = LocalContext.current
    // Her gönderenin son durumu (Güvendeyim / yardım / SOS) ve toplam görünen kişi sayısı
    val mine = events.filter { it.memberId == m.id && !it.mine && it.type != CType.HELLO && it.type != CType.READ }
    val seen = events.filter { it.memberId == m.id && !it.mine }.map { it.name }.distinct()
    val last = mine.filter { it.type == CType.SAFE || it.type == CType.HELP || it.type == CType.SOS }.groupBy { it.name }.mapValues { it.value.maxBy { e -> e.ts } }
    Card2(onClick = onEdit) {
        Text("Grup: " + m.name + if (m.owner) " (yönetici)" else "", style = MaterialTheme.typography.titleMedium)
        Text(if (seen.isEmpty()) "Henüz kimse yazmadı. Kodu paylaş, katılanlar burada görünür." else "${seen.size} kişi göründü: " + seen.joinToString(", "),
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (m.limit > 0) {
            val n = seen.size + 1   // sen dahil
            Text("Kişi: $n / ${m.limit}" + if (n > m.limit) " • Beklenenden fazla kişi var. Kod yanlış ellere geçmiş olabilir; kodu yenilemeyi düşün." else "",
                fontSize = 12.sp, color = if (n > m.limit) DK.Danger else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        last.values.sortedByDescending { it.ts }.forEach { e ->
            val (t, c) = when (e.type) {
                CType.SAFE -> "güvende ✓" to DK.Teal
                CType.SOS -> "ENKAZ ALTINDA" to DK.Danger
                else -> "YARDIM İSTİYOR" to DK.Accent2
            }
            Text("${e.name}: $t • ${Notifs.ago(e.ts)}", color = c, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        }
        mine.filter { it.type == CType.TEXT }.takeLast(3).forEach { e ->
            Text("${e.name}: ${e.text}", fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            OutlinedButton({ Circles.send(m, CType.CHECK); toast(ctx, "Gruba soru gönderildi ✓") }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Herkese: Güvende misin?", fontSize = 12.sp, maxLines = 1) }
            Button({ Circles.send(m, CType.SAFE, "Güvendeyim"); toast(ctx, "Gruba \"Güvendeyim\" gönderildi ✓") }, Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DK.Teal, contentColor = Color(0xFF00201C))) { Text("Güvendeyim", fontSize = 12.sp, maxLines = 1) }
        }
        TextButton(onShare) { Text("Davet kodunu paylaş", fontSize = 12.sp) }
    }
}

/** İsim ya da yakınlık yazılır; hızlı seçim düğmeleri de var. */
@Composable
fun RelationField(value: String, onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(value, onChange, label = { Text("İsim veya yakınlık (Anne, Baba, Ayşe…)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Anne", "Baba", "Eşim", "Kardeşim", "Çocuğum", "Dedem", "Babaanne", "Anneanne", "Arkadaşım").forEach { r ->
                AssistChip({ onChange(r) }, { Text(r) })
            }
        }
    }
}


/** "Konumunu kimler görüyor": yalnızca il adı paylaşılır; kişi başına aç/kapat, kaldır ve genel otomatik onay. */
@Composable
private fun ProvinceShareCard(members: List<Member>) {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    var auto by remember { mutableStateOf(prefs.shareProvAuto) }
    var qMag by remember { mutableFloatStateOf(prefs.circleQuakeMag) }
    val watching = members.count { it.shareWith }
    Card2 {
        Text("Konumunu kimler görüyor", style = MaterialTheme.typography.titleMedium)
        Text(if (watching == 0) "Şu an hiçbir yakının ilini görmüyor." else "$watching yakının bulunduğun ili görüyor. Tam konum değil, yalnızca il adı paylaşılır.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        members.filter { it.incomingReq }.forEach { m ->
            Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text("${m.name} ilini görmek istiyor", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ Circles.setShare(m.id, true) }) { Text("Paylaş") }
                    TextButton({ Circles.declineRequest(m.id) }) { Text("Şimdi değil") }
                }
            }
        }

        members.forEach { m ->
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(m.name, Modifier.weight(1f))
                if (m.shareWith || m.incomingReq) TextButton({ Circles.removeWatcher(m.id) }) { Text("Kaldır", fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
                Switch(m.shareWith, { Circles.setShare(m.id, it) })
            }
        }

        SwitchRow("İl bilgisini yakınlarımla paylaş", "Açıksa yakınlarının istekleri sorulmadan onaylanır. Kapalıysa (önerilen) her istekte sen karar verirsin.", auto) {
            auto = it; prefs.shareProvAuto = it
            if (it) Circles.approveAllPending()
        }
        if (watching > 0 || members.any { it.incomingReq }) OutlinedButton({ Circles.shareNone(); auto = false }, Modifier.fillMaxWidth()) { Text("Hiçbiriyle paylaşma") }

        Text("Yakınlarımın ilinde deprem olunca bildir: en az M${"%.1f".format(java.util.Locale.US, qMag)}", modifier = Modifier.padding(top = 8.dp), fontSize = 13.sp)
        Slider(qMag, { qMag = Math.round(it * 2) / 2f; prefs.circleQuakeMag = qMag }, valueRange = 2f..6f, steps = 7)
        Text("Kapatınca yeni il bilgisi gitmez; daha önce gönderilen il karşı telefonda kalabilir. Bir yakının ilini paylaşmıyorsa kişi kartından ili elle seçebilirsin.",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
