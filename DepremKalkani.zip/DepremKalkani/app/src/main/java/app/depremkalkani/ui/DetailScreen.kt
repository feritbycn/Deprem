package app.depremkalkani.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.dk
import app.depremkalkani.data.*
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.mesh.MsgType
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DetailScreen(q: Quake, onShowOnMap: (Quake) -> Unit, onAlertView: (Quake) -> Unit) {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val scope = rememberCoroutineScope()
    var felt by remember { mutableStateOf(q.id in prefs.feltIds) }
    val fmt = SimpleDateFormat("d MMMM yyyy, HH:mm:ss", Locale("tr"))
    val d = Geo.distanceFromMe(q)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card2(brush = DK.Hero) {
            Text(String.format(Locale.US, "M %.1f", q.mag), fontSize = 52.sp, color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.headlineLarge)
            Text(q.place, color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.titleLarge)
            Text(fmt.format(Date(q.time)), color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f))
        }
        Card2 {
            Info("Derinlik", "${"%.1f".format(Locale.US, q.depthKm)} km")
            Info("Konum", "%.4f, %.4f".format(Locale.US, q.lat, q.lon))
            Info("Kaynak", Sources.label(q.source))
            if (d != null) Info("Sana uzaklık", "${fmtDist(d)} • ${Geo.compass(Geo.bearingDeg(Geo.lat!!, Geo.lon!!, q.lat, q.lon))} yönünde")
            if (q.province.isNotBlank()) Info("İl", q.province)
        }
        BigButton(if (felt) "Hissettiğini bildirdin ✓" else "Hissettim", enabled = !felt, onClick = {
            felt = true; prefs.feltIds = prefs.feltIds + q.id
            scope.launch {
                val ok = CrowdFelt.report(ctx, true)
                toast(ctx, if (ok) "Hissettiğin bildirildi ✓ Yakındaki kullanıcılara iletildi." else "Kaydedildi; internet/konum olmadığı için yalnızca yakın cihazlara gitti.")
            }
        })
        BigButton("Sismik dalga görünümü", { onAlertView(q) }, color = DK.Danger)
        BigButton("Haritada göster", { onShowOnMap(q) }, outlined = true)
        BigButton("Paylaş", { Share.text(ctx, Share.quakeText(q)) }, outlined = true)
        q.url?.let { u -> BigButton("Kaynakta aç", { Share.url(ctx, u) }, outlined = true) }
        Text("\"Hissettim\" kaydı telefonunda tutulur ve yakındaki Deprem Kalkanı kullanıcılarına internetsiz iletilir. Aynı bölgede yeterince kullanıcı bildirirse çevredekilere \"Kullanıcılar deprem hissedildiğini bildiriyor\" uyarısı gider.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Info(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(k, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(120.dp))
        Text(v, style = MaterialTheme.typography.titleMedium)
    }
}
