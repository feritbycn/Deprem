package app.depremkalkani.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import app.depremkalkani.data.Circles
import app.depremkalkani.data.CrowdFelt
import app.depremkalkani.data.Sources
import app.depremkalkani.dk
import kotlinx.coroutines.launch

/** Sayfayı aşağı çekince depremleri, Yakınlarım'ı ve "hissettim" verisini yeniler. */
@Composable
fun GlobalRefresh(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    PullToRefreshBox(
        isRefreshing = busy,
        onRefresh = {
            scope.launch {
                busy = true
                runCatching { ctx.dk.repo.refresh(ctx.dk.prefs.sources.ifEmpty { setOf(Sources.AFAD) }) }
                runCatching { Circles.syncNow() }
                runCatching { CrowdFelt.refresh(ctx) }
                busy = false
            }
        },
        modifier = Modifier.fillMaxSize(),
    ) { content() }
}
