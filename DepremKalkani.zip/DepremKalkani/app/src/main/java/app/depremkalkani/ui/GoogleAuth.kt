package app.depremkalkani.ui

import android.app.Activity
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import app.depremkalkani.BuildConfig
import app.depremkalkani.dk
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** Google ile giriş (Credential Manager). Başarı: null, hata: Türkçe mesaj. */
object GoogleAuth {
    suspend fun signIn(ctx: Context): String? {
        if (BuildConfig.GOOGLE_WEB_CLIENT_ID.isBlank())
            return "Google girişi henüz kurulmadı: gradle.properties içine GOOGLE_WEB_CLIENT_ID yazılmalı (README'ye bak)."
        val act = ctx as? Activity ?: return "Giriş ekranı açılamadı."
        return try {
            val opt = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
                .build()
            val res = CredentialManager.create(act).getCredential(act, GetCredentialRequest.Builder().addCredentialOption(opt).build())
            val cred = res.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                val p = ctx.dk.prefs
                p.accountName = g.displayName ?: ""
                p.accountEmail = g.id
                if (p.nick.isBlank()) p.nick = (g.displayName ?: g.id.substringBefore('@'))
                null
            } else "Beklenmeyen giriş yanıtı."
        } catch (e: Exception) {
            "Giriş yapılamadı: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    fun signOut(ctx: Context) {
        val p = ctx.dk.prefs
        p.accountName = ""; p.accountEmail = ""
    }
}
