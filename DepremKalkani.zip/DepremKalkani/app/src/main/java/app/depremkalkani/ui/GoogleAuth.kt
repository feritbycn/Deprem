package app.depremkalkani.ui

import app.depremkalkani.data.NickGuard
import android.app.Activity
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import kotlinx.coroutines.withTimeoutOrNull
import app.depremkalkani.BuildConfig
import app.depremkalkani.dk
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** Google ile giriş (Credential Manager). Başarı: null, hata: Türkçe mesaj. */
object GoogleAuth {
    suspend fun signIn(ctx: Context): String? {
        // Credential Manager bazı cihazlarda yanıt vermeden bekleyebilir: 40 sn sonra anlaşılır bir mesajla bırak
        return withTimeoutOrNull(40_000L) { signInInner(ctx) }
            ?: "Google yanıt vermedi. Telefonda Google hesabının ekli olduğunu, Play Hizmetleri'nin güncel olduğunu ve uygulamayı Google Play'den kurduğunu kontrol et; sonra tekrar dene."
    }

    private suspend fun signInInner(ctx: Context): String? {
        if (BuildConfig.GOOGLE_WEB_CLIENT_ID.isBlank())
            return "Google girişi henüz kurulmadı: gradle.properties içine GOOGLE_WEB_CLIENT_ID yazılmalı (README'ye bak)."
        val act = ctx as? Activity ?: return "Giriş ekranı açılamadı."
        return try {
            val cm = CredentialManager.create(act)
            val res: GetCredentialResponse = try {
                val opt = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
                    .build()
                cm.getCredential(act, GetCredentialRequest.Builder().addCredentialOption(opt).build())
            } catch (e: NoCredentialException) {
                // Hesap listesi alınamadıysa klasik "Google ile oturum aç" akışı: hesap seçme ekranını kendisi açar
                val opt2 = GetSignInWithGoogleOption.Builder(BuildConfig.GOOGLE_WEB_CLIENT_ID).build()
                cm.getCredential(act, GetCredentialRequest.Builder().addCredentialOption(opt2).build())
            }
            val cred = res.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                val p = ctx.dk.prefs
                p.accountName = NickGuard.clean(g.displayName ?: "")
                p.accountEmail = g.id
                if (p.nick.isBlank()) p.nick = (g.displayName ?: g.id.substringBefore('@'))   // numara içeriyorsa kabul edilmez
                if (p.nick.isBlank()) p.nickAsked = false   // ad boş kaldıysa Yakındakiler ilk kullanımda adı yeniden sorar
                null
            } else "Beklenmeyen giriş yanıtı."
        } catch (e: GetCredentialCancellationException) {
            "Giriş iptal edildi."
        } catch (e: Exception) {
            "Giriş yapılamadı: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    fun signOut(ctx: Context) {
        val p = ctx.dk.prefs
        p.accountName = ""; p.accountEmail = ""
    }
}
