package app.depremkalkani.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import app.depremkalkani.data.Geo
import app.depremkalkani.data.Quake
import app.depremkalkani.data.Sources
import java.util.Locale

object Perms {
    val location = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    val notification get() = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray<String>()

    val nearby: Array<String>
        get() = buildList {
            if (Build.VERSION.SDK_INT >= 31) {
                add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT); add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
        }.toTypedArray()

    fun has(ctx: Context, perms: Array<String>) =
        perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
}

object Share {
    fun mapsLink(lat: Double, lon: Double) = "https://maps.google.com/?q=%.6f,%.6f".format(Locale.US, lat, lon)

    fun text(ctx: Context, text: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(i, "Paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** İnternet olmasa da hücresel şebeke varsa çalışır. Kullanıcı SMS uygulamasında "Gönder"e basar. */
    fun sms(ctx: Context, phones: List<String>, body: String) {
        val uri = Uri.parse("smsto:" + phones.joinToString(","))
        val i = Intent(Intent.ACTION_SENDTO, uri).putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }
    }

    fun dial(ctx: Context, number: String) {
        runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun url(ctx: Context, url: String) {
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun geo(ctx: Context, lat: Double, lon: Double, label: String) {
        val u = Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode(label)})")
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { url(ctx, mapsLink(lat, lon)) }
    }

    fun quakeText(q: Quake): String =
        "Deprem M%.1f • %s\nDerinlik %.0f km • Kaynak: %s\n%s".format(Locale.US, q.mag, q.place, q.depthKm, Sources.label(q.source),
            mapsLink(q.lat, q.lon))

    fun myStatusText(prefs: app.depremkalkani.data.Prefs, status: String): String {
        val loc = if (Geo.known) "\nKonumum: " + mapsLink(Geo.lat!!, Geo.lon!!) else ""
        val note = if (prefs.emergencyNote.isNotBlank()) "\nNot: ${prefs.emergencyNote}" else ""
        val who = if (prefs.nick.isNotBlank()) "${prefs.nick}: " else ""
        return "$who$status$loc$note"
    }
}

fun fmtDist(km: Double): String = if (km < 1) "${(km * 1000).toInt()} m" else if (km < 100) "%.1f km".format(Locale.US, km) else "${km.toInt()} km"
