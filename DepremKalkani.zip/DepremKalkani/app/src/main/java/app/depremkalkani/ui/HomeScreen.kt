package app.depremkalkani.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.dk
import app.depremkalkani.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun HomeScreen(onOpen: (Quake) -> Unit, onPro: () -> Unit, onCircle: () -> Unit, onFelt: () -> Unit = {}, onPerms: () -> Unit = {}) {
    val ctx = LocalContext.current
    val app = ctx.dk
    val repo = app.repo
    val prefs = app.prefs
    val scope = rememberCoroutineScope()
    val all by repo.quakes.collectAsState()
    val loading by repo.loading.collectAsState()
    val err by repo.error.collectAsState()
    val last by repo.lastUpdate.collectAsState()
    val isPro by app.billing.isPro.collectAsState()
    var minMag by remember { mutableFloatStateOf(prefs.listMinMag) }
    var srcFilter by remember { mutableStateOf(prefs.listSource.takeIf { it.isNotBlank() && it in prefs.sources }) }
    var regionOnly by remember { mutableStateOf(prefs.listRegion) }
    val ctx0 = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableIntStateOf(0) }   // 0 = son depremler, 1 = önemli depremler

    // Açılışta ve ekran açıkken her 30 sn'de bir yenile
    LaunchedEffect(Unit) {
        while (true) {
            runCatching { app.repo.refresh(prefs.sources.ifEmpty { setOf(Sources.AFAD) }) }
            delay(if (isPro) 15_000 else 30_000)
        }
    }

    val list = remember(all, minMag, srcFilter, regionOnly, last) {
        all.filter { it.mag >= minMag && (srcFilter == null || it.source == srcFilter) &&
            (!regionOnly || RegionAuto.inMyRegion(it)) }
    }
    val day = System.currentTimeMillis() - 86400_000L
    val last24 = all.filter { it.time >= day }
    val strongest = last24.maxByOrNull { it.mag }
    var bigRegion by remember { mutableStateOf(prefs.bigRegion) }
    val bigRecent = remember(all, last, bigRegion) {
        val since = System.currentTimeMillis() - 7 * 86400_000L
        all.filter { it.mag >= 4.0 && it.time >= since && (!bigRegion || RegionAuto.inMyRegion(it)) }.sortedByDescending { it.time }.take(12)
    }
    val nearest = if (Geo.known) all.filter { it.time >= day }.minByOrNull { Geo.distanceFromMe(it) ?: 1e9 } else null

    var pulling by remember { mutableStateOf(false) }   // gösterge sadece kullanıcı çekince; arka plan yenilemesinde görünmez
    PullToRefreshBox(isRefreshing = pulling, onRefresh = { pulling = true; scope.launch { delay(900); pulling = false }; scope.launch { runCatching { repo.refresh(prefs.sources.ifEmpty { setOf(Sources.AFAD) }) } } }, modifier = Modifier.fillMaxSize()) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Deprem Kalkanı", style = MaterialTheme.typography.headlineLarge)
                    Text(
                        if (last > 0) "Güncellendi: ${Notifs.ago(last)}" else if (loading) "Veriler alınıyor…" else "Henüz güncellenmedi",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp,
                    )
                }
                val dark = ThemeState.choice.value ?: androidx.compose.foundation.isSystemInDarkTheme()
                IconButton({
                    val to = !dark
                    ThemeState.choice.value = to; prefs.themeMode = if (to) "dark" else "light"
                }) { Icon(if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode, if (dark) "Aydınlık mod" else "Karanlık mod") }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                var ptick by remember { mutableIntStateOf(0) }
                androidx.lifecycle.compose.LifecycleEventEffect(androidx.lifecycle.Lifecycle.Event.ON_RESUME) { ptick++ }
                val missing = remember(ptick) { PermHealth.missingRequired(ctx0).filter { it.kind == PK.BATT || it.kind == PK.MONITOR } }
                // Açılmamış diğer özellikler de aynı kartta: yakın cihaz izni, kilit ekranı uyarısı, arka plan verisi
                val others = remember(ptick) {
                    PermHealth.items(ctx0).filter { !it.ok && !it.required && (it.kind == PK.NEARBY || it.kind == PK.FSI || it.kind == PK.BGDATA) }.map { it.title }
                }
                if (missing.isNotEmpty() || others.isNotEmpty()) Card2(onClick = onPerms) {
                    Text("${missing.size + others.size} ayar / özellik kapalı", style = MaterialTheme.typography.titleSmall)
                    if (missing.isNotEmpty()) Text("Önemli: " + missing.joinToString(", ") { it.title } + " • uyarıları kaçırabilirsin.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (others.isNotEmpty()) Text("Açılmamış: " + others.joinToString(", "), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Dokunup düzelt.", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                }
                PermBanner("notif", "Bildirim izni kapalı: deprem ve sismik dalga uyarıları sana ulaşmaz.", Perms.notification,
                    { Perms.notification.isEmpty() || Perms.has(ctx0, Perms.notification) }, dismissible = true)
                PermBanner("loc", "Konum izni kapalı: depreme uzaklığı hesaplayamam ve bölgene göre uyaramam.", Perms.location,
                    { Perms.has(ctx0, arrayOf(android.Manifest.permission.ACCESS_COARSE_LOCATION)) || Perms.has(ctx0, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION)) }, dismissible = true)
            }
        }
        if (err != null && all.isEmpty()) item {
            Card2(brush = null) {
                Text("Veri alınamadı", style = MaterialTheme.typography.titleMedium)
                Text("İnternet bağlantını kontrol et. Son kaydedilen veriler internet olmasa da burada görünür.\n$err",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
        }
        item {
            Card2(brush = DK.Hero, onClick = strongest?.let { s -> { onOpen(s) } }) {
                Text("SON 24 SAATİN EN BÜYÜĞÜ", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.75f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                if (strongest == null) {
                    if (loading) SeismicLoader(Modifier.fillMaxWidth().height(80.dp), color = androidx.compose.ui.graphics.Color.White)
                    else Text("Veri bekleniyor", color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.titleLarge)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(String.format(Locale.US, "%.1f", strongest.mag), color = androidx.compose.ui.graphics.Color.White,
                            fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(strongest.place, color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${Notifs.ago(strongest.time)} • ${strongest.depthKm.toInt()} km derin • ${Sources.label(strongest.source)}",
                                color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("24 saatte", "${last24.size}", Modifier.weight(1f))
                Stat("M4 ve üzeri", "${last24.count { it.mag >= 4 }}", Modifier.weight(1f))
                Stat("Sana en yakın", nearest?.let { fmtDist(Geo.distanceFromMe(it) ?: 0.0) } ?: "—", Modifier.weight(1f))
            }
        }
        // Son 7 günün M4+ depremleri: ince, yatay kaydırılan şerit (yoksa hiç görünmez)
        if (bigRecent.isNotEmpty() || bigRegion) item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Son günlerin büyük depremleri", fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp).weight(1f))
                    FilterChip(selected = !bigRegion, onClick = { bigRegion = false; prefs.bigRegion = false }, label = { Text("Hepsi", fontSize = 12.sp) })
                    FilterChip(selected = bigRegion, onClick = { bigRegion = true; prefs.bigRegion = true }, label = { Text("Bölgem", fontSize = 12.sp) })
                }
                if (bigRecent.isEmpty()) Text("Bölgende son 7 günde M4+ deprem yok.", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    bigRecent.forEach { q -> BigQuakeChip(q) { onOpen(q) } }
                }
            }
        }
        item {
            Card2(brush = DK.Hero, onClick = onFelt) {
                Text("Deprem hissettin mi?", style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White)
                Text("Bölgendeki kullanıcıların bildirimlerini gör, sen de \"Hissettim\" / \"Hissetmedim\" de.",
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
        item {
            val mem by Circles.members.collectAsState()
            Card2(brush = DK.Cool, onClick = onCircle) {
                Text("Yakınlarım", style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White)
                Text(if (mem.isEmpty()) "Aile ve tanıdıklarını ekle; deprem olunca birbirinize \"Güvendeyim\" deyin."
                     else "${mem.count { !it.group }} kişi" + (mem.count { it.group }.let { g -> if (g > 0) " • $g grup" else "" }) + " • ${mem.count { it.status == CType.SAFE }} güvende • tek dokunuşla durumunu bildir",
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
        item {
            TabRow(selectedTabIndex = tab, containerColor = androidx.compose.ui.graphics.Color.Transparent) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Son depremler") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Önemli depremler") })
            }
        }
        if (tab == 0) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1f, 2f, 3f, 4f, 5f).forEach { m ->
                            FilterChip(selected = minMag == m, onClick = { minMag = m; prefs.listMinMag = m }, label = { Text("M${m.toInt()}+") })
                        }
                        FilterChip(selected = regionOnly, onClick = { regionOnly = !regionOnly; prefs.listRegion = regionOnly }, label = { Text("Bölgem") })
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = srcFilter == null, onClick = { srcFilter = null; prefs.listSource = "" }, label = { Text("Tüm kaynaklar") })
                        Sources.ALL.filter { it in prefs.sources }.forEach { s ->
                            FilterChip(selected = srcFilter == s, onClick = { srcFilter = if (srcFilter == s) null else s; prefs.listSource = srcFilter ?: "" }, label = { Text(Sources.label(s)) })
                        }
                    }
                    if (regionOnly) Text("Bölgem: " + RegionAuto.label() + (if (RegionAuto.userInTurkey()) " • AFAD ve Kandilli" else " içindeki depremler"),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp))
                }
            }

            if (list.isEmpty() && !loading) item {
                Text("Bu filtrelerde deprem yok.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 20.dp))
            }
            items(list.distinctBy { it.id }.take(300), key = { it.id }) { q -> QuakeRow(q) { onOpen(q) } }

        } else {
            item { Text("Türkiye'nin yakın tarihindeki büyük depremler. Canlı veri değildir; bir depreme dokununca merkez üssü, derinlik ve bilinen etkilerini görürsün.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
            items(Seed.notable, key = { it.id }) { q -> QuakeRow(q, historic = true) { onOpen(q) } }
        }
        item {
            if (!isPro) Card2(brush = DK.Cool, onClick = onPro) {
                Text("Reklamsız kullan", style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White)
                Text("Pro ile reklamlar kalkar, veriler 15 sn'de bir yenilenir.", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
    }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp),
    ) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
fun QuakeRow(q: Quake, historic: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MagBadge(q.mag)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(q.place, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val d = Geo.distanceFromMe(q)
            Text(
                (if (historic) java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale("tr")).format(java.util.Date(q.time)) else Notifs.ago(q.time)) +
                    " • ${q.depthKm.toInt()} km" + (d?.let { " • sana ${fmtDist(it)}" } ?: ""),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Pill(Sources.label(q.source))
    }
}

/** Küçük, yatay kaydırılan "büyük deprem" kartı: renkli büyüklük + yer + zaman/uzaklık. */
@Composable
private fun BigQuakeChip(q: Quake, onClick: () -> Unit) {
    val c = DK.magColor(q.mag)
    Row(
        Modifier.width(210.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(c.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Text(String.format(Locale.US, "%.1f", q.mag), color = c, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(q.place, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val d = Geo.distanceFromMe(q)
            Text(Notifs.ago(q.time) + (d?.let { " • ${fmtDist(it)}" } ?: ""), fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
