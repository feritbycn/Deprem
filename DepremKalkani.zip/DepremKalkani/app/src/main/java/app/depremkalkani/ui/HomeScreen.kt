package app.depremkalkani.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.dk
import app.depremkalkani.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun HomeScreen(onOpen: (Quake) -> Unit, onPro: () -> Unit, onCircle: () -> Unit, onFelt: () -> Unit = {}) {
    val ctx = LocalContext.current
    val app = ctx.dk
    val repo = app.repo
    val prefs = app.prefs
    val scope = rememberCoroutineScope()
    val all by repo.quakes.collectAsState()
    val loading by repo.loading.collectAsState()
    val err by repo.error.collectAsState()
    val last by repo.lastUpdate.collectAsState()
    val isPro by app.billing.isPro.collectAsState()
    var minMag by remember { mutableFloatStateOf(prefs.listMinMag) }
    var srcFilter by remember { mutableStateOf<String?>(null) }
    var regionOnly by remember { mutableStateOf(false) }

    // Açılışta ve ekran açıkken her 30 sn'de bir yenile
    LaunchedEffect(Unit) {
        while (true) {
            runCatching { app.repo.refresh(prefs.sources.ifEmpty { setOf(Sources.AFAD) }) }
            delay(if (isPro) 15_000 else 30_000)
        }
    }

    val list = remember(all, minMag, srcFilter, regionOnly, last) {
        all.filter { it.mag >= minMag && (srcFilter == null || it.source == srcFilter) &&
            (!regionOnly || QuakeRepository.matches(it, prefs, minMag)) }
    }
    val day = System.currentTimeMillis() - 86400_000L
    val last24 = all.filter { it.time >= day }
    val strongest = last24.maxByOrNull { it.mag }
    val nearest = if (Geo.known) all.filter { it.time >= day }.minByOrNull { Geo.distanceFromMe(it) ?: 1e9 } else null

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Deprem Kalkanı", style = MaterialTheme.typography.headlineLarge)
                    Text(
                        if (last > 0) "Güncellendi: ${Notifs.ago(last)}" else if (loading) "Veriler alınıyor…" else "Henüz güncellenmedi",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp,
                    )
                }
                if (loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                else IconButton({ scope.launch { runCatching { repo.refresh(prefs.sources.ifEmpty { setOf(Sources.AFAD) }) } } }) {
                    Icon(Icons.Filled.Refresh, "Yenile")
                }
            }
        }
        if (err != null && all.isEmpty()) item {
            Card2(brush = null) {
                Text("Veri alınamadı", style = MaterialTheme.typography.titleMedium)
                Text("İnternet bağlantını kontrol et. Son kaydedilen veriler internet olmasa da burada görünür.\n$err",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
        }
        item {
            Card2(brush = DK.Hero, onClick = strongest?.let { s -> { onOpen(s) } }) {
                Text("SON 24 SAATİN EN BÜYÜĞÜ", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.75f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                if (strongest == null) {
                    Text("Veri bekleniyor", color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.titleLarge)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(String.format(Locale.US, "%.1f", strongest.mag), color = androidx.compose.ui.graphics.Color.White,
                            fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(strongest.place, color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${Notifs.ago(strongest.time)} • ${strongest.depthKm.toInt()} km derin • ${Sources.label(strongest.source)}",
                                color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("24 saatte", "${last24.size}", Modifier.weight(1f))
                Stat("M4 ve üzeri", "${last24.count { it.mag >= 4 }}", Modifier.weight(1f))
                Stat("Sana en yakın", nearest?.let { fmtDist(Geo.distanceFromMe(it) ?: 0.0) } ?: "—", Modifier.weight(1f))
            }
        }
        item {
            Card2(brush = DK.Hero, onClick = onFelt) {
                Text("Deprem hissettin mi?", style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White)
                Text("Bölgendeki kullanıcıların bildirimlerini gör, sen de \"Hissettim\" / \"Hissetmedim\" de.",
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
        item {
            val mem by Circles.members.collectAsState()
            Card2(brush = DK.Cool, onClick = onCircle) {
                Text("Yakınlarım", style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White)
                Text(if (mem.isEmpty()) "Aile ve tanıdıklarını ekle; deprem olunca birbirinize \"Güvendeyim\" deyin."
                     else "${mem.size} kişi • ${mem.count { it.status == CType.SAFE }} güvende • tek dokunuşla durumunu bildir",
                    color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
        item { AdBanner(isPro) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(2f, 3f, 4f, 5f).forEach { m ->
                        FilterChip(selected = minMag == m, onClick = { minMag = m; prefs.listMinMag = m }, label = { Text("M${m.toInt()}+") })
                    }
                    FilterChip(selected = regionOnly, onClick = { regionOnly = !regionOnly }, label = { Text("Bölgem") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = srcFilter == null, onClick = { srcFilter = null }, label = { Text("Tüm kaynaklar") })
                    Sources.ALL.filter { it in prefs.sources }.forEach { s ->
                        FilterChip(selected = srcFilter == s, onClick = { srcFilter = if (srcFilter == s) null else s }, label = { Text(Sources.label(s)) })
                    }
                }
            }
        }
        if (list.isEmpty() && !loading) item {
            Text("Bu filtrelerde deprem yok.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 20.dp))
        }
        items(list.take(300), key = { it.id }) { q -> QuakeRow(q) { onOpen(q) } }

        item { SectionTitle("Önemli depremler (tarihî)") }
        items(Seed.notable, key = { it.id }) { q -> QuakeRow(q, historic = true) { onOpen(q) } }
        item {
            if (!isPro) Card2(brush = DK.Cool, onClick = onPro) {
                Text("Reklamsız kullan", style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White)
                Text("Pro ile reklamlar kalkar, veriler 15 sn'de bir yenilenir.", color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp),
    ) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
fun QuakeRow(q: Quake, historic: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MagBadge(q.mag)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(q.place, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val d = Geo.distanceFromMe(q)
            Text(
                (if (historic) java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale("tr")).format(java.util.Date(q.time)) else Notifs.ago(q.time)) +
                    " • ${q.depthKm.toInt()} km" + (d?.let { " • sana ${fmtDist(it)}" } ?: ""),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Pill(Sources.label(q.source))
    }
}
