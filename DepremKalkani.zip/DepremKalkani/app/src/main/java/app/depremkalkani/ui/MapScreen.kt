package app.depremkalkani.ui

import android.content.Context
import android.graphics.Color as AColor
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.depremkalkani.dk
import app.depremkalkani.data.*
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon

private fun dot(ctx: Context, color: Int, sizeDp: Int): ShapeDrawable {
    val px = (sizeDp * ctx.resources.displayMetrics.density).toInt()
    return ShapeDrawable(OvalShape()).apply {
        setIntrinsicHeight(px); setIntrinsicWidth(px); paint.color = color
        paint.alpha = 220
    }
}

@Composable
fun MapScreen(focus: Quake?, onOpen: (Quake) -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.dk
    val prefs = app.prefs
    val scope = rememberCoroutineScope()
    val quakes by app.repo.quakes.collectAsState()
    var minMag by remember { mutableFloatStateOf(maxOf(2.5f, prefs.listMinMag)) }
    var showAssembly by remember { mutableStateOf(false) }
    var assembly by remember { mutableStateOf(Assembly.load(ctx)) }
    var status by remember { mutableStateOf<String?>(null) }
    var assemblyLoading by remember { mutableStateOf(false) }
    val view = remember { MapView(ctx).apply {
        setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true)
        controller.setZoom(6.0); controller.setCenter(GeoPoint(39.0, 35.0))
    } }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) view.onResume() else if (e == Lifecycle.Event.ON_PAUSE) view.onPause()
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); view.onPause(); view.onDetach() }
    }

    LaunchedEffect(focus) {
        if (focus != null) { view.controller.setZoom(9.0); view.controller.setCenter(GeoPoint(focus.lat, focus.lon)) }
        else if (Geo.known) { view.controller.setZoom(7.0); view.controller.setCenter(GeoPoint(Geo.lat!!, Geo.lon!!)) }
    }

    fun redraw() {
        view.overlays.clear()
        if (Geo.known) {
            view.overlays += Marker(view).apply {
                position = GeoPoint(Geo.lat!!, Geo.lon!!); title = "Konumum"
                icon = dot(ctx, AColor.parseColor("#2979FF"), 16); setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            }
        }
        val shown = quakes.filter { it.mag >= minMag }.take(400).reversed()
        for (q in shown) {
            view.overlays += Marker(view).apply {
                position = GeoPoint(q.lat, q.lon)
                title = "M%.1f  %s".format(java.util.Locale.US, q.mag, q.place)
                snippet = Notifs.ago(q.time) + " • " + q.depthKm.toInt() + " km • " + Sources.label(q.source)
                val sz = (10 + q.mag * 3.2).toInt().coerceIn(12, 40)
                icon = dot(ctx, DK.magColor(q.mag).toArgb(), sz)
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                setOnMarkerClickListener { m, _ -> if (m.isInfoWindowShown) { onOpen(q); true } else { m.showInfoWindow(); true } }
            }
        }
        if (showAssembly) for (a in assembly) {
            view.overlays += Marker(view).apply {
                position = GeoPoint(a.lat, a.lon); title = a.name; snippet = "Toplanma alanı"
                icon = dot(ctx, AColor.parseColor("#22C55E"), 18); setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            }
        }
        view.invalidate()
    }
    LaunchedEffect(quakes, minMag, showAssembly, assembly) { redraw() }

    Box(Modifier.fillMaxSize()) {
        AndroidView({ view }, Modifier.fillMaxSize())
        DelayedLoader(assemblyLoading, Modifier.align(Alignment.Center), "Toplanma alanları aranıyor…")
        Column(Modifier.align(Alignment.TopStart).padding(12.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(2.5f, 3f, 4f, 5f).forEach { m ->
                    FilterChip(selected = minMag == m, onClick = { minMag = m },
                        label = { Text("M${if (m % 1f == 0f) m.toInt().toString() else m.toString()}+") },
                        colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surface))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = showAssembly, onClick = {
                    showAssembly = !showAssembly
                    if (showAssembly) scope.launch {
                        LocationHelper.refresh(ctx)
                        if (Geo.known) {
                            status = "Toplanma alanları aranıyor…"; assemblyLoading = true
                            runCatching { withContext(Dispatchers.IO) { Assembly.fetch(ctx, Geo.lat!!, Geo.lon!!) } }
                                .onSuccess { assemblyLoading = false; assembly = it; status = if (it.isEmpty()) "Yakında kayıtlı toplanma alanı bulunamadı. AFAD sorgusunu dene." else null }
                                .onFailure { assemblyLoading = false; status = if (assembly.isEmpty()) "İnternet yok; kayıtlı toplanma alanı da yok." else "Çevrimdışı: kayıtlı alanlar gösteriliyor." }
                        } else status = "Konum bilinmiyor."
                    }
                }, label = { Text("Toplanma alanları") },
                    colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surface))
                AssistChip(onClick = {
                    scope.launch {
                        LocationHelper.refresh(ctx)
                        if (Geo.known) { view.controller.setZoom(11.0); view.controller.animateTo(GeoPoint(Geo.lat!!, Geo.lon!!)) }
                    }
                }, label = { Text("Konumum") }, colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.surface))
            }
            status?.let {
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
                    Text(it, Modifier.padding(10.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (showAssembly) TextButton({ Share.url(ctx, Assembly.AFAD_EDEVLET) }) { Text("AFAD resmî sorgusu (e-Devlet)") }
        }
    }
}

