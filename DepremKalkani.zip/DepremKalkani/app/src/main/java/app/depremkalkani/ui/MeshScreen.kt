package app.depremkalkani.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.dk
import app.depremkalkani.data.Geo
import app.depremkalkani.data.Notifs
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.mesh.MeshMsg
import app.depremkalkani.mesh.MsgType
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.launch

@Composable
fun MeshScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val scope = rememberCoroutineScope()
    val running by Mesh.running.collectAsState()
    val peers by Mesh.peers.collectAsState()
    val msgs by Mesh.messages.collectAsState()
    val err by Mesh.error.collectAsState()
    val cEvents by app.depremkalkani.data.Circles.events.collectAsState()
    val cMembers by app.depremkalkani.data.Circles.members.collectAsState()
    var toRelatives by remember { mutableStateOf(false) }       // false: yakındaki kullanıcılar, true: yakınlarım
    var selMember by remember { mutableStateOf<String?>(null) }  // null: tüm yakınlarım
    val feed = remember(msgs, cEvents, cMembers) {
        val circ = cEvents.filter { it.type != app.depremkalkani.data.CType.HELLO || !it.mine }.map {
            MeshMsg(it.id, if (it.mine) Mesh.myId else "c" + it.memberId, if (it.mine) "" else it.name,
                when (it.type) {
                    app.depremkalkani.data.CType.SAFE -> MsgType.SAFE; app.depremkalkani.data.CType.SOS -> MsgType.SOS
                    app.depremkalkani.data.CType.HELP -> MsgType.NEED; else -> MsgType.TEXT
                },
                (if (it.mine) "→ ${it.name}: " else "(Yakınım) ") + (if (it.type == app.depremkalkani.data.CType.TEXT || it.text.isNotBlank()) it.text.ifBlank { it.type.label } else it.type.label),
                if (it.mine) Geo.lat else cMembers.firstOrNull { m -> m.id == it.memberId }?.lat,
                if (it.mine) Geo.lon else cMembers.firstOrNull { m -> m.id == it.memberId }?.lon,
                it.ts, 0, "")
        }
        (msgs + circ).sortedBy { it.ts }
    }
    val smsPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    var text by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf(prefs.nick) }
    val listState = rememberLazyListState()
    var btOn by remember { mutableStateOf(true) }
    var locOn by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        while (true) {
            btOn = ctx.getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter?.isEnabled ?: false
            locOn = if (android.os.Build.VERSION.SDK_INT >= 28) ctx.getSystemService(android.location.LocationManager::class.java)?.isLocationEnabled ?: true else true
            kotlinx.coroutines.delay(2000)
        }
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        scope.launch { LocationHelper.refresh(ctx) }
        Mesh.start()
    }
    fun toggle() {
        if (running) Mesh.stop()
        else if (Perms.has(ctx, Perms.nearby)) { scope.launch { LocationHelper.refresh(ctx) }; Mesh.start() }
        else perm.launch((Perms.nearby + Perms.notification).distinct().toTypedArray())
    }
    LaunchedEffect(feed.size) { if (feed.isNotEmpty()) listState.animateScrollToItem(feed.size - 1) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(top = 12.dp)) {
        Text("Yakındakiler", style = MaterialTheme.typography.headlineLarge)
        Text("İnternet ve şebeke olmadan, yakındaki Deprem Kalkanı kullanıcılarıyla mesajlaş, konum ve durum gönder.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))

        Card2(brush = if (running) DK.Cool else null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (running) "Tarama açık" else "Tarama kapalı", style = MaterialTheme.typography.titleMedium)
                    Text("Bulunan: ${peers.size} • Bağlı cihaz: ${peers.values.count { it.connected }}" + (peers.values.filter { it.connected }.joinToString { it.nick }.let { if (it.isNotBlank()) " ($it)" else "" }),
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(running, { toggle() })
            }
            if (!running) {
                OutlinedTextField(nick, { nick = it; prefs.nick = it }, label = { Text("Adın (diğerleri görür)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
            if (running && !btOn) {
                Text("Bluetooth KAPALI. Yakındaki telefonları bulmak için Bluetooth'u aç.", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                TextButton({ ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Bluetooth ayarı") }
            }
            if (running && !locOn) {
                Text("Konum KAPALI. Android, yakındaki cihaz taraması için konumun açık olmasını ister.", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                TextButton({ ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Konum ayarı") }
            }
            if (running && btOn && peers.isEmpty()) Text("Aranıyor… Karşı telefonda da Yakındakiler taraması AÇIK ve ekran açık olsun. Bağlanması 10–60 sn sürebilir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (cMembers.isNotEmpty()) Text("Yakınlarım: ${cMembers.size} kişi bağlı (internet, yoksa SMS ile ulaşır; bu sayı 'Bağlı cihaz'dan ayrıdır)",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        }
        Spacer(Modifier.height(8.dp))

        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (feed.isEmpty()) item {
                Card2 {
                    Text("Nasıl çalışır?", style = MaterialTheme.typography.titleMedium)
                    Text("• Taramayı aç; yakındaki telefonlar otomatik bağlanır.\n• Mesajlar bağlı telefonlardan başkalarına da aktarılır (zincirleme, en fazla 8 atlama).\n" +
                        "• Menzil açık alanda ~30–100 m'dir; enkazda/binada çok daha azdır. Garantili değildir; 112/AFAD'ın yerine geçmez.\n" +
                        "• SOS mesajları yakındaki herkese görünür. Aile mesajları için Ayarlar'dan aile kodu belirle.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(feed, key = { it.id }) { m -> MsgBubble(m, mine = m.from == Mesh.myId) }
        }

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            AssistChip({ Mesh.send(MsgType.SAFE, "Güvendeyim"); toast(ctx, "Gönderildi ✓ (${Mesh.connectedCount} bağlı cihaz)") }, { Text("Güvendeyim") })
            AssistChip({ Mesh.send(MsgType.INJURED, "Yaralıyım"); toast(ctx, "Gönderildi ✓ (${Mesh.connectedCount} bağlı cihaz)") }, { Text("Yaralıyım") })
            AssistChip({ Mesh.send(MsgType.SOS, "Enkaz altındayım!"); toast(ctx, "SOS gönderildi ✓ (${Mesh.connectedCount} bağlı cihaz)") }, { Text("SOS") },
                colors = AssistChipDefaults.assistChipColors(labelColor = DK.Danger))
        }
        if (cMembers.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Kime:", fontSize = 13.sp)
                FilterChip(!toRelatives, { toRelatives = false }, label = { Text("Yakındaki kullanıcılar") })
                FilterChip(toRelatives, { toRelatives = true }, label = { Text("Yakınlarım") })
            }
            if (toRelatives) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selMember == null, { selMember = null }, label = { Text("Hepsi") })
                cMembers.forEach { m -> FilterChip(selMember == m.id, { selMember = m.id }, label = { Text(m.name) }) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Mesaj yaz…") }, maxLines = 3)
            IconButton({
                if (text.isNotBlank()) {
                    if (cMembers.any { it.phone.isNotBlank() } && !Perms.has(ctx, arrayOf(android.Manifest.permission.SEND_SMS))) smsPerm.launch(android.Manifest.permission.SEND_SMS)
                    val msgText = text.trim()
                    if (toRelatives && cMembers.isNotEmpty()) {
                        val target = cMembers.firstOrNull { it.id == selMember }
                        if (target != null) app.depremkalkani.data.Circles.send(target, app.depremkalkani.data.CType.TEXT, msgText)
                        else app.depremkalkani.data.Circles.sendAll(app.depremkalkani.data.CType.TEXT, msgText)
                        toast(ctx, "Yakınına gönderildi ✓ (" + (target?.name ?: "${cMembers.size} kişi") + "; internet yoksa Bluetooth/SMS ile denenir)")
                    } else {
                        Mesh.send(MsgType.TEXT, msgText)
                        toast(ctx, if (Mesh.connectedCount == 0) "Kuyruğa alındı: yakında bağlı cihaz yok, bağlanınca iletilecek" else "Yakındaki ${Mesh.connectedCount} cihaza gönderildi ✓")
                    }
                    text = "" }
            }) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable
private fun MsgBubble(m: MeshMsg, mine: Boolean) {
    val ctx = LocalContext.current
    val c = when (m.type) {
        MsgType.SOS -> DK.Danger; MsgType.INJURED -> DK.Accent2; MsgType.NEED -> DK.Accent2
        MsgType.SAFE -> DK.Teal; MsgType.FELT -> DK.Accent2; MsgType.CIRCLE -> DK.Teal; MsgType.TEXT -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(if (mine) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface).padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text((if (mine) "Sen" else m.nick) + (if (m.lat != null && m.lon != null) " (%.5f, %.5f)".format(java.util.Locale.US, m.lat, m.lon) else ""),
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(Notifs.ago(m.ts), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (m.type != MsgType.TEXT) Text(m.type.label, color = c, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
        if (m.text.isNotBlank()) Text(m.text)
        if (m.lat != null && m.lon != null) {
            val d = Geo.distanceFromMe(m.lat, m.lon)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d?.let { "~${fmtDist(it)} uzakta" } ?: "%.4f, %.4f".format(java.util.Locale.US, m.lat, m.lon), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                TextButton({ Share.geo(ctx, m.lat, m.lon, m.nick) }) { Text("Haritada aç") }
            }
        }
    }
}
