package app.depremkalkani.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.dk
import app.depremkalkani.data.Geo
import app.depremkalkani.data.Notifs
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.mesh.MeshMsg
import app.depremkalkani.mesh.MsgType
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.launch

@Composable
fun MeshScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val scope = rememberCoroutineScope()
    val running by Mesh.running.collectAsState()
    val peers by Mesh.peers.collectAsState()
    val msgs by Mesh.messages.collectAsState()
    val err by Mesh.error.collectAsState()
    val cEvents by app.depremkalkani.data.Circles.events.collectAsState()
    val cMembers by app.depremkalkani.data.Circles.members.collectAsState()
    val acks by Mesh.acks.collectAsState()
    val reads by app.depremkalkani.data.Circles.reads.collectAsState()
    val queuedIds by app.depremkalkani.data.Circles.queued.collectAsState()
    val isPro by ctx.dk.billing.isPro.collectAsState()
    var voiceDlg by remember { mutableStateOf(false) }
    if (voiceDlg) VoiceSendDialog { voiceDlg = false }
    LaunchedEffect(Unit) { app.depremkalkani.mesh.Voice.purge(ctx) }
    var replyTo by remember { mutableStateOf<MeshMsg?>(null) }
    var meshNotif by remember { mutableStateOf(prefs.meshNotif) }
    var autoLoc by remember { mutableStateOf(prefs.sosAutoLoc) }
    var volunteer by remember { mutableStateOf(prefs.volunteer) }
    var shareNearby by remember { mutableStateOf(prefs.sosShareNearby) }
    var circleNotif by remember { mutableStateOf(prefs.circleNotif) }
    var showSettings by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf("nearby") }             // "nearby" | "all" | yakın kimliği
    val toRelatives = sel != "nearby" && (sel == "all" || cMembers.any { it.id == sel })
    val selMember: String? = sel.takeIf { it != "nearby" && it != "all" }
    val feed = remember(msgs, cEvents, cMembers) {
        val circ = cEvents.filter { it.type != app.depremkalkani.data.CType.HELLO || !it.mine }.map {
            MeshMsg(it.id, if (it.mine) Mesh.myId else "c" + it.memberId, if (it.mine) "" else it.name,
                when (it.type) {
                    app.depremkalkani.data.CType.SAFE -> MsgType.SAFE; app.depremkalkani.data.CType.SOS -> MsgType.SOS
                    app.depremkalkani.data.CType.HELP -> MsgType.NEED; else -> MsgType.TEXT
                },
                (if (it.mine) "${it.name} kişisine: " else "(Yakınım) ") + (if (it.type == app.depremkalkani.data.CType.TEXT || it.text.isNotBlank()) it.text.ifBlank { it.type.label } else it.type.label),
                if (it.mine) Geo.lat else cMembers.firstOrNull { m -> m.id == it.memberId }?.lat,
                if (it.mine) Geo.lon else cMembers.firstOrNull { m -> m.id == it.memberId }?.lon,
                it.ts, 0, "")
        }
        (msgs + circ).sortedBy { it.ts }
    }
    val smsPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    var text by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf(prefs.nick) }
    val listState = rememberLazyListState()
    var btOn by remember { mutableStateOf(true) }
    var locOn by remember { mutableStateOf(true) }
    // ekran açıkken: yakın mesajlarını sık çek, görülenleri karşıya bildir
    LaunchedEffect(Unit) {
        while (true) {
            runCatching { app.depremkalkani.data.Circles.pollNow() }
            kotlinx.coroutines.delay(6000)
        }
    }
    LaunchedEffect(feed.size, cEvents.size) {
        Mesh.markSeen(); app.depremkalkani.data.Circles.markSeen()
    }
    LaunchedEffect(btOn) { if (btOn && running) Mesh.rescan() }
    LaunchedEffect(Unit) {
        while (true) {
            btOn = ctx.getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter?.isEnabled ?: false
            locOn = if (android.os.Build.VERSION.SDK_INT >= 28) ctx.getSystemService(android.location.LocationManager::class.java)?.isLocationEnabled ?: true else true
            kotlinx.coroutines.delay(2000)
        }
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        scope.launch { LocationHelper.refresh(ctx) }
        Mesh.start()
    }
    var nearAsk by remember { mutableStateOf(false) }
    var askName by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf("") }
    fun startScan() {
        if (Perms.hasNearby(ctx)) { scope.launch { LocationHelper.refresh(ctx) }; Mesh.start() }
        else nearAsk = true
    }
    fun toggle() {
        if (running) Mesh.stop()
        else if (!prefs.nickAsked && prefs.nick.isBlank()) { nameDraft = ""; askName = true }
        else if (Perms.hasNearby(ctx)) { scope.launch { LocationHelper.refresh(ctx) }; Mesh.start() }
        else nearAsk = true
    }
    var smsAsk by remember { mutableStateOf(false) }
    fun sendText(raw: String) {
        if (cMembers.any { it.phone.isNotBlank() } && !Perms.has(ctx, arrayOf(android.Manifest.permission.SEND_SMS)) && isPro) smsAsk = true
                    val msgText = (replyTo?.let { r -> "Yanıt, " + (if (r.from == Mesh.myId) "Sen" else r.nick) + ": \"" + r.text.lineSequence().last().take(40) + "\"\n" } ?: "") + raw.trim()
                    replyTo = null
                    if (toRelatives && cMembers.isNotEmpty()) {
                        val target = cMembers.firstOrNull { it.id == selMember }
                        if (target != null) app.depremkalkani.data.Circles.send(target, app.depremkalkani.data.CType.TEXT, msgText)
                        else app.depremkalkani.data.Circles.sendAll(app.depremkalkani.data.CType.TEXT, msgText)
                        toast(ctx, "Yakınına gönderildi ✓ (" + (target?.name ?: "${cMembers.size} kişi") + "; internet olmasa da ulaştırılmaya çalışılır)")
                    } else {
                        Mesh.send(MsgType.TEXT, msgText)
                        toast(ctx, if (Mesh.connectedCount == 0) "Kuyruğa alındı: yakında bağlı cihaz yok, bağlanınca iletilecek" else "Yakındaki ${Mesh.connectedCount} cihaza gönderildi ✓")
                    }
    }
    LaunchedEffect(feed.size) { if (feed.isNotEmpty()) listState.animateScrollToItem(feed.size - 1) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(top = 12.dp)) {
        val scanning by Mesh.scanning.collectAsState()
        val relFound = peers.values.mapNotNull { p -> cMembers.firstOrNull { it.dev.isNotBlank() && it.dev == p.devId }?.name }.distinct()
        val warn = when {
            running && !btOn -> "Bluetooth kapalı"
            running && !locOn -> "Konum kapalı"
            err != null -> "Uyarı var"
            else -> null
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Yakındakiler", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            IconButton({ showSettings = true }) { Icon(Icons.Filled.Settings, "Yakındakiler ayarları") }
        }
        PermBanner("nearby", "Yakındaki cihazlar izni kapalı (Bluetooth ve konum). Çevrendeki kullanıcıları bulabilmek için gerekli.", Perms.nearby,
            { Perms.hasNearby(ctx) }, modifier = Modifier.padding(bottom = 6.dp))
        PermBanner("notif", "Bildirim izni kapalı: yakınlarından ve çevrenden gelen mesajları göremezsin.", Perms.notification,
            { Perms.notification.isEmpty() || Perms.has(ctx, Perms.notification) }, modifier = Modifier.padding(bottom = 6.dp))
        Card2(brush = if (running) DK.Cool else null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (running) { RadarPulse(searching = peers.values.none { it.connected }); Spacer(Modifier.width(10.dp)) }
                Column(Modifier.weight(1f)) {
                    Text(if (!running) "Tarama kapalı" else if (peers.values.any { it.connected }) "Bağlandı" else if (peers.isNotEmpty()) "Cihaz bulundu, bağlanıyor…" else "Yakındaki cihazlar aranıyor…", style = MaterialTheme.typography.titleSmall)
                    Text("Bulunan: ${peers.size} • Bağlı: ${peers.values.count { it.connected }}" + (if (relFound.isNotEmpty()) " • Yakınların: " + relFound.joinToString() else ""),
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    warn?.let { Text("⚠ $it — ayarlara dokun", fontSize = 12.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.clickable { showSettings = true }) }
                }
                if (running) TextButton({ Mesh.rescan() }, enabled = !scanning, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    if (scanning) { CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp); Spacer(Modifier.width(6.dp)); Text("Taranıyor", fontSize = 12.sp) }
                    else Text("Yeniden tara", fontSize = 12.sp)
                }
                Switch(running, { toggle() })
            }
        }
        Spacer(Modifier.height(6.dp))

        if (smsAsk) ExplainDialog("SMS izni", "İnternet ve yakın cihaz yokken, yakınlarına acil durum SMS'i gönderebilmek için. Sadece sen mesaj yazdığında ve başka yol kalmadığında kullanılır.",
            onOk = { smsAsk = false; smsPerm.launch(android.Manifest.permission.SEND_SMS) }, onCancel = { smsAsk = false })
        if (nearAsk) ExplainDialog("Yakındaki cihazlar izni", "Bluetooth ve yakın cihaz izni, internet yokken çevrendeki Deprem Kalkanı kullanıcılarını bulup mesaj ve SOS iletebilmek için gerekir. Android bunun için konum iznini de ister; konumun kaydedilmez.",
            onOk = { nearAsk = false; perm.launch((Perms.nearby + Perms.notification).distinct().toTypedArray()) }, onCancel = { nearAsk = false })

        if (askName) AlertDialog(
            onDismissRequest = { askName = false },
            title = { Text("Adın ne?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Yakındakiler mesaj gönderdiğinde bu ad görünür. Sonra Yakındakiler ayarlarından (dişli simgesi) değiştirebilirsin.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(nameDraft, { nameDraft = it }, label = { Text("Adın") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = { TextButton({
                prefs.nick = nameDraft.trim(); nick = prefs.nick; prefs.nickAsked = true; askName = false; startScan()
            }) { Text("Devam") } },
            dismissButton = { TextButton({ prefs.nickAsked = true; askName = false; startScan() }) { Text("Şimdi değil") } }
        )

        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton({ showSettings = false }) { Text("Tamam") } },
            title = { Text("Yakındakiler ayarları") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("İnternet ve şebeke olmadan, yakındaki Deprem Kalkanı kullanıcılarıyla mesajlaşırsın.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SwitchRow("Yakın cihaz taraması", "Çevredeki telefonları bulur ve bağlanır.", running) { toggle() }
                    OutlinedTextField(nick, { nick = it; prefs.nick = it }, label = { Text("Adın (yakınların görür)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    SwitchRow("Yardım edebilirim (gönüllü)", "Yakınındaki SOS çağrılarında 112/AFAD hatırlatmalı öncelikli bildirim alırsın. Resmî görevli doğrulaması değildir.", volunteer) { volunteer = it; prefs.volunteer = it }
                    SwitchRow("SOS'ta yaklaşık konumum gönüllülere görünsün", "Kapalıyken yakındakilere konum gitmez; açıkken ~200 m yuvarlanmış alan gider. Yakınlarına tam konum her zaman gider.", shareNearby) { shareNearby = it; prefs.sosShareNearby = it }
                    SwitchRow("SOS'tayken tam konumu otomatik paylaş", "Konum isteyen gönüllüye onay beklemeden tam konum gider. Telefonu kullanamayacak durumda olursan işe yarar.", autoLoc) { autoLoc = it; prefs.sosAutoLoc = it }
                    SwitchRow("Yakındakiler bildirimleri", "Yakındaki kullanıcılardan mesaj gelince bildir (SOS çağrıları her zaman bildirilir).", meshNotif) { meshNotif = it; prefs.meshNotif = it }
                    if (cMembers.isNotEmpty()) SwitchRow("Yakınlarım mesaj bildirimleri", "Yakınlarının yazdığı mesajlar (Güvendeyim/yardım çağrıları her zaman bildirilir).", circleNotif) { circleNotif = it; prefs.circleNotif = it }
                    if (running && !btOn) {
                        Text("Bluetooth KAPALI. Yakındaki telefonları bulmak için Bluetooth'u aç.", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                        TextButton({ ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Bluetooth ayarı") }
                    }
                    if (running && !locOn) {
                        Text("Konum KAPALI. Android, yakındaki cihaz taraması için konumun açık olmasını ister.", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                        TextButton({ ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Konum ayarı") }
                    }
                    err?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        if (it.contains("izni")) TextButton({
                            ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${ctx.packageName}")).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                        }) { Text("Uygulama izinlerini aç") }
                    }
                    if (running && btOn && peers.isEmpty()) Text("Aranıyor… Karşı telefonda da Yakındakiler taraması AÇIK ve ekran açık olsun. Bağlanması 10–60 sn sürebilir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (cMembers.isNotEmpty()) Text("Yakınlarım: ${cMembers.size} kişi (internet olmasa da ulaştırılmaya çalışılır; 'Bağlı' sayısından ayrıdır)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
        )

        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (feed.isEmpty()) item {
                Card2 {
                    Text("Nasıl çalışır?", style = MaterialTheme.typography.titleMedium)
                    Text("• Taramayı aç; yakındaki telefonlar otomatik bağlanır.\n• Mesajlar bağlı telefonlardan başkalarına da aktarılır (zincirleme, en fazla 8 atlama).\n" +
                        "• Menzil açık alanda ~30–100 m'dir; enkazda/binada çok daha azdır. Garantili değildir; 112/AFAD'ın yerine geçmez.\n" +
                        "• SOS mesajları yakındaki herkese görünür. Aile mesajları için Ayarlar'dan aile kodu belirle.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(feed.filter { it.type != MsgType.ACK }, key = { it.id }) { m ->
                val relByDev = cMembers.filter { it.dev.isNotBlank() }.associate { it.dev to it.name }
                val devs = acks[m.id] ?: emptySet()
                val relNames = (devs.mapNotNull { relByDev[it] } + (reads[m.id] ?: emptySet())).toSet()
                val others = devs.count { relByDev[it] == null }
                MsgBubble(m, mine = m.from == Mesh.myId, relNames = relNames, others = others, queued = m.id in queuedIds, onReply = { replyTo = m })
            }
        }

        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            AssistChip({ Mesh.send(MsgType.SAFE, "Güvendeyim"); toast(ctx, "Gönderildi ✓ (${Mesh.connectedCount} bağlı cihaz)") }, { Text("Güvendeyim") })
            AssistChip({ Mesh.send(MsgType.INJURED, "Yaralıyım"); toast(ctx, "Gönderildi ✓ (${Mesh.connectedCount} bağlı cihaz)") }, { Text("Yaralıyım") })
            AssistChip({ Mesh.send(MsgType.SOS, "Enkaz altındayım!"); toast(ctx, "SOS gönderildi ✓ (${Mesh.connectedCount} bağlı cihaz)") }, { Text("SOS") },
                colors = AssistChipDefaults.assistChipColors(labelColor = DK.Danger))
        }
        AssistChip({ voiceDlg = true }, { Text("Sesli mesaj") })
        if (cMembers.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Kime:", fontSize = 12.sp)
            FilterChip(sel == "nearby", { sel = "nearby" }, label = { Text("Yakındakiler") })
            FilterChip(sel == "all", { sel = "all" }, label = { Text("Tüm yakınlarım") })
            cMembers.forEach { m -> FilterChip(sel == m.id, { sel = m.id }, label = { Text(m.name) }) }
        }
        replyTo?.let { r ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(start = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Yanıt: " + (if (r.from == Mesh.myId) "Sen" else r.nick) + " - " + r.text.lineSequence().last().take(50),
                    fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                IconButton({ replyTo = null }) { Icon(Icons.Filled.Close, "Yanıtı iptal et") }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Mesaj yaz…") }, maxLines = 3)
            IconButton({
                if (text.isNotBlank()) { sendText(text); text = "" }
            }) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable
private fun MsgBubble(m: MeshMsg, mine: Boolean, relNames: Set<String>, others: Int, queued: Boolean = false, onReply: () -> Unit) {
    val ctx = LocalContext.current
    val c = when (m.type) {
        MsgType.SOS -> DK.Danger; MsgType.INJURED -> DK.Accent2; MsgType.NEED -> DK.Accent2
        MsgType.SAFE -> DK.Teal; MsgType.FELT -> DK.Accent2; MsgType.CIRCLE -> DK.Teal; MsgType.ACK -> DK.Teal; MsgType.LOCREQ -> DK.Accent2; MsgType.LOCOK -> DK.Teal; MsgType.VOICE -> DK.Accent2; MsgType.TEXT -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onReply() }
            .background(if (mine) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface).padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text((if (mine) "Sen" else m.nick) + (if (m.lat != null && m.lon != null) " (%.5f, %.5f)".format(java.util.Locale.US, m.lat, m.lon) else ""),
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(Notifs.ago(m.ts), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (m.type != MsgType.TEXT) Text(m.type.label, color = c, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
        if (m.text.isNotBlank()) {
            val lines = m.text.lines()
            if (lines.size > 1 && lines[0].startsWith("Yanıt, ")) {
                Text(lines[0].removePrefix("Yanıt, "), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 3.dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.background).padding(horizontal = 8.dp, vertical = 4.dp))
                Text(lines.drop(1).joinToString("\n"))
            } else Text(m.text)
        }
        if (m.type == MsgType.VOICE) VoiceControls(m, mine)
        if (!mine && m.type == MsgType.SOS && !m.text.startsWith("(Yakınım)")) {
            var asked by remember(m.id) { mutableStateOf(false) }
            TextButton({ Mesh.requestLocation(m); asked = true; toast(ctx, "Tam konum isteği gönderildi") }, enabled = !asked) {
                Text(if (asked) "Konum isteği gönderildi" else "Tam konum iste")
            }
        }
        if (!mine && m.type == MsgType.LOCREQ) {
            val done by Mesh.answered.collectAsState()
            TextButton({ Mesh.approveLocation(m); toast(ctx, "Tam konum paylaşıldı") }, enabled = m.id !in done) {
                Text(if (m.id in done) "Konum paylaşıldı ✓" else "Tam konumumu paylaş")
            }
        }
        if (mine) {
            val total = relNames.size + others
            Text(when {
                total > 0 -> "✓ Görüldü • $total kişi" + (if (relNames.isNotEmpty()) " (" + relNames.joinToString() + ")" else "")
                queued -> "Sırada: internet ya da yakın cihaz bağlanınca iletilecek"
                else -> "Gönderildi"
            }, fontSize = 11.sp, color = if (total > 0) DK.Teal else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (m.lat != null && m.lon != null) {
            val d = Geo.distanceFromMe(m.lat, m.lon)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d?.let { "~${fmtDist(it)} uzakta" } ?: "%.4f, %.4f".format(java.util.Locale.US, m.lat, m.lon), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                TextButton({ Share.geo(ctx, m.lat, m.lon, m.nick) }) { Text("Haritada aç") }
            }
        }
    }
}

/** Tarama animasyonu: aranırken yayılan halkalar (turuncu), bağlanınca sabit yeşil nokta. */
@Composable
private fun RadarPulse(searching: Boolean) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "p")
    val dot = if (searching) androidx.compose.ui.graphics.Color(0xFFFFB020) else DK.Teal
    Canvas(Modifier.size(44.dp)) {
        val c = size.minDimension / 2
        if (searching) for (k in 0..2) {
            val q = (p + k / 3f) % 1f
            drawCircle(dot.copy(alpha = (1f - q) * 0.7f), radius = c * q, style = Stroke(width = 3f))
        }
        drawCircle(dot, radius = c * 0.22f)
    }
}
