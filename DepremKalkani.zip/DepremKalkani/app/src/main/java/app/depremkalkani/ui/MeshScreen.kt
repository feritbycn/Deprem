package app.depremkalkani.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.dk
import app.depremkalkani.data.Geo
import app.depremkalkani.data.Notifs
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.mesh.MeshMsg
import app.depremkalkani.mesh.MsgType
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.launch

@Composable
fun MeshScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val scope = rememberCoroutineScope()
    val running by Mesh.running.collectAsState()
    val peers by Mesh.peers.collectAsState()
    val msgs by Mesh.messages.collectAsState()
    val err by Mesh.error.collectAsState()
    val cEvents by app.depremkalkani.data.Circles.events.collectAsState()
    val cMembers by app.depremkalkani.data.Circles.members.collectAsState()
    val acks by Mesh.acks.collectAsState()
    val reads by app.depremkalkani.data.Circles.reads.collectAsState()
    val queuedIds by app.depremkalkani.data.Circles.queued.collectAsState()
    val isPro by ctx.dk.billing.isPro.collectAsState()
    var voiceDlg by remember { mutableStateOf(false) }
    if (voiceDlg) VoiceSendDialog { voiceDlg = false }
    LaunchedEffect(Unit) { app.depremkalkani.mesh.Voice.purge(ctx) }
    var replyTo by remember { mutableStateOf<MeshMsg?>(null) }
    var meshNotif by remember { mutableStateOf(prefs.meshNotif) }
    var autoLoc by remember { mutableStateOf(prefs.sosAutoLoc) }
    var volunteer by remember { mutableStateOf(prefs.volunteer) }
    var shareNearby by remember { mutableStateOf(prefs.sosShareNearby) }
    var circleNotif by remember { mutableStateOf(prefs.circleNotif) }
    var showSettings by remember { mutableStateOf(false) }
    var showMuted by remember { mutableStateOf(false) }
    var locDlg by remember { mutableStateOf(false) }
    var infoDlg by remember { mutableStateOf(false) }
    var infoTab by remember { mutableIntStateOf(0) }
    var infoSeen by remember { mutableStateOf(prefs.sp.getBoolean("info_seen", false)) }
    var wifiShareDlg by remember { mutableStateOf(false) }
    var wifiShare by remember { mutableStateOf(prefs.wifiShareOn) }
    var wSsid by remember { mutableStateOf(prefs.wifiSsid) }
    var wPass by remember { mutableStateOf(prefs.wifiPass) }
    var wifiShow by remember { mutableStateOf(false) }
    var wifiStatus by remember { mutableStateOf<String?>(null) }
    val wifiReqs by Mesh.wifiRequests.collectAsState()
    val wifiOffer by Mesh.wifiOffer.collectAsState()
    var askStatus by remember { mutableStateOf<Pair<MsgType, String>?>(null) }
    askStatus?.let { a ->
        StatusConfirmDialog(a.first, onOk = {
            askStatus = null
            Mesh.send(a.first, a.second)
            toast(ctx, (if (a.first == MsgType.SOS) "SOS gönderildi ✓" else "Gönderildi ✓") + " (${Mesh.connectedCount} bağlı cihaz)")
        }, onCancel = { askStatus = null })
    }
    var sel by remember { mutableStateOf("nearby") }             // "nearby" | "all" | yakın kimliği
    val toRelatives = sel != "nearby" && (sel == "all" || cMembers.any { it.id == sel })
    val selMember: String? = sel.takeIf { it != "nearby" && it != "all" }
    val feed = remember(msgs, cEvents, cMembers) {
        val circ = cEvents.filter { it.type != app.depremkalkani.data.CType.HELLO || !it.mine }.map {
            MeshMsg(it.id, if (it.mine) Mesh.myId else "c" + it.memberId, if (it.mine) "" else it.name,
                when (it.type) {
                    app.depremkalkani.data.CType.SAFE -> MsgType.SAFE; app.depremkalkani.data.CType.SOS -> MsgType.SOS
                    app.depremkalkani.data.CType.HELP -> MsgType.NEED; app.depremkalkani.data.CType.VOICE -> MsgType.VOICE; else -> MsgType.TEXT
                },
                (if (it.mine) "${it.name} kişisine: " else "(Yakınım) ") + (if (it.type == app.depremkalkani.data.CType.TEXT || it.text.isNotBlank()) it.text.ifBlank { it.type.label } else it.type.label),
                if (it.mine) Geo.lat else cMembers.firstOrNull { m -> m.id == it.memberId }?.lat,
                if (it.mine) Geo.lon else cMembers.firstOrNull { m -> m.id == it.memberId }?.lon,
                it.ts, 0, "")
        }
        (msgs + circ).sortedBy { it.ts }
    }
    var tab by remember { mutableStateOf("chat") }   // chat = sohbet, ev = SOS/konum/sistem olayları
    var muted by remember { mutableStateOf(prefs.mutedDevs) }
    var fil by remember { mutableStateOf("all") }   // all | rel | near | sos | voice | m:<yakın id>
    var cardOpen by remember { mutableStateOf(false) }
    val evMember = remember(cEvents) { cEvents.associate { it.id to it.memberId } }
    fun isChat(m: MeshMsg) = m.type == MsgType.TEXT || m.type == MsgType.VOICE
    val shown = remember(feed, fil, evMember, tab, muted) {
        feed.filter { it.type != MsgType.ACK && !(it.type == MsgType.TEXT && it.text in setOf("Wi-Fi arıyor", "Wi-Fi paylaşıldı", "Wi-Fi'ye bağlandı", "Wi-Fi'ye bağlandı ✓")) && (isChat(it) == (tab == "chat")) && it.from !in muted }.filter { m ->
            val circ = m.id in evMember
            when {
                fil == "rel" -> circ
                fil == "near" -> !circ
                fil == "sos" -> m.type == MsgType.SOS || m.type == MsgType.INJURED || m.type == MsgType.NEED
                fil == "voice" -> m.type == MsgType.VOICE
                fil.startsWith("m:") -> evMember[m.id] == fil.removePrefix("m:")
                else -> true
            }
        }
    }
    var seenChatTs by remember { mutableStateOf(System.currentTimeMillis()) }
    var seenEvTs by remember { mutableStateOf(System.currentTimeMillis()) }
    val unreadChat = feed.count { it.from != Mesh.myId && it.type != MsgType.ACK && isChat(it) && it.from !in muted && it.ts > seenChatTs }
    val unreadEv = feed.count { it.from != Mesh.myId && it.type != MsgType.ACK && !isChat(it) && it.ts > seenEvTs }
    LaunchedEffect(tab, feed.size) { if (tab == "chat") seenChatTs = System.currentTimeMillis() else seenEvTs = System.currentTimeMillis() }
    val smsPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val addNet = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val o = Mesh.wifiOffer.value
        if (o != null) {
            if (res.resultCode != android.app.Activity.RESULT_OK) wifiStatus = "İptal edildi. Bağlan'a basıp Kaydet'e dokun."
            else {
                wifiStatus = "Kaydedildi. Telefon ağa bağlanıyor…"
                scope.launch {
                    var ok = false
                    repeat(8) { if (!ok) { if (app.depremkalkani.mesh.WifiLink.connectedTo(ctx, o.ssid)) ok = true else kotlinx.coroutines.delay(1000) } }
                    if (ok) { wifiStatus = "Bağlandı ✓"; Mesh.sendWifiAck(o.from) }
                    else if (android.os.Build.VERSION.SDK_INT >= 29) {
                        // Telefon zaten başka bir Wi-Fi'deyse kayıtlı ağa kendiliğinden geçmez: doğrudan bağlanmayı zorla
                        wifiStatus = "Telefon şu anki ağında kaldı. Doğrudan bağlanılıyor… Çıkan pencerede \"" + o.ssid + "\" ağını onayla."
                        app.depremkalkani.mesh.WifiLink.connect(ctx, o.ssid, o.pass) { ok2, msg ->
                            wifiStatus = msg
                            if (ok2) Mesh.sendWifiAck(o.from)
                        }
                    }
                    else wifiStatus = "Henüz bağlanamadı. Paylaşanın hotspot'u açık mı? Hotspot \"gizli\" ise bulunamaz: paylaşandan Erişim noktası ayarlarında \"Erişim noktasını gizle\"yi kapatmasını iste."
                }
            }
        }
    }
    var text by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf(prefs.nick) }
    val listState = rememberLazyListState()
    var btOn by remember { mutableStateOf(true) }
    var locOn by remember { mutableStateOf(true) }
    // ekran açıkken: yakın mesajlarını sık çek, görülenleri karşıya bildir
    LaunchedEffect(Unit) {
        while (true) {
            runCatching { app.depremkalkani.data.Circles.pollNow() }
            kotlinx.coroutines.delay(6000)
        }
    }
    LaunchedEffect(feed.size, cEvents.size) {
        Mesh.markSeen(); app.depremkalkani.data.Circles.markSeen()
    }
    LaunchedEffect(btOn) { if (btOn && running) Mesh.rescan() }
    LaunchedEffect(Unit) {
        while (true) {
            btOn = ctx.getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter?.isEnabled ?: false
            locOn = if (android.os.Build.VERSION.SDK_INT >= 28) ctx.getSystemService(android.location.LocationManager::class.java)?.isLocationEnabled ?: true else true
            kotlinx.coroutines.delay(2000)
        }
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        scope.launch { LocationHelper.refresh(ctx) }
        Mesh.start()
    }
    var nearAsk by remember { mutableStateOf(false) }
    var askName by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf("") }
    fun startScan() {
        if (Perms.hasNearby(ctx)) { scope.launch { LocationHelper.refresh(ctx) }; Mesh.start() }
        else nearAsk = true
    }
    fun toggle() {
        if (running) Mesh.stop()
        else if (!prefs.nickAsked && prefs.nick.isBlank()) { nameDraft = ""; askName = true }
        else if (Perms.hasNearby(ctx)) { scope.launch { LocationHelper.refresh(ctx) }; Mesh.start() }
        else nearAsk = true
    }
    var smsAsk by remember { mutableStateOf(false) }
    fun sendText(raw: String) {
        if (cMembers.any { it.phone.isNotBlank() } && !Perms.has(ctx, arrayOf(android.Manifest.permission.SEND_SMS)) && isPro) smsAsk = true
                    val msgText = (replyTo?.let { r -> "Yanıt, " + (if (r.from == Mesh.myId) "Sen" else r.nick) + ": \"" + r.text.lineSequence().last().take(40) + "\"\n" } ?: "") + raw.trim()
                    replyTo = null
                    if (toRelatives && cMembers.isNotEmpty()) {
                        val target = cMembers.firstOrNull { it.id == selMember }
                        if (target != null) app.depremkalkani.data.Circles.send(target, app.depremkalkani.data.CType.TEXT, msgText)
                        else app.depremkalkani.data.Circles.sendAll(app.depremkalkani.data.CType.TEXT, msgText)
                        toast(ctx, "Yakınına gönderildi ✓ (" + (target?.name ?: "${cMembers.size} kişi") + "; internet olmasa da ulaştırılmaya çalışılır)")
                    } else {
                        Mesh.send(MsgType.TEXT, msgText, withLocation = false)
                        toast(ctx, if (Mesh.connectedCount == 0) "Kuyruğa alındı: yakında bağlı cihaz yok, bağlanınca iletilecek" else "Yakındaki ${Mesh.connectedCount} cihaza gönderildi ✓")
                    }
    }
    LaunchedEffect(shown.size, fil) { if (shown.isNotEmpty()) listState.animateScrollToItem(shown.size - 1) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(top = 12.dp)) {
        val scanning by Mesh.scanning.collectAsState()
        val relFound = peers.values.mapNotNull { p -> cMembers.firstOrNull { it.dev.isNotBlank() && it.dev == p.devId }?.name }.distinct()
        val warn = when {
            running && !btOn -> "Bluetooth kapalı"
            running && !locOn -> "Konum kapalı"
            err != null -> "Uyarı var"
            else -> null
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Yakındakiler", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            IconButton({ showSettings = true }) { Icon(Icons.Filled.Settings, "Yakındakiler ayarları") }
        }
        PermBanner("nearby", "Yakındaki cihazlar izni kapalı (Bluetooth ve konum). Çevrendeki kullanıcıları bulabilmek için gerekli.", Perms.nearby,
            { Perms.hasNearby(ctx) }, modifier = Modifier.padding(bottom = 6.dp))
        PermBanner("notif", "Bildirim izni kapalı: yakınlarından ve çevrenden gelen mesajları göremezsin.", Perms.notification,
            { Perms.notification.isEmpty() || Perms.has(ctx, Perms.notification) }, modifier = Modifier.padding(bottom = 6.dp))
        val compact = running && warn == null && peers.values.any { it.connected } && !cardOpen
        if (compact) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { cardOpen = true }.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(DK.Teal))
            Spacer(Modifier.width(8.dp))
            Text("Bağlandı • ${peers.values.count { it.connected }} cihaz" + (if (relFound.isNotEmpty()) " • " + relFound.joinToString() else ""), fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
            Text("Detay", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        } else Card2(brush = if (running) DK.Cool else null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (running) { RadarPulse(searching = peers.values.none { it.connected }); Spacer(Modifier.width(10.dp)) }
                Column(Modifier.weight(1f)) {
                    Text(if (!running) "Tarama kapalı" else if (peers.values.any { it.connected }) "Bağlandı" else if (peers.isNotEmpty()) "Cihaz bulundu, bağlanıyor…" else "Yakındaki cihazlar aranıyor…", style = MaterialTheme.typography.titleSmall)
                    Text("Bulunan: ${peers.size} • Bağlı: ${peers.values.count { it.connected }}" + (if (relFound.isNotEmpty()) " • Yakınların: " + relFound.joinToString() else ""),
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    warn?.let { Text("⚠ $it — ayarlara dokun", fontSize = 12.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.clickable { showSettings = true }) }
                }
                if (running) TextButton({ Mesh.rescan() }, enabled = !scanning, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    if (scanning) { CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp); Spacer(Modifier.width(6.dp)); Text("Taranıyor", fontSize = 12.sp) }
                    else Text("Yeniden tara", fontSize = 12.sp)
                }
                Switch(running, { toggle() })
                if (cardOpen) TextButton({ cardOpen = false }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("Küçült", fontSize = 12.sp) }
            }
        }
        Spacer(Modifier.height(4.dp))
        TabRow(selectedTabIndex = if (tab == "chat") 0 else 1, containerColor = androidx.compose.ui.graphics.Color.Transparent) {
            Tab(selected = tab == "chat", onClick = { tab = "chat"; fil = "all" }, text = { Text("Sohbet" + if (unreadChat > 0 && tab != "chat") "  ($unreadChat)" else "") })
            Tab(selected = tab == "ev", onClick = { tab = "ev"; fil = "all" }, text = { Text("Olaylar" + if (unreadEv > 0 && tab != "ev") "  ($unreadEv)" else "") })
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            InfoIconButton(!infoSeen, "Kime gider? Bilgi") {
                infoSeen = true; prefs.sp.edit().putBoolean("info_seen", true).apply()
                infoTab = 0; infoDlg = true
            }
            val noNet = !app.depremkalkani.mesh.WifiLink.online(ctx)
            val urgent = noNet && Mesh.hasActiveSos()
            if (tab == "ev") AssistChip({
                if (!Mesh.requestWifi()) toast(ctx, "Biraz bekle: son istekten bu yana 1 dakika geçmedi.")
                else {
                    if (!running) toggle()
                    toast(ctx, if (Mesh.connectedCount == 0) "İsteğin gönderildi. Şu an yakında aktif kullanıcı yok; biri yaklaşınca ona bildirim gidecek ve paylaşırsa sana haber verilecek. Taramayı açık tut."
                        else "Wi-Fi isteği yakındakilere gönderildi ✓")
                }
            }, { Text(if (urgent) "📶 İnternetim yok: Wi-Fi iste" else "📶 Wi-Fi iste", fontSize = 12.sp) },
                colors = if (urgent) AssistChipDefaults.assistChipColors(containerColor = DK.Accent2.copy(alpha = 0.25f)) else AssistChipDefaults.assistChipColors())
            if (tab == "ev") AssistChip({ wifiShareDlg = true }, { Text("📲 Wi-Fi paylaş", fontSize = 12.sp) })
            if (tab == "chat") FilterChip(meshNotif, { meshNotif = !meshNotif; prefs.meshNotif = meshNotif },
                label = { Text(if (meshNotif) "🔔 Bildirim: Açık" else "🔕 Bildirim: Kapalı", fontSize = 12.sp) })
        }
        if (tab == "chat" && unreadEv > 0) Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp)).background(DK.Danger.copy(alpha = 0.15f))
            .clickable { tab = "ev"; fil = "all" }.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("⚠ $unreadEv yeni acil durum / olay bildirimi", fontSize = 13.sp, color = DK.Danger, modifier = Modifier.weight(1f))
            Text("Görüntüle", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(fil == "all", { fil = "all" }, label = { Text("Hepsi") })
            if (tab == "chat") {
                FilterChip(fil == "rel", { fil = "rel" }, label = { Text("Yakınlarım") })
                FilterChip(fil == "near", { fil = "near" }, label = { Text("Yakındakiler") })
                FilterChip(fil == "voice", { fil = "voice" }, label = { Text("Sesli") })
                cMembers.filter { !it.group }.forEach { cm -> FilterChip(fil == "m:" + cm.id, { fil = "m:" + cm.id }, label = { Text(cm.name) }) }
            } else FilterChip(fil == "sos", { fil = "sos" }, label = { Text("SOS") })
        }
        if (tab == "chat" && sel == "nearby") Text("Yakındaki herkes görür ve içerik şifreli değildir; özel bilgi yazma.", fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp, top = 2.dp))
        Spacer(Modifier.height(4.dp))

        if (smsAsk) ExplainDialog("SMS izni", "İnternet ve yakın cihaz yokken, yakınlarına acil durum SMS'i gönderebilmek için. Sadece sen mesaj yazdığında ve başka yol kalmadığında kullanılır.",
            onOk = { smsAsk = false; smsPerm.launch(android.Manifest.permission.SEND_SMS) }, onCancel = { smsAsk = false })
        if (nearAsk) ExplainDialog("Yakındaki cihazlar izni", "Bluetooth ve yakın cihaz izni, internet yokken çevrendeki Deprem Kalkanı kullanıcılarını bulup mesaj ve SOS iletebilmek için gerekir. Android bunun için konum iznini de ister; konumun kaydedilmez.",
            onOk = { nearAsk = false; perm.launch((Perms.nearby + Perms.notification).distinct().toTypedArray()) }, onCancel = { nearAsk = false })

        if (askName) AlertDialog(
            onDismissRequest = { askName = false },
            title = { Text("Adın ne?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Yakındakiler mesaj gönderdiğinde bu ad görünür. Sonra Yakındakiler ayarlarından (dişli simgesi) değiştirebilirsin.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(nameDraft, { if (app.depremkalkani.data.NickGuard.bad(it)) toast(ctx, "Ad yerine telefon numarası yazılamaz") else nameDraft = it }, label = { Text("Adın") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = { TextButton({
                prefs.nick = nameDraft.trim(); nick = prefs.nick; prefs.nickAsked = true; askName = false; startScan()
            }) { Text("Devam") } },
            dismissButton = { TextButton({ prefs.nickAsked = true; askName = false; startScan() }) { Text("Şimdi değil") } }
        )

        if (wifiReqs.isNotEmpty() || wifiShareDlg) {
            val saved = wSsid.isNotBlank() && wPass.length >= 8
            val canShare = saved
            AlertDialog(
                onDismissRequest = { Mesh.clearWifiRequests(); wifiShareDlg = false },
                title = { WifiTitle(if (wifiReqs.isNotEmpty()) "Wi-Fi isteği" else "Wi-Fi paylaş", if (wifiReqs.isNotEmpty()) "📶" else "📲", DK.Accent2) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(if (wifiReqs.isNotEmpty()) wifiReqs.size.toString() + " kişi Wi-Fi arıyor: " + wifiReqs.joinToString { it.nick.ifBlank { "Anonim" } }
                            else "Şu an Wi-Fi arayan yok.")
                        Text("📱 Yalnızca Deprem Kalkanı yüklü yakındaki telefonlara ulaşır.", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        if (canShare) Text("Hotspot'un açık olsun ve \"Erişim noktasını gizle\" KAPALI olsun (gizliyse diğer telefon bulamaz). Bilgi yalnızca isteyenlere şifreli gider.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else Text("Hotspot bilgin kayıtlı değil. Erişim noktası ayarlarını aç, hotspot'u çalıştır (\"Erişim noktasını gizle\" kapalı olsun); sonra gelip adı ve şifreyi aşağıya yaz.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedTextField(wSsid, { wSsid = it }, label = { Text("Hotspot adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(wPass, { wPass = it }, label = { Text("Hotspot şifresi (en az 8 karakter)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row {
                            TextButton({ app.depremkalkani.mesh.WifiLink.openHotspotSettings(ctx) }) { Text("Erişim noktasını aç") }
                            TextButton({ infoTab = 2; infoDlg = true }) { Text("ⓘ Bilgi") }
                        }
                    }
                },
                confirmButton = { TextButton({
                    val ssid = wSsid.trim(); val pass = wPass
                    if (!canShare) {
                        toast(ctx, "Hotspot bilgisi eksik: erişim noktası ayarları açılıyor.")
                        app.depremkalkani.mesh.WifiLink.openHotspotSettings(ctx)
                    } else {
                        prefs.wifiSsid = ssid; prefs.wifiPass = pass; prefs.wifiShareOn = true; wifiShare = true
                        if (wifiReqs.isNotEmpty()) {
                            val n = Mesh.shareWifi(wifiReqs, ssid, pass)
                            toast(ctx, if (n > 0) "Wi-Fi bilgisi $n kişiye gönderildi ✓ Hotspot'un açık olsun." else "Gönderilemedi.")
                        } else toast(ctx, "Kaydedildi ✓ Biri Wi-Fi isteyince bildirim gelecek.")
                        wifiShareDlg = false
                    }
                }) { Text(if (!canShare) "Erişim noktasını aç" else if (wifiReqs.isNotEmpty()) "Paylaş" else "Kaydet") } },
                dismissButton = { TextButton({ Mesh.clearWifiRequests(); wifiShareDlg = false }) { Text(if (wifiReqs.isNotEmpty()) "Reddet" else "Kapat") } }
            )
        }

        wifiOffer?.let { o ->
            val close = { Mesh.dismissWifiOffer(); wifiStatus = null; wifiShow = false }
            AlertDialog(
                onDismissRequest = close,
                title = { WifiTitle("Wi-Fi paylaşıldı", "✅", DK.Teal) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(o.nick.ifBlank { "Biri" } + " seninle Wi-Fi paylaştı.")
                        if (o.ssid.isNotBlank()) {
                            Text("📶 Wi-Fi: " + o.ssid, fontWeight = FontWeight.Bold)
                            Text("Bağlan'a bas; Android'in açtığı pencerede Kaydet'e dokunursan telefon ağa kendisi bağlanır. Hotspot \"gizli\" ise bulunamaz.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (wifiShow) Text("Ad: " + o.ssid + "\nŞifre: " + o.pass, fontSize = 13.sp)
                            Row {
                                Button({
                                    wifiStatus = "Bağlanılıyor…"
                                    val direct = { app.depremkalkani.mesh.WifiLink.connect(ctx, o.ssid, o.pass) { ok, msg ->
                                        wifiStatus = msg
                                        if (ok) Mesh.sendWifiAck(o.from)
                                    } }
                                    if (android.os.Build.VERSION.SDK_INT >= 30) {
                                        if (runCatching { addNet.launch(app.depremkalkani.mesh.WifiLink.addNetworkIntent(o.ssid, o.pass)) }.isFailure) direct()
                                    } else direct()
                                }) { Text("Wi-Fi'ye bağlan") }
                                TextButton({ wifiShow = !wifiShow }) { Text(if (wifiShow) "Bilgiyi gizle" else "Bilgiyi göster") }
                            }
                        }
                        wifiStatus?.let { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary) }
                    }
                },
                confirmButton = { TextButton(close) { Text("Kapat") } }
            )
        }

        if (infoDlg) InfoTabsDialog(infoTab) { infoDlg = false }

        if (locDlg) AlertDialog(
            onDismissRequest = { locDlg = false },
            title = { Text("Konumunu paylaş") },
            text = { Text("Yakındaki Deprem Kalkanı kullanıcıları yaklaşık konumunu (~200 m) ve adını görecek. Tam konum, yalnızca sen onaylarsan istenen kişiye gider.") },
            confirmButton = { TextButton({
                locDlg = false
                scope.launch {
                    LocationHelper.refresh(ctx)
                    if (Geo.known) { Mesh.send(MsgType.LOC, "Konumumu paylaşıyorum"); toast(ctx, "Konum gönderildi ✓ (${Mesh.connectedCount} bağlı cihaz)") }
                    else toast(ctx, "Konum alınamadı. Konum iznini ve konum servisini kontrol et.")
                }
            }) { Text("Paylaş") } },
            dismissButton = { TextButton({ locDlg = false }) { Text("Vazgeç") } }
        )

        if (showMuted) AlertDialog(
            onDismissRequest = { showMuted = false },
            confirmButton = { TextButton({ showMuted = false }) { Text("Tamam") } },
            dismissButton = { if (muted.isNotEmpty()) TextButton({ muted = emptySet(); prefs.mutedDevs = emptySet(); showMuted = false }) { Text("Hepsini aç") } },
            title = { Text("Susturulanlar") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (muted.isEmpty()) Text("Susturulan kimse yok.", fontSize = 13.sp)
                    muted.toList().forEach { id ->
                        val nm = feed.lastOrNull { it.from == id }?.nick?.takeIf { it.isNotBlank() } ?: "Bilinmeyen kişi"
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(nm)
                                Text("Kimlik: " + id.takeLast(4), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton({ muted = muted - id; prefs.mutedDevs = muted }) { Text("Aç") }
                        }
                    }
                }
            }
        )

        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton({ showSettings = false }) { Text("Tamam") } },
            title = { Text("Yakındakiler ayarları") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("İnternet ve şebeke olmadan, yakındaki Deprem Kalkanı kullanıcılarıyla mesajlaşırsın.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SwitchRow("Yakın cihaz taraması", "Çevredeki telefonları bulur ve bağlanır.", running) { toggle() }
                    OutlinedTextField(nick, { if (app.depremkalkani.data.NickGuard.bad(it)) toast(ctx, "Ad yerine telefon numarası yazılamaz") else { nick = it; prefs.nick = it } }, label = { Text("Adın (yakınların görür)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    SwitchRow("Yardım edebilirim (gönüllü)", "Yakınındaki SOS çağrılarında 112/AFAD hatırlatmalı öncelikli bildirim alırsın. Resmî görevli doğrulaması değildir.", volunteer) { volunteer = it; prefs.volunteer = it }
                    SwitchRow("SOS'ta yaklaşık konumum gönüllülere görünsün", "Kapalıyken yakındakilere konum gitmez; açıkken ~200 m yuvarlanmış alan gider. Yakınlarına tam konum her zaman gider.", shareNearby) { shareNearby = it; prefs.sosShareNearby = it }
                    SwitchRow("SOS'tayken tam konumu otomatik paylaş", "Konum isteyen gönüllüye onay beklemeden tam konum gider. Telefonu kullanamayacak durumda olursan işe yarar.", autoLoc) { autoLoc = it; prefs.sosAutoLoc = it }
                    SwitchRow("Yakındakiler bildirimleri", "Yakındaki kullanıcılardan mesaj gelince bildir (SOS çağrıları her zaman bildirilir).", meshNotif) { meshNotif = it; prefs.meshNotif = it }
                    SwitchRow("Wi-Fi paylaşabilirim", "Biri Wi-Fi isterse bildirim gelir; onaylarsan hotspot bilgin yalnızca ona şifreli gider.", wifiShare) { wifiShare = it; prefs.wifiShareOn = it }
                    if (wifiShare) {
                        OutlinedTextField(wSsid, { wSsid = it; prefs.wifiSsid = it }, label = { Text("Hotspot adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(wPass, { wPass = it; prefs.wifiPass = it }, label = { Text("Hotspot şifresi") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row {
                            TextButton({ app.depremkalkani.mesh.WifiLink.openHotspotSettings(ctx) }) { Text("Hotspot ayarlarını aç") }
                            TextButton({ infoTab = 2; infoDlg = true }) { Text("ⓘ Bilgi") }
                        }
                    }
                    if (muted.isNotEmpty()) TextButton({ showMuted = true }) { Text("Susturulanlar (${muted.size})") }
                    if (cMembers.isNotEmpty()) SwitchRow("Yakınlarım mesaj bildirimleri", "Yakınlarının yazdığı mesajlar (Güvendeyim/yardım çağrıları her zaman bildirilir).", circleNotif) { circleNotif = it; prefs.circleNotif = it }
                    if (running && !btOn) {
                        Text("Bluetooth KAPALI. Yakındaki telefonları bulmak için Bluetooth'u aç.", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                        TextButton({ ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Bluetooth ayarı") }
                    }
                    if (running && !locOn) {
                        Text("Konum KAPALI. Android, yakındaki cihaz taraması için konumun açık olmasını ister.", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                        TextButton({ ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Konum ayarı") }
                    }
                    err?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        if (it.contains("izni")) TextButton({
                            ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${ctx.packageName}")).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                        }) { Text("Uygulama izinlerini aç") }
                    }
                    if (running && btOn && peers.isEmpty()) Text("Aranıyor… Karşı telefonda da Yakındakiler taraması AÇIK ve ekran açık olsun. Bağlanması 10–60 sn sürebilir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (cMembers.isNotEmpty()) Text("Yakınlarım: ${cMembers.size} kişi (internet olmasa da ulaştırılmaya çalışılır; 'Bağlı' sayısından ayrıdır)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
        )

        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (feed.isEmpty()) item {
                Card2 {
                    Text("Nasıl çalışır?", style = MaterialTheme.typography.titleMedium)
                    Text("• Taramayı aç; yakındaki telefonlar otomatik bağlanır.\n• Mesajlar bağlı telefonlardan başkalarına da aktarılır (zincirleme, en fazla 8 atlama).\n" +
                        "• Menzil açık alanda ~30–100 m'dir; enkazda/binada çok daha azdır. Garantili değildir; 112/AFAD'ın yerine geçmez.\n" +
                        "• SOS mesajları yakındaki herkese görünür. Aile mesajları için Ayarlar'dan aile kodu belirle.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (feed.isNotEmpty() && shown.isEmpty()) item {
                Text(if (tab == "chat") "Henüz sohbet mesajı yok. Aşağıdan herkese yazabilirsin." else "Henüz SOS ya da sistem olayı yok.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 20.dp))
            }
            items(shown, key = { it.id }) { m ->
                val relByDev = cMembers.filter { it.dev.isNotBlank() }.associate { it.dev to it.name }
                val devs = acks[m.id] ?: emptySet()
                val relNames = (devs.mapNotNull { relByDev[it] } + (reads[m.id] ?: emptySet())).toSet()
                val others = devs.count { relByDev[it] == null }
                MsgBubble(m, mine = m.from == Mesh.myId, relNames = relNames, others = others, queued = m.id in queuedIds, chat = tab == "chat",
                    onMute = if (tab == "chat" && m.from != Mesh.myId && m.id !in evMember) ({ muted = muted + m.from; prefs.mutedDevs = muted; toast(ctx, "${m.nick} susturuldu") }) else null,
                    onReply = { replyTo = m })
            }
        }

        Spacer(Modifier.height(6.dp))
        if (tab == "ev") {
            Text("Acil durum bildirimi yakındaki herkese gider.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                AssistChip({ askStatus = MsgType.SAFE to "Güvendeyim" }, { Text("Güvendeyim") })
                AssistChip({ askStatus = MsgType.INJURED to "Yaralıyım" }, { Text("Yaralıyım") })
                AssistChip({ askStatus = MsgType.SOS to "Enkaz altındayım!" }, { Text("SOS") },
                    colors = AssistChipDefaults.assistChipColors(labelColor = DK.Danger))
                AssistChip({ locDlg = true }, { Text("📍 Konumumu paylaş") })
            }
            Spacer(Modifier.height(8.dp))
        } else {
        if (cMembers.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Kime:", fontSize = 12.sp)
            FilterChip(sel == "nearby", { sel = "nearby" }, label = { Text("Yakındakiler") })
            FilterChip(sel == "all", { sel = "all" }, label = { Text("Tüm yakınlarım") })
            cMembers.forEach { m -> FilterChip(sel == m.id, { sel = m.id }, label = { Text(m.name) }) }
        }
        replyTo?.let { r ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(start = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Yanıt: " + (if (r.from == Mesh.myId) "Sen" else r.nick) + " - " + r.text.lineSequence().last().take(50),
                    fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                IconButton({ replyTo = null }) { Icon(Icons.Filled.Close, "Yanıtı iptal et") }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            AssistChip({ voiceDlg = true }, { Text("🎤 Sesli mesaj") })
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text(if (sel == "nearby") "Yakındakilere yaz (herkes görür)…" else "Mesaj yaz…") }, maxLines = 3)
            IconButton({
                if (text.isNotBlank()) { sendText(text); text = "" }
            }) { Icon(Icons.AutoMirrored.Filled.Send, "Gönder", tint = MaterialTheme.colorScheme.primary) }
        }
        }
    }
}

@Composable
private fun MsgBubble(m: MeshMsg, mine: Boolean, relNames: Set<String>, others: Int, queued: Boolean = false, chat: Boolean = false, onMute: (() -> Unit)? = null, onReply: () -> Unit) {
    val ctx = LocalContext.current
    val c = when (m.type) {
        MsgType.SOS -> DK.Danger; MsgType.INJURED -> DK.Accent2; MsgType.NEED -> DK.Accent2
        MsgType.SAFE -> DK.Teal; MsgType.FELT -> DK.Accent2; MsgType.CIRCLE -> DK.Teal; MsgType.ACK -> DK.Teal; MsgType.LOCREQ -> DK.Accent2; MsgType.LOCOK -> DK.Teal; MsgType.LOC -> DK.Teal; MsgType.WIFIREQ -> DK.Accent2; MsgType.WIFIOK -> DK.Teal; MsgType.WIFIACK -> DK.Teal; MsgType.VOICE -> DK.Accent2; MsgType.TEXT -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    var dx by remember { mutableFloatStateOf(0f) }
    Box(Modifier.fillMaxWidth()) {
    if (dx > 40f) Text("↩", Modifier.align(Alignment.CenterStart).padding(start = 8.dp), fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (chat && mine) Arrangement.End else Arrangement.Start) {
    Column(
        (if (chat) Modifier.widthIn(max = 300.dp) else Modifier.fillMaxWidth())
            .offset { androidx.compose.ui.unit.IntOffset(dx.toInt(), 0) }
            .pointerInput(m.id, chat) {
                if (!chat) return@pointerInput
                detectHorizontalDragGestures(
                    onDragEnd = { if (dx > 90f) onReply(); dx = 0f },
                    onDragCancel = { dx = 0f },
                ) { _, d -> dx = (dx + d).coerceIn(0f, 160f) }
            }
            .clip(RoundedCornerShape(16.dp))
            .background(if (mine) (if (chat) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) else MaterialTheme.colorScheme.surface).padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!(chat && mine)) Text((if (mine) "Sen" else m.nick),
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f, fill = chat.not()))
            else Spacer(Modifier.weight(1f, fill = false))
            if (chat && !mine) Spacer(Modifier.width(10.dp))
            Text(if (chat) Notifs.hhmm(m.ts) else Notifs.ago(m.ts), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (m.type != MsgType.TEXT) Text(m.type.label, color = c, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
        if (m.text.isNotBlank() && m.type != MsgType.WIFIREQ && m.type != MsgType.WIFIOK) {
            val lines = m.text.lines()
            if (lines.size > 1 && lines[0].startsWith("Yanıt, ")) {
                Text(lines[0].removePrefix("Yanıt, "), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 3.dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.background).padding(horizontal = 8.dp, vertical = 4.dp))
                Text(lines.drop(1).joinToString("\n"))
            } else Text(m.text)
        }
        if (m.type == MsgType.VOICE) VoiceControls(m, mine)
        if (!mine && m.type == MsgType.WIFIREQ) TextButton({
            if (!Mesh.openWifiReq(m.id)) toast(ctx, "Bu isteğin süresi doldu ya da bilgisi artık yok. Karşı taraf yeniden istesin.")
        }) { Text("📲 Wi-Fi'mi paylaş") }
        if (!mine && m.type == MsgType.SOS && !m.text.startsWith("(Yakınım)")) {
            var asked by remember(m.id) { mutableStateOf(false) }
            TextButton({ Mesh.requestLocation(m); asked = true; toast(ctx, "Tam konum isteği gönderildi") }, enabled = !asked) {
                Text(if (asked) "Konum isteği gönderildi" else "Tam konum iste")
            }
        }
        if (!mine && m.type == MsgType.LOCREQ) {
            val done by Mesh.answered.collectAsState()
            TextButton({ Mesh.approveLocation(m); toast(ctx, "Tam konum paylaşıldı") }, enabled = m.id !in done) {
                Text(if (m.id in done) "Konum paylaşıldı ✓" else "Tam konumumu paylaş")
            }
        }
        if (mine) {
            val total = relNames.size + others
            Text(when {
                total > 0 -> (if (m.type == MsgType.VOICE) "✓ Dinlendi • $total kişi" else "✓ Görüldü • $total kişi") + (if (relNames.isNotEmpty()) " (" + relNames.joinToString() + ")" else "")
                queued -> "Sırada: internet ya da yakın cihaz bağlanınca iletilecek"
                else -> "Gönderildi"
            }, fontSize = 11.sp, color = if (total > 0) DK.Teal else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!chat && m.lat != null && m.lon != null) {
            val d = Geo.distanceFromMe(m.lat, m.lon)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d?.let { "~${fmtDist(it)} uzakta" } ?: "%.4f, %.4f".format(java.util.Locale.US, m.lat, m.lon), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                TextButton({ Share.geo(ctx, m.lat, m.lon, m.nick) }) { Text("Haritada aç") }
            }
        }
        if (onMute != null) TextButton({ onMute() }, contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)) { Text("Sustur", fontSize = 11.sp) }
    }
    }
    }
}

/** Tarama animasyonu: aranırken yayılan halkalar (turuncu), bağlanınca sabit yeşil nokta. */
@Composable
private fun RadarPulse(searching: Boolean) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "p")
    val dot = if (searching) androidx.compose.ui.graphics.Color(0xFFFFB020) else DK.Teal
    Canvas(Modifier.size(44.dp)) {
        val c = size.minDimension / 2
        if (searching) for (k in 0..2) {
            val q = (p + k / 3f) % 1f
            drawCircle(dot.copy(alpha = (1f - q) * 0.7f), radius = c * q, style = Stroke(width = 3f))
        }
        drawCircle(dot, radius = c * 0.22f)
    }
}
