package app.depremkalkani.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.dk
import app.depremkalkani.data.*
import app.depremkalkani.sensor.SeismoEngine
import app.depremkalkani.service.MonitorService
import java.util.Locale

// ======================================================================= Daha fazla
enum class Sub { CIRCLE, WAVE, GUIDE, SETTINGS, PRO, ABOUT }

@Composable
fun MoreScreen(onOpen: (Sub) -> Unit) {
    val isPro by LocalContext.current.dk.billing.isPro.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Daha fazla", style = MaterialTheme.typography.headlineLarge)
        if (!isPro) Card2(brush = DK.Hero, onClick = { onOpen(Sub.PRO) }) {
            Text("PRO", color = Color.White.copy(alpha = 0.8f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Reklamsız Deprem Kalkanı", color = Color.White, style = MaterialTheme.typography.titleLarge)
            Text("Tek seferlik ödeme. Reklamlar kalkar, veri 15 sn'de bir yenilenir.", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
        Tile("Yakınlarım", "Aile ve tanıdıklarına \"Güvendeyim\" de, \"Güvende misin?\" sor", { onOpen(Sub.CIRCLE) })
        Tile("Sismograf ve sarsıntı algılayıcı", "Telefonun ivmeölçeriyle canlı dalga grafiği", { onOpen(Sub.WAVE) })
        Tile("Hazırlık ve rehber", "Deprem çantası, ne yapmalı, acil numaralar", { onOpen(Sub.GUIDE) })
        Tile("Ayarlar", "Bildirim, bölge, kaynak, ses, acil kişiler", { onOpen(Sub.SETTINGS) })
        Tile("Hakkında ve gizlilik", "Veri kaynakları ve sınırlar", { onOpen(Sub.ABOUT) })
    }
}

@Composable
private fun Tile(title: String, sub: String, onClick: () -> Unit) {
    Card2(onClick = onClick) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ======================================================================= Sismograf
@Composable
fun WaveScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val wave by SeismoEngine.wave.collectAsState()
    val running by SeismoEngine.running.collectAsState()
    val avail by SeismoEngine.available.collectAsState()
    val sta by SeismoEngine.sta.collectAsState()
    val lta by SeismoEngine.lta.collectAsState()
    val peak by SeismoEngine.peak.collectAsState()
    val trig by SeismoEngine.lastTrigger.collectAsState()
    var bg by remember { mutableStateOf(prefs.shakeDetect) }
    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline

    DisposableEffect(Unit) { SeismoEngine.acquire(ctx, "wave"); onDispose { SeismoEngine.release("wave") } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Sismograf", style = MaterialTheme.typography.headlineLarge)
        if (!avail) Text("Bu cihazda ivmeölçer bulunamadı.", color = MaterialTheme.colorScheme.error)
        Card2 {
            Canvas(Modifier.fillMaxWidth().height(200.dp)) {
                val h = size.height; val w = size.width
                for (i in 0..4) drawLine(grid, Offset(0f, h * i / 4), Offset(w, h * i / 4), 1f)
                if (wave.size > 2) {
                    val p = Path()
                    wave.forEachIndexed { i, v ->
                        val x = w * i / (wave.size - 1)
                        if (i == 0) p.moveTo(x, h - (v.coerceIn(0f, 6f) / 6f) * h) else p.lineTo(x, h - (v.coerceIn(0f, 6f) / 6f) * h)
                    }
                    drawPath(p, line, style = Stroke(width = 3f, cap = StrokeCap.Round))
                }
            }
            Text("Son ~10 sn titreşim genliği (m/s²)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Card2 {
            Row {
                Column(Modifier.weight(1f)) { Text("Anlık (STA)", fontSize = 12.sp); Text("%.2f".format(Locale.US, sta), fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                Column(Modifier.weight(1f)) { Text("Ortalama (LTA)", fontSize = 12.sp); Text("%.2f".format(Locale.US, lta), fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                Column(Modifier.weight(1f)) { Text("Tepe", fontSize = 12.sp); Text("%.2f".format(Locale.US, peak), fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            }
            OutlinedButton({ SeismoEngine.resetPeak() }, Modifier.padding(top = 8.dp)) { Text("Tepe değerini sıfırla") }
            if (trig > 0) Text("Son tetiklenme: ${Notifs.ago(trig)}", color = DK.Accent2, modifier = Modifier.padding(top = 8.dp))
        }
        Card2 {
            SwitchRow("Arka planda sarsıntı algıla", "Telefonu düz bir yüzeyde şarjda bırakırsan daha doğru çalışır. Pil harcar.", bg) {
                bg = it; prefs.shakeDetect = it
                if (it) { if (prefs.monitorOn) MonitorService.start(ctx) } else SeismoEngine.release("svc")
            }
        }
        Text("Tek telefonla algılama yanlış alarm verebilir ve resmî deprem bilgisinin yerine geçmez. Doğru bilgi için AFAD/Kandilli listesine bak.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ======================================================================= Rehber
private val BAG = listOf(
    "Su (kişi başı en az 3 gün yetecek kadar)", "Konserve / enerji barı / kuru gıda", "İlk yardım seti", "Düdük",
    "El feneri + yedek pil", "Powerbank + şarj kablosu", "Pilli / şarjlı radyo", "Kişisel ilaçlar (en az 1 haftalık)",
    "Kimlik ve önemli belge kopyaları (poşette)", "Nakit para", "Battaniye / mont / yedek kıyafet", "Hijyen malzemeleri, maske, eldiven",
    "Kağıt, kalem, aile iletişim listesi", "Bebek / yaşlı / evcil hayvan ihtiyaçları", "Çakmak / su geçirmez kibrit",
)
private val DURING = listOf(
    "ÇÖK – KAPAN – TUTUN: Sağlam bir masa/sıra altında ya da iç duvar dibinde başını ve boynunu koru.",
    "Pencere, ayna, devrilebilecek eşyalardan uzak dur.", "Asansör kullanma; sallanma sırasında koşup merdivene atılma.",
    "Dışarıdaysan bina, direk, kablo ve cam yığınlarından uzak, açık alana geç.", "Araçtaysan güvenli ve açık bir yerde dur, araçta kal.",
)
private val AFTER = listOf(
    "Sarsıntı durunca güvenliysen doğal gazı, elektriği ve suyu kapat.", "Kibrit/çakmak çakma; gaz kokusu varsa hemen uzaklaş.",
    "Binadan sakin şekilde çık, asansörü kullanma, AFAD toplanma alanına git.", "Artçılara hazır ol; hasarlı binaya girme.",
    "Telefonu gereksiz kullanma; mesajlaşmayı ve SMS'i tercih et, hatları 112 için boş bırak.",
)
private val TRAPPED = listOf(
    "Panik yapma, enerjini koru. Ağzını ve burnunu kumaşla kapat.", "Elindeki cihazla (düdük, flaş) ses ve ışık ver; bağırmak yerine düdüğü tercih et.",
    "Boruya veya duvara düzenli vur (3 vuruş, ara, 3 vuruş).", "Uygulamada \"ENKAZ ALTINDAYIM\"ı başlat: düdük + flaş + yakındakilere SOS.",
    "Kibrit/çakmak yakma.", "Hareket edebiliyorsan dengesiz yığınları oynatma.",
)
private val NUMBERS = listOf("112" to "Acil Çağrı", "122" to "AFAD", "110" to "İtfaiye", "155" to "Polis", "156" to "Jandarma", "168" to "Kızılay", "187" to "Doğalgaz acil")

@Composable
fun GuideScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    var checked by remember { mutableStateOf(prefs.bagChecked) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Hazırlık ve rehber", style = MaterialTheme.typography.headlineLarge) }
        item { SectionTitle("Acil numaralar") }
        item {
            Card2 {
                NUMBERS.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (n, l) -> OutlinedButton({ Share.dial(ctx, n) }, Modifier.weight(1f)) { Text("$n  $l", maxLines = 1, fontSize = 13.sp) } }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item { SectionTitle("Deprem anında") }
        item { Card2 { DURING.forEach { Text("• $it", Modifier.padding(vertical = 3.dp)) } } }
        item { SectionTitle("Deprem sonrası") }
        item { Card2 { AFTER.forEach { Text("• $it", Modifier.padding(vertical = 3.dp)) } } }
        item { SectionTitle("Enkaz altında kalırsan") }
        item { Card2 { TRAPPED.forEach { Text("• $it", Modifier.padding(vertical = 3.dp)) } } }
        item { SectionTitle("Deprem çantası (${checked.size}/${BAG.size})") }
        items(BAG) { item ->
            val on = item in checked
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(on, { v -> checked = if (v) checked + item else checked - item; prefs.bagChecked = checked })
                Text(item, Modifier.padding(end = 8.dp))
            }
        }
        item { SectionTitle("Toplanma alanı") }
        item {
            Card2 {
                Text("Harita sekmesinden \"Toplanma alanları\"nı aç; yakınındaki alanlar internet varken kaydedilir, sonra çevrimdışı da görünür.", fontSize = 13.sp)
                OutlinedButton({ Share.url(ctx, Assembly.AFAD_EDEVLET) }, Modifier.padding(top = 8.dp)) { Text("AFAD Acil Toplanma Alanı Sorgulama") }
            }
        }
    }
}

// ======================================================================= Ayarlar
@Composable
fun SettingsScreen(onTestWave: (Quake) -> Unit = {}) {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    var monitor by remember { mutableStateOf(prefs.monitorOn) }
    var minMag by remember { mutableFloatStateOf(prefs.notifMinMag) }
    var sound by remember { mutableStateOf(prefs.sound) }
    var vib by remember { mutableStateOf(prefs.vibrate) }
    var night by remember { mutableStateOf(prefs.nightMode) }
    var sources by remember { mutableStateOf(prefs.sources) }
    var region by remember { mutableStateOf(prefs.region) }
    var provinces by remember { mutableStateOf(prefs.provinces) }
    var radius by remember { mutableIntStateOf(prefs.radiusKm) }
    var feltNotif by remember { mutableStateOf(prefs.feltNotif) }
    var feltThr by remember { mutableIntStateOf(prefs.feltThreshold) }
    var waveKm by remember { mutableIntStateOf(prefs.waveAlertKm) }
    var testKm by remember { mutableIntStateOf(prefs.waveTestKm) }
    var showProv by remember { mutableStateOf(false) }
    var nick by remember { mutableStateOf(prefs.nick) }
    var fam by remember { mutableStateOf(prefs.familyCode) }
    var note by remember { mutableStateOf(prefs.emergencyNote) }
    var c1n by remember { mutableStateOf(prefs.c1n) }; var c1p by remember { mutableStateOf(prefs.c1p) }
    var c2n by remember { mutableStateOf(prefs.c2n) }; var c2p by remember { mutableStateOf(prefs.c2p) }
    var c3n by remember { mutableStateOf(prefs.c3n) }; var c3p by remember { mutableStateOf(prefs.c3p) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (monitor) MonitorService.start(ctx)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ayarlar", style = MaterialTheme.typography.headlineLarge)

        Card2 {
            var accEmail by remember { mutableStateOf(prefs.accountEmail) }
            var accName by remember { mutableStateOf(prefs.accountName) }
            var accMsg by remember { mutableStateOf<String?>(null) }
            val accScope = rememberCoroutineScope()
            Text("Hesap", style = MaterialTheme.typography.titleMedium)
            if (accEmail.isBlank()) {
                Text("Google hesabınla giriş yap; adın otomatik doldurulur. Giriş zorunlu değildir.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                BigButton("Google ile giriş yap", {
                    accScope.launch {
                        accMsg = GoogleAuth.signIn(ctx)
                        accEmail = prefs.accountEmail; accName = prefs.accountName; nick = prefs.nick
                    }
                })
            } else {
                Text(accName.ifBlank { "Giriş yapıldı" }, fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                Text(accEmail, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton({ GoogleAuth.signOut(ctx); accEmail = ""; accName = "" }) { Text("Çıkış yap") }
            }
            accMsg?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        }

        Card2 {
            Text("Bildirimler", style = MaterialTheme.typography.titleMedium)
            SwitchRow("Canlı deprem bildirimi", "Arka planda veriyi takip eder (kalıcı bildirim görünür).", monitor) {
                monitor = it; prefs.monitorOn = it
                if (it) {
                    val need = (Perms.notification + Perms.location)
                    if (Perms.has(ctx, need)) MonitorService.start(ctx) else permLauncher.launch(need)
                } else if (Circles.members.value.isEmpty()) MonitorService.stop(ctx)
            }
            Text("En düşük büyüklük: M%.1f".format(Locale.US, minMag), modifier = Modifier.padding(top = 8.dp))
            Slider(minMag, { minMag = (Math.round(it * 2) / 2f); prefs.notifMinMag = minMag }, valueRange = 2f..7f, steps = 9)
            SwitchRow("Titreşim", checked = vib) { vib = it; prefs.vibrate = it }
            SwitchRow("Gece modu", "23:00–07:00 arası yalnızca M5+ depremlerde bildirim.", night) { night = it; prefs.nightMode = it }
        }

        Card2 {
            Text("Sismik dalga", style = MaterialTheme.typography.titleMedium)
            Text("Tam ekran sismik dalga uyarısı, merkez üssü sana en fazla $waveKm km uzaktaysa açılır (daha uzaktakiler normal bildirim olur).", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Uyarı mesafesi: $waveKm km", modifier = Modifier.padding(top = 6.dp))
            Slider(waveKm.toFloat(), { waveKm = (it / 50).toInt() * 50; prefs.waveAlertKm = waveKm }, valueRange = 50f..1500f)
            Text("Test depreminin uzaklığı: $testKm km", modifier = Modifier.padding(top = 6.dp))
            Slider(testKm.toFloat(), { testKm = ((it / 10).toInt() * 10).coerceAtLeast(10); prefs.waveTestKm = testKm }, valueRange = 10f..500f)
            BigButton("Sismik dalga testi (tam ekran)", { onTestWave(TestQuake.make(testKm)) }, color = DK.Danger)
            OutlinedButton({
                val q = TestQuake.make(testKm)
                Notifs.notifyQuake(ctx, q, prefs)
                toast(ctx, if (Notifs.canPost(ctx)) "Test bildirimi gönderildi — bildirime dokun ✓" else "Bildirim izni kapalı! Uygulama izinlerinden aç.")
            }, Modifier.fillMaxWidth()) { Text("Test bildirimi gönder") }
            OutlinedButton({
                if (android.os.Build.VERSION.SDK_INT >= 34) runCatching {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }, Modifier.fillMaxWidth()) { Text("Kilit ekranında tam ekran izni (Android 14+)") }
            Text("Gerçek bir deprem değildir; yalnızca ekranı ve sesi denemek içindir.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Card2 {
            Text("\"Deprem hissettim\" bildirimleri", style = MaterialTheme.typography.titleMedium)
            SwitchRow("Bölgemde hissedildi uyarısı", "Aynı ilde yeterince kullanıcı \"hissettim\" derse haber ver. Farklı illerdekiler birbirine sayılmaz.", feltNotif) { feltNotif = it; prefs.feltNotif = it }
            Text("Eşik: aynı ilde en az $feltThr kullanıcı", modifier = Modifier.padding(top = 6.dp))
            Slider(feltThr.toFloat(), { feltThr = it.toInt().coerceAtLeast(1); prefs.feltThreshold = feltThr }, valueRange = 1f..30f, steps = 28)
        }

        Card2 {
            Text("Bildirim sesi", style = MaterialTheme.typography.titleMedium)
            Text("Ses değiştirince Android kanal ayarı kullanılır. Sistem ayarlarından sesi ayrıca özelleştirebilirsin.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            AlertSound.values().forEach { s ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(sound == s, { sound = s; prefs.alertSound = s.name })
                    Text(s.label, Modifier.weight(1f))
                    if (s.raw != null) TextButton({ playPreview(ctx, s) }) { Text("Dinle") }
                }
            }
            OutlinedButton({
                ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("Sistem bildirim ayarları") }
        }

        Card2 {
            Text("Hangi bölgeden bildirim gelsin?", style = MaterialTheme.typography.titleMedium)
            RegionMode.values().forEach { m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(region == m, { region = m; prefs.regionMode = m.name })
                    Text(m.label)
                }
            }
            if (region == RegionMode.PROVINCES) {
                OutlinedButton({ showProv = true }) { Text(if (provinces.isEmpty()) "İl seç" else "${provinces.size} il seçili: " + provinces.take(3).joinToString()) }
            }
            if (region == RegionMode.RADIUS) {
                Text("Yarıçap: $radius km (konumuna göre)")
                Slider(radius.toFloat(), { radius = (it / 50).toInt() * 50; prefs.radiusKm = radius }, valueRange = 50f..1000f)
                if (!Geo.known) Text("Konum henüz alınamadı. Konum iznini ver.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        }

        Card2 {
            Text("Veri kaynakları", style = MaterialTheme.typography.titleMedium)
            Sources.ALL.forEach { s ->
                SwitchRow(Sources.label(s), when (s) {
                    Sources.AFAD -> "Türkiye (resmî)"; Sources.KANDILLI -> "Türkiye (Boğaziçi Üniv.)"
                    Sources.EMSC -> "Avrupa-Akdeniz, dünya"; else -> "ABD Jeoloji Servisi, dünya"
                }, s in sources) { on ->
                    sources = if (on) sources + s else (sources - s).ifEmpty { setOf(Sources.AFAD) }; prefs.sources = sources
                }
            }
        }

        Card2 {
            Text("Acil durum bilgilerim", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(nick, { nick = it; prefs.nick = it }, label = { Text("Adın") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(fam, { fam = it; prefs.familyCode = it }, label = { Text("Aile kodu (aynı kodu kullananlar sizin mesajlarınızı görür)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(note, { note = it; prefs.emergencyNote = it }, label = { Text("Tıbbi not (kan grubu, ilaç, alerji)") }, modifier = Modifier.fillMaxWidth())
            Text("Acil kişiler (SMS ile konumun gönderilir)", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            ContactRow(c1n, c1p, { c1n = it; prefs.c1n = it }, { c1p = it; prefs.c1p = it })
            ContactRow(c2n, c2p, { c2n = it; prefs.c2n = it }, { c2p = it; prefs.c2p = it })
            ContactRow(c3n, c3p, { c3n = it; prefs.c3n = it }, { c3p = it; prefs.c3p = it })
        }

        Card2 {
            Text("Cihaz ayarları", style = MaterialTheme.typography.titleMedium)
            Text("Bildirimlerin kapalı uygulamada da gelmesi için pil kısıtlamasını kaldır.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton({
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, Modifier.padding(top = 6.dp)) { Text("Pil optimizasyonu ayarı") }
            OutlinedButton({
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("Uygulama izinleri") }
        }
    }

    if (showProv) {
        AlertDialog(
            onDismissRequest = { showProv = false },
            confirmButton = { TextButton({ showProv = false }) { Text("Tamam") } },
            dismissButton = { TextButton({ provinces = emptySet(); prefs.provinces = emptySet() }) { Text("Temizle") } },
            title = { Text("İl seç") },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(TURKEY_PROVINCES) { p ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(p in provinces, { v -> provinces = if (v) provinces + p else provinces - p; prefs.provinces = provinces })
                            Text(p)
                        }
                    }
                }
            },
        )
    }
}

@Composable
private fun ContactRow(n: String, p: String, onN: (String) -> Unit, onP: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(n, onN, label = { Text("İsim") }, singleLine = true, modifier = Modifier.weight(1f))
        OutlinedTextField(p, onP, label = { Text("Telefon") }, singleLine = true, modifier = Modifier.weight(1f))
    }
}

private var preview: android.media.MediaPlayer? = null
private fun playPreview(ctx: android.content.Context, s: AlertSound) {
    runCatching {
        preview?.release()
        val id = when (s) { AlertSound.SIREN -> app.depremkalkani.R.raw.siren; AlertSound.SOS -> app.depremkalkani.R.raw.sos
            AlertSound.NUCLEAR -> app.depremkalkani.R.raw.nuclear; else -> return }
        preview = android.media.MediaPlayer.create(ctx, id)?.apply { setOnCompletionListener { it.release(); preview = null }; start() }
    }
}

// ======================================================================= Pro
@Composable
fun ProScreen() {
    val ctx = LocalContext.current
    val b = ctx.dk.billing
    val isPro by b.isPro.collectAsState()
    val price by b.price.collectAsState()
    val msg by b.message.collectAsState()
    LaunchedEffect(Unit) { b.connect() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card2(brush = DK.Hero) {
            Text("PRO", color = Color.White.copy(alpha = 0.8f), fontWeight = FontWeight.Bold)
            Text(if (isPro) "Pro etkin — teşekkürler!" else "Deprem Kalkanı Pro", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        }
        Card2 {
            listOf("Tüm reklamlar kalkar", "Deprem verisi 15 sn'de bir yenilenir (ücretsizde 30 sn)", "Geliştirmeyi destekler",
                "Tek seferlik ödeme, abonelik yok").forEach { Text("✓  $it", Modifier.padding(vertical = 4.dp)) }
            Text("Güvenlik özellikleri (düdük, SOS, bildirimler, yakın cihaz mesajı) her zaman ücretsiz kalır.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
        }
        if (!isPro) {
            BigButton(if (price != null) "Pro'ya geç • $price" else "Pro'ya geç", { (ctx as? Activity)?.let { b.buy(it) } })
            OutlinedButton({ b.restore() }, Modifier.fillMaxWidth()) { Text("Satın alımı geri yükle") }
        }
        msg?.let { Text(it, color = DK.Teal) }
    }
}

// ======================================================================= Hakkında
@Composable
fun AboutScreen() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Hakkında", style = MaterialTheme.typography.headlineLarge)
        Card2 {
            Text("Veri kaynakları", style = MaterialTheme.typography.titleMedium)
            Text("Deprem bilgileri AFAD, Kandilli Rasathanesi, EMSC ve USGS'nin herkese açık servislerinden doğrudan çekilir. Toplanma alanları OpenStreetMap katkıcılarına aittir. Harita © OpenStreetMap katkıcıları.", fontSize = 13.sp)
        }
        Card2 {
            Text("Önemli uyarılar", style = MaterialTheme.typography.titleMedium)
            Text("• Bu uygulama resmî bir kurum uygulaması değildir; erken uyarı sistemi değildir.\n" +
                "• Deprem verileri kurumlarca sonradan güncellenebilir (büyüklük/konum değişir).\n" +
                "• İnternetsiz yakın cihaz iletişimi menzil, engeller ve karşı tarafta uygulamanın açık olmasına bağlıdır; garanti vermez.\n" +
                "• Tehlikede önce 112'yi ara.", fontSize = 13.sp)
        }
        Card2 {
            Text("Gizlilik", style = MaterialTheme.typography.titleMedium)
            Text("Konumun yalnızca mesafe hesabı, harita ve senin başlattığın paylaşımlar için kullanılır. Yakın cihaz mesajlarında adın ve konumun yakındaki kullanıcılara iletilir. Reklamlar için Google AdMob kullanılır; onay formu ilk açılışta gösterilir.", fontSize = 13.sp)
        }
        Text("Sürüm ${app.depremkalkani.BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
