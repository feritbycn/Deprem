package app.depremkalkani.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.depremkalkani.dk

/**
 * Bir sayfada gereken izin kapalıysa küçük bir uyarı bandı gösterir ve oradan açtırır.
 * Kullanıcı izni "bir daha sorma" ile reddettiyse sistem penceresi çıkmaz; bu durumda uygulama ayarlarına götürür.
 * dismissible = true ise kapatılabilir; kapatma sonrası 3 gün / 2 hafta / 2 ay sonra yeniden görünür, en fazla 3 kez.
 */
@Composable
fun PermBanner(
    key: String, text: String, perms: Array<String>, granted: () -> Boolean,
    dismissible: Boolean = false, modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val sp = ctx.dk.prefs.sp
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }   // ayarlardan dönünce yenile

    fun missing() = perms.filter { androidx.core.content.ContextCompat.checkSelfPermission(ctx, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
    fun openSettings() {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        toast(ctx, "Açılan ekranda İzinler bölümünden aç")
    }
    fun blockedForever(): Boolean {
        val act = ctx as? Activity ?: return false
        val m = missing()
        return m.isNotEmpty() && sp.getBoolean("pa_$key", false) && m.none { androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(act, it) }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
        if (!granted() && blockedForever()) openSettings()
    }

    val gaps = longArrayOf(3, 14, 60).map { it * 86_400_000L }
    val count = sp.getInt("pd_$key", 0)
    val at = sp.getLong("pda_$key", 0L)
    var hidden by remember(tick) { mutableStateOf(dismissible && (count >= 3 || System.currentTimeMillis() - at < gaps[count.coerceAtMost(2)])) }
    val ok = remember(tick) { granted() }
    if (ok || hidden) return

    Card2(modifier) {
        Text(text, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button({
                if (blockedForever()) openSettings()
                else { sp.edit().putBoolean("pa_$key", true).apply(); launcher.launch(perms.distinct().toTypedArray()) }
            }) { Text("İzin ver") }
            if (dismissible) TextButton({
                sp.edit().putInt("pd_$key", count + 1).putLong("pda_$key", System.currentTimeMillis()).apply(); hidden = true
            }) { Text("Kapat") }
        }
    }
}
