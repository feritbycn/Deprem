package app.depremkalkani.ui

import android.Manifest
import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.depremkalkani.R
import app.depremkalkani.data.Notifs
import app.depremkalkani.dk

enum class PK { NOTIF, LOC, BATT, MONITOR, FSI, NEARBY, BGDATA, MIC }

class PItem(val kind: PK, val emoji: String, val title: String, val why: String, val required: Boolean, val ok: Boolean, val action: String)

/** Uygulamanın düzgün çalışması için gereken izin/ayarların durumu. */
object PermHealth {
    fun items(ctx: Context): List<PItem> {
        val prefs = ctx.dk.prefs
        val nm = ctx.getSystemService(android.app.NotificationManager::class.java)
        val pm = ctx.getSystemService(PowerManager::class.java)
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val notifOk = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        val locOk = Perms.has(ctx, arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION)) || Perms.has(ctx, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
        val battOk = runCatching { pm.isIgnoringBatteryOptimizations(ctx.packageName) }.getOrDefault(true)
        val fsiOk = Build.VERSION.SDK_INT < 34 || runCatching { nm.canUseFullScreenIntent() }.getOrDefault(true)
        val bgOk = runCatching { cm.restrictBackgroundStatus != ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED }.getOrDefault(true)
        return listOf(
            PItem(PK.NOTIF, "🔔", "Bildirimler", "Deprem, sismik dalga ve yakınlarından gelen uyarıların sana ulaşması için.", true, notifOk, "İzin ver"),
            PItem(PK.LOC, "📍", "Konum", "Depremin sana uzaklığını hesaplamak ve bölgene göre uyarmak için. Konumun sunucuya kaydedilmez.", true, locOk, "İzin ver"),
            PItem(PK.BATT, "🔋", "Pil kısıtlaması yok", "Telefon pil tasarrufuna girince uygulamanın kapanmaması ve uyarıların gecikmemesi için.", true, battOk, "Kısıtlamayı kaldır"),
            PItem(PK.MONITOR, "📡", "Canlı takip", "Uygulama kapalıyken bile depremleri arka planda takip eder.", true, prefs.monitorOn, "Aç"),
            PItem(PK.FSI, "📲", "Kilit ekranında tam ekran uyarı", "Ekran kilitliyken sismik dalga uyarısı ve geri sayım hemen açılsın.", false, fsiOk, "İzin ver"),
            PItem(PK.NEARBY, "🤝", "Yakındaki cihazlar", "İnternet yokken çevrendeki kullanıcılara mesaj ve SOS iletmek için (Bluetooth).", false, Perms.hasNearby(ctx), "İzin ver"),
            PItem(PK.BGDATA, "📶", "Arka planda veri", "Veri tasarrufu açıksa arka plandaki takip ve bildirimler engellenebilir.", false, bgOk, "Ayarı aç"),
            PItem(PK.MIC, "🎙️", "Mikrofon", "Yalnızca sesli mesaj kaydederken kullanılır, isteğe bağlıdır.", false, Perms.has(ctx, arrayOf(Manifest.permission.RECORD_AUDIO)), "İzin ver"),
        )
    }

    fun missingRequired(ctx: Context) = items(ctx).filter { it.required && !it.ok }

    private const val ID = 7300

    /** Önemli bir ayar eksikse (en çok 3 günde bir) sessiz bir hatırlatma bildirimi gönderir; her şey tamamsa kaldırır. */
    fun checkAndNotify(ctx: Context) {
        val prefs = ctx.dk.prefs
        val miss = missingRequired(ctx)
        val nm = NotificationManagerCompat.from(ctx)
        if (miss.isEmpty()) { runCatching { nm.cancel(ID) }; prefs.sp.edit().remove("ph_sig").apply(); return }
        if (!Notifs.canPost(ctx)) return
        val sig = miss.joinToString(",") { it.kind.name }
        val last = prefs.sp.getLong("ph_last", 0L)
        val sameSig = prefs.sp.getString("ph_sig", "") == sig
        val gap = if (sameSig) 3 * 86_400_000L else 6 * 3600_000L
        if (System.currentTimeMillis() - last < gap) return
        prefs.sp.edit().putLong("ph_last", System.currentTimeMillis()).putString("ph_sig", sig).apply()
        val n = NotificationCompat.Builder(ctx, Notifs.CH_HEALTH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("${miss.size} ayar eksik")
            .setContentText("Deprem uyarılarını kaçırabilirsin: " + miss.joinToString(", ") { it.title.lowercase() } + ". Dokunup düzelt.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Deprem uyarılarını kaçırabilirsin: " + miss.joinToString(", ") { it.title.lowercase() } + ". Dokunup tek tek düzelt."))
            .setPriority(NotificationCompat.PRIORITY_LOW).setAutoCancel(true)
            .setContentIntent(Notifs.openDestIntent(ctx, "perms")).build()
        runCatching { nm.notify(ID, n) }
    }
}
