package app.depremkalkani.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import app.depremkalkani.dk
import app.depremkalkani.service.MonitorService

@Composable
fun PermsScreen() {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val items = remember(tick) { PermHealth.items(ctx) }
    val done = items.count { it.ok }
    val missReq = items.count { it.required && !it.ok }

    fun appSettings() { runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    fun launchIntent(i: Intent) { runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.onFailure { appSettings() } }

    var lastKind by remember { mutableStateOf<PK?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        tick++
        // "Bir daha sorma" ile reddedildiyse sistem penceresi çıkmaz: uygulama ayarlarına götür
        val activity = ctx as? Activity
        if (res.values.any { !it } && activity != null && res.keys.none { ActivityCompat.shouldShowRequestPermissionRationale(activity, it) }) {
            if (lastKind == PK.NOTIF) launchIntent(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)) else appSettings()
        }
    }

    fun act(p: PItem) {
        lastKind = p.kind
        when (p.kind) {
            PK.NOTIF -> {
                if (android.os.Build.VERSION.SDK_INT >= 33 && !Perms.has(ctx, Perms.notification)) permLauncher.launch(Perms.notification)
                else launchIntent(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
            }
            PK.LOC -> permLauncher.launch(Perms.location)
            PK.BATT -> launchIntent(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            PK.MONITOR -> { prefs.monitorOn = true; runCatching { MonitorService.start(ctx) }; tick++ }
            PK.FSI -> launchIntent(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}")))
            PK.NEARBY -> permLauncher.launch((Perms.nearby + Perms.notification).distinct().toTypedArray())
            PK.BGDATA -> launchIntent(Intent(Settings.ACTION_IGNORE_BACKGROUND_DATA_RESTRICTIONS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            PK.MIC -> permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
    }

    val good = DK.Teal
    val warn = DK.Accent2
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Özet kartı: halka + durum
        Card2(brush = if (missReq == 0) DK.Cool else DK.Hero) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = 9.dp.toPx()
                        drawArc(Color.White.copy(alpha = 0.25f), 0f, 360f, false, topLeft = Offset(w / 2, w / 2), size = Size(size.width - w, size.height - w), style = Stroke(w))
                        drawArc(if (missReq == 0) good else Color.White, -90f, 360f * done / items.size, false, topLeft = Offset(w / 2, w / 2), size = Size(size.width - w, size.height - w), style = Stroke(w, cap = StrokeCap.Round))
                    }
                    Text("$done/${items.size}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(if (missReq == 0) "Her şey hazır ✓" else "$missReq önemli ayar eksik", color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text(if (missReq == 0) "Deprem uyarıları sana zamanında ulaşır." else "Eksikleri tamamla; yoksa uyarıları geç alabilir ya da kaçırabilirsin.",
                        color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                }
            }
        }
        Section("Gerekli", items.filter { it.required }, good, warn) { act(it) }
        Section("Önerilen", items.filter { !it.required }, good, warn) { act(it) }

        Card2 {
            Text("Kullanılmayan uygulama ayarı", style = MaterialTheme.typography.titleMedium)
            Text("Android, uzun süre açılmayan uygulamaların izinlerini silebilir. Uygulama ayarlarında \"Kullanılmıyorsa uygulama izinlerini kaldır\" seçeneğini kapat; deprem uyarıları kesilmesin.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton({ appSettings() }, Modifier.padding(top = 6.dp)) { Text("Uygulama ayarlarını aç") }
        }
        Card2 {
            Text("Bazı telefonlar uygulamayı kapatır", style = MaterialTheme.typography.titleMedium)
            Text("Xiaomi, Oppo, Huawei, Samsung gibi markalar arka plan uygulamalarını sert kısıtlar. Telefonuna özel adımlar için aşağıdaki rehbere bak.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton({ launchIntent(Intent(Intent.ACTION_VIEW, Uri.parse("https://dontkillmyapp.com/"))) }, Modifier.padding(top = 6.dp)) { Text("Telefonuma özel rehber") }
        }
    }
}

@Composable
private fun Section(title: String, list: List<PItem>, good: Color, warn: Color, onAct: (PItem) -> Unit) {
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp, start = 4.dp))
    list.forEach { p ->
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background((if (p.ok) good else warn).copy(alpha = 0.2f)), contentAlignment = Alignment.Center) { Text(p.emoji, fontSize = 22.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(p.why, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            if (p.ok) Text("✓", color = good, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            else Button({ onAct(p) }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) { Text(p.action, fontSize = 12.sp) }
        }
    }
}
