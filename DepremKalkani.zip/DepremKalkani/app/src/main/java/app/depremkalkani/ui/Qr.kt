package app.depremkalkani.ui

import android.graphics.Bitmap
import android.graphics.Color as AColor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

/** Ortaya uygulama simgesi konur; hata düzeltme seviyesi H olduğu için (~%30 kayıp tolere edilir) kod yine okunur. Logo alanın ~%18'ini kaplar. */
fun qrBitmap(text: String, px: Int = 640, logo: android.graphics.drawable.Drawable? = null): Result<Bitmap> = runCatching {
    val hints = HashMap<EncodeHintType, Any>()
    hints[EncodeHintType.MARGIN] = 1
    hints[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.H
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, px, px, hints)
    val pixels = IntArray(px * px) { i -> if (m.get(i % px, i / px)) AColor.BLACK else AColor.WHITE }
    val bmp = Bitmap.createBitmap(pixels, px, px, Bitmap.Config.ARGB_8888)
    if (logo != null) runCatching {
        val c = android.graphics.Canvas(bmp)
        val box = (px * 0.22f).toInt()          // beyaz zemin
        val ico = (box * 0.82f).toInt()         // simge
        val l = (px - box) / 2; val t = l
        val bg = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE }
        c.drawRoundRect(l.toFloat(), t.toFloat(), (l + box).toFloat(), (t + box).toFloat(), box * 0.22f, box * 0.22f, bg)
        val il = (px - ico) / 2
        logo.setBounds(il, il, il + ico, il + ico)
        logo.draw(c)
    }
    bmp
}

/** Google'ın kod tarayıcısı kendi ekranında kamerayı açar; uygulamaya kamera izni gerekmez. */
fun scanInviteQr(ctx: android.content.Context, onCode: (String) -> Unit, onError: (String) -> Unit) {
    runCatching {
        val opts = com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(com.google.mlkit.vision.barcode.common.Barcode.FORMAT_QR_CODE).build()
        com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(ctx, opts).startScan()
            .addOnSuccessListener { b ->
                val v = b.rawValue?.trim().orEmpty()
                if (v.startsWith("DK1.") || v.startsWith("DKG1.")) onCode(v) else onError("Bu QR bir Deprem Kalkanı daveti değil.")
            }
            .addOnFailureListener { e ->
                if (!(e is com.google.android.gms.common.api.ApiException && e.statusCode == 16))
                    onError("QR taranamadı (" + (e.message ?: e.javaClass.simpleName) + "). Kodu elle yapıştırabilirsin.")
            }
    }.onFailure { onError("QR tarayıcı açılamadı. Kodu elle yapıştırabilirsin.") }
}

/** Davet kodunu QR olarak gösterir (koyu temada da beyaz zemin, kolay okunur). */
@Composable
fun QrImage(text: String, size: Int = 230) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val res = remember(text) { qrBitmap(text, 640, runCatching { ctx.packageManager.getApplicationIcon(ctx.packageName) }.getOrNull()) }
    val bmp = res.getOrNull()
    if (bmp == null) {
        androidx.compose.material3.Text("QR oluşturulamadı: " + (res.exceptionOrNull()?.let { it.javaClass.simpleName + " " + (it.message ?: "") } ?: ""),
            color = androidx.compose.material3.MaterialTheme.colorScheme.error, fontSize = androidx.compose.ui.unit.TextUnit.Unspecified)
        return
    }
    Image(bmp.asImageBitmap(), "Davet QR kodu", Modifier.size(size.dp).background(Color.White).padding(8.dp))
}
