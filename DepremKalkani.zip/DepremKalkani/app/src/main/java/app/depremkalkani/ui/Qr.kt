package app.depremkalkani.ui

import android.graphics.Bitmap
import android.graphics.Color as AColor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

/**
 * QR bitmap'i çizer. Modüller tam sayı piksel boyutunda çizilir (bulanıklık yok), ortaya uygulama simgesi konur.
 * Hata düzeltme seviyesi H (~%30 kayıp tolere edilir); logo QR alanının yalnızca ~%6'sını kaplar.
 * Not: Bitmap.createBitmap(IntArray...) DEĞİŞTİRİLEMEZ bitmap verir, üstüne çizilemez; bu yüzden boş bitmap + Canvas kullanılır.
 */
fun qrBitmap(text: String, px: Int = 1024, logo: android.graphics.drawable.Drawable? = null): Result<Bitmap> = runCatching {
    val hints = HashMap<EncodeHintType, Any>()
    hints[EncodeHintType.MARGIN] = 2
    hints[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.H
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 1, 1, hints)   // doğal boyut (sessiz bölge dahil)
    val n = m.width
    val mod = maxOf(1, px / n)
    val size = mod * n
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    c.drawColor(AColor.WHITE)
    val dark = android.graphics.Paint().apply { color = AColor.BLACK; isAntiAlias = false }
    for (y in 0 until n) for (x in 0 until n) if (m.get(x, y))
        c.drawRect((x * mod).toFloat(), (y * mod).toFloat(), ((x + 1) * mod).toFloat(), ((y + 1) * mod).toFloat(), dark)
    if (logo != null) runCatching {
        // Kalkan, QR'ın üstüne doğrudan yerleştirilir (arkasında beyaz kutu YOK); kalkanın dışında QR noktaları aynen devam eder.
        // Simge 108x108'lik tuvalde; kalkan 60 birim yüksekliğinde, tuvalin ortasında. Kalkan yüksekliği = QR'ın %22'si (alanın ~%4'ü; H düzeltmesi %30 tolere eder).
        val dsz = (108f * (0.22f * size / 60f)).toInt()
        val half = dsz / 2; val mid = size / 2
        logo.setBounds(mid - half, mid - half, mid + half, mid + half)
        logo.draw(c)
    }
    bmp
}

/** Yalnızca kalkan çizimi (şeffaf zeminli ön plan katmanı). */
fun qrLogo(ctx: android.content.Context): android.graphics.drawable.Drawable? =
    runCatching { androidx.core.content.ContextCompat.getDrawable(ctx, app.depremkalkani.R.drawable.ic_launcher_foreground)?.mutate() }.getOrNull()

/** QR'ı 4K (3840 px) PNG olarak paylaşır: yazdırmaya ya da ekrana atmaya yeter. */
fun shareQrImage(ctx: android.content.Context, text: String) {
    kotlin.concurrent.thread {
        val icon = qrLogo(ctx)
        val bmp = qrBitmap(text, 3840, icon).getOrNull() ?: return@thread
        val f = java.io.File(ctx.cacheDir, "qr/deprem_kalkani_davet.png").also { it.parentFile?.mkdirs() }
        java.io.FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = android.content.Intent(android.content.Intent.ACTION_SEND).setType("image/png")
            .putExtra(android.content.Intent.EXTRA_STREAM, uri).addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            runCatching { ctx.startActivity(android.content.Intent.createChooser(i, "QR resmini paylaş").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }
}

/** Google'ın kod tarayıcısı kendi ekranında kamerayı açar; uygulamaya kamera izni gerekmez. */
fun scanInviteQr(ctx: android.content.Context, onCode: (String) -> Unit, onError: (String) -> Unit) {
    runCatching {
        val opts = com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(com.google.mlkit.vision.barcode.common.Barcode.FORMAT_QR_CODE).build()
        com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(ctx, opts).startScan()
            .addOnSuccessListener { b ->
                val v = b.rawValue?.trim().orEmpty()
                if (v.startsWith("DK1.") || v.startsWith("DKG1.")) onCode(v) else onError("Bu QR bir Deprem Kalkanı daveti değil.")
            }
            .addOnFailureListener { e ->
                if (!(e is com.google.android.gms.common.api.ApiException && e.statusCode == 16))
                    onError("QR taranamadı (" + (e.message ?: e.javaClass.simpleName) + "). Kodu elle yapıştırabilirsin.")
            }
    }.onFailure { onError("QR tarayıcı açılamadı. Kodu elle yapıştırabilirsin.") }
}

/** Davet kodunu QR olarak gösterir (koyu temada da beyaz zemin, kolay okunur). */
@Composable
fun QrImage(text: String, size: Int = 230) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val res = remember(text) { qrBitmap(text, 1024, qrLogo(ctx)) }
    val bmp = res.getOrNull()
    if (bmp == null) {
        androidx.compose.material3.Text("QR oluşturulamadı: " + (res.exceptionOrNull()?.let { it.javaClass.simpleName + " " + (it.message ?: "") } ?: ""),
            color = androidx.compose.material3.MaterialTheme.colorScheme.error, fontSize = androidx.compose.ui.unit.TextUnit.Unspecified)
        return
    }
    Image(bmp.asImageBitmap(), "Davet QR kodu", Modifier.size(size.dp).background(Color.White).padding(8.dp), filterQuality = androidx.compose.ui.graphics.FilterQuality.None)
}
