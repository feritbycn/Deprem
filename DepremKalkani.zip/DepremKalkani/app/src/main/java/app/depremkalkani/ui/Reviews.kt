package app.depremkalkani.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import app.depremkalkani.data.Prefs
import com.google.android.play.core.review.ReviewManagerFactory
import com.google.android.play.core.ktx.launchReview
import com.google.android.play.core.ktx.requestReview

/** Uygulama içi puanlama ve paylaşım. Play bağlantısı paket adından otomatik oluşur. */
object Reviews {
    fun storeUrl(ctx: Context) = "https://play.google.com/store/apps/details?id=${ctx.packageName}"

    /** Kullanıcıyı rahatsız etmeyen zamanlama: 5+ açılış, 3+ gün, en fazla 3 kez, aralarda 60 gün. */
    fun due(p: Prefs): Boolean {
        val now = System.currentTimeMillis()
        return p.launchCount >= 5 && p.firstLaunch > 0 && now - p.firstLaunch >= 3 * 86_400_000L &&
            p.reviewAskCount < 3 && now - p.reviewAskedAt >= 60 * 86_400_000L
    }

    fun markAsked(p: Prefs) { p.reviewAskedAt = System.currentTimeMillis(); p.reviewAskCount = p.reviewAskCount + 1 }

    /** Play'in uygulama içi puanlama penceresi. Gösterilip gösterilmeyeceğine Play karar verir (kota); olmazsa mağaza sayfası açılır. */
    suspend fun launchInApp(act: Activity) {
        runCatching {
            val m = ReviewManagerFactory.create(act)
            val info = m.requestReview()
            m.launchReview(act, info)
        }.onFailure { openStore(act) }
    }

    fun openStore(ctx: Context) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }.onFailure {
            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl(ctx))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    fun share(ctx: Context) = Share.text(ctx,
        "Deprem Kalkanı: canlı deprem takibi, sismik dalga uyarısı ve internetsiz yakın mesajlaşma.\nİndir: ${storeUrl(ctx)}")
}
