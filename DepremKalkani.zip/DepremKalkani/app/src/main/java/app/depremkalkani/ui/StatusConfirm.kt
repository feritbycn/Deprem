package app.depremkalkani.ui

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import app.depremkalkani.mesh.MsgType

/** Durum bildirimi (Güvendeyim, Yaralıyım, SOS...) göndermeden önce yanlışlıkla basmaya karşı onay sorar. */
@Composable
fun StatusConfirmDialog(type: MsgType, onOk: () -> Unit, onCancel: () -> Unit) {
    val (title, body) = when (type) {
        MsgType.SAFE -> "Güvende olduğunu bildir?" to "Yakınlarına ve yakınındaki kullanıcılara \"Güvendeyim\" mesajı gidecek."
        MsgType.INJURED -> "Yaralı olduğunu bildir?" to "Yakınlarına ve yakınındaki kullanıcılara yaralı olduğunu bildiren mesaj gidecek. Yardıma gelmeye çalışabilirler."
        MsgType.NEED -> "Malzeme ihtiyacını bildir?" to "Yakınlarına ve yakınındaki kullanıcılara su, yiyecek ve ilaç ihtiyacın bildirilecek."
        MsgType.SOS -> "SOS gönderilsin mi?" to "Enkaz altında olduğunu bildiren acil çağrı yakınlarına ve yakınındaki kullanıcılara gidecek. Yanlışlıkla bastıysan Vazgeç'e dokun."
        else -> "Gönderilsin mi?" to "Mesaj gönderilecek."
    }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = { Text(body) },
        confirmButton = { TextButton(onOk) { Text("Gönder") } },
        dismissButton = { TextButton(onCancel) { Text("Vazgeç") } },
    )
}
