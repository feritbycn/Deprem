package app.depremkalkani.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object DK {
    val Bg = Color(0xFF0A0F1F)
    val Surface = Color(0xFF121A33)
    val SurfaceHi = Color(0xFF1A2447)
    val Accent = Color(0xFFFF5A3C)
    val Accent2 = Color(0xFFFFB347)
    val Teal = Color(0xFF2DD4BF)
    val Danger = Color(0xFFE5383B)
    val Muted = Color(0xFF8E9ABF)
    val Hero = Brush.linearGradient(listOf(Color(0xFF2B1B4D), Color(0xFF7A1F3D), Color(0xFFFF5A3C)))
    val Cool = Brush.linearGradient(listOf(Color(0xFF14264F), Color(0xFF1D4E89)))
    val SosBrush = Brush.linearGradient(listOf(Color(0xFFB00020), Color(0xFFFF3D00)))

    fun magColor(m: Double): Color = when {
        m >= 6 -> Color(0xFFB5179E); m >= 5 -> Color(0xFFE5383B); m >= 4 -> Color(0xFFFF8A00)
        m >= 3 -> Color(0xFFFFC53D); else -> Color(0xFF2DD4BF)
    }
}

private val Dark = darkColorScheme(
    primary = DK.Accent, onPrimary = Color.White, secondary = DK.Teal, onSecondary = Color(0xFF00201C),
    background = DK.Bg, onBackground = Color(0xFFEFF2FF),
    surface = DK.Surface, onSurface = Color(0xFFEFF2FF), surfaceVariant = DK.SurfaceHi, onSurfaceVariant = DK.Muted,
    error = DK.Danger, outline = Color(0xFF2B3763),
    surfaceContainer = DK.Surface, surfaceContainerHigh = DK.SurfaceHi,
)
private val Light = lightColorScheme(
    primary = Color(0xFFD7381C), onPrimary = Color.White, secondary = Color(0xFF0B8F80),
    background = Color(0xFFF4F6FD), onBackground = Color(0xFF0E1530),
    surface = Color.White, onSurface = Color(0xFF0E1530), surfaceVariant = Color(0xFFE8ECFA), onSurfaceVariant = Color(0xFF5A678F),
    outline = Color(0xFFC9D1EE),
)

@Composable
fun DepremTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography = Typography(
            headlineLarge = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp),
            headlineMedium = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
            titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
            titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
            bodyLarge = TextStyle(fontSize = 16.sp),
            bodyMedium = TextStyle(fontSize = 14.sp),
            labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
            labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium),
        ),
        content = content,
    )
}
