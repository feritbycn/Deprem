package app.depremkalkani.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.data.AppUpdate

/** Üstte sabit güncelleme şeridi. Acil ekranında gösterilmez. */
@Composable
fun UpdateBar(phase: AppUpdate.Phase, progress: Int, waitingSafe: Boolean, onUpdate: () -> Unit) {
    if (phase == AppUpdate.Phase.NONE) return
    val green = phase != AppUpdate.Phase.AVAILABLE
    val brush = if (green) Brush.horizontalGradient(listOf(Color(0xFF1F6F5B), Color(0xFF2AA37D)))
                else Brush.horizontalGradient(listOf(Color(0xFFFF7A4D), Color(0xFFC2262E)))
    Column(Modifier.fillMaxWidth().background(brush).statusBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(when (phase) {
                AppUpdate.Phase.AVAILABLE -> "⬆ Yeni sürüm hazır"
                AppUpdate.Phase.DOWNLOADING -> "⬇ İndiriliyor…  %$progress"
                else -> if (waitingSafe) "✔ İndirildi — bu ekrandan çıkınca kurulacak" else "✔ Güncelleniyor, uygulama yeniden açılacak…"
            }, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (phase == AppUpdate.Phase.AVAILABLE) Text("Güncelle", color = Color(0xFFC2262E), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White).clickable { onUpdate() }.padding(horizontal = 12.dp, vertical = 5.dp))
        }
        if (phase == AppUpdate.Phase.DOWNLOADING) LinearProgressIndicator(progress = { progress / 100f },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(4.dp), color = Color.White, trackColor = Color.White.copy(alpha = 0.3f))
    }
}
