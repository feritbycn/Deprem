package app.depremkalkani.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay

/** Ortada simge, etrafında yayılan halkalar: "Wi-Fi aranıyor / paylaşılıyor" hissi. */
@Composable
fun WifiPulse(emoji: String, color: Color, size: Dp = 88.dp, animate: Boolean = true) {
    val t = rememberInfiniteTransition(label = "wifi")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "p")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val c = this.size.minDimension / 2
            if (animate) for (k in 0..2) {
                val q = (p + k / 3f) % 1f
                drawCircle(color.copy(alpha = (1f - q) * 0.55f), radius = c * (0.45f + 0.55f * q), style = Stroke(width = 4f))
            }
            drawCircle(color.copy(alpha = 0.16f), radius = c * 0.5f)
        }
        Text(emoji, fontSize = (size.value * 0.36f).sp)
    }
}

@Composable
fun WifiTitle(text: String, emoji: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        WifiPulse(emoji, color, size = 52.dp)
        Text(text, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun StepRow(index: Int, emoji: String, title: String, body: String, color: Color) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(120L * index); a.animateTo(1f, tween(380)) }
    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 28f }
            .clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)).padding(10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(color.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 17.sp)
        }
        Column(Modifier.padding(start = 10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(body, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OnlyAppBanner() {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(DK.Danger.copy(alpha = 0.12f)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("📱", fontSize = 22.sp)
        Text(
            "Yalnızca Deprem Kalkanı yüklü telefonlar arasında çalışır. Uygulaması olmayan telefonlara ve normal Wi-Fi ağlarına istek gitmez.",
            fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp),
        )
    }
}

/** "Kime gider?" bilgi ekranı: Mesajlar, Wi-Fi iste ve Wi-Fi paylaş için ayrı sekmeler. */
@Composable
fun InfoTabsDialog(initialTab: Int, onClose: () -> Unit) {
    var tab by remember { mutableIntStateOf(initialTab) }
    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
            Column(Modifier.padding(top = 10.dp)) {
                TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
                    Tab(tab == 0, { tab = 0 }, text = { Text("Mesajlar", fontSize = 12.sp) })
                    Tab(tab == 1, { tab = 1 }, text = { Text("Wi-Fi iste", fontSize = 12.sp) })
                    Tab(tab == 2, { tab = 2 }, text = { Text("Wi-Fi paylaş", fontSize = 12.sp) })
                }
                Column(
                    Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()).padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    when (tab) {
                        0 -> {
                            WifiPulse("💬", DK.Teal, size = 72.dp)
                            Text("Mesajın kime gider?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            OnlyAppBanner()
                            StepRow(0, "📡", "Yakındaki telefonlara", "Tanımadığın kişiler de olabilir; Yakınlarım listesinde olmaları gerekmez.", DK.Teal)
                            StepRow(1, "📏", "Menzil", "Açık alanda yaklaşık 50–100 m. Aradaki telefonlar mesajı iletir (en fazla 8 atlama). Başka şehre gitmez.", DK.Teal)
                            StepRow(2, "🌐", "İnternet gerekmez", "Karşı telefonda uygulama ve Yakındakiler taraması açık olmalı.", DK.Accent2)
                            StepRow(3, "📍", "Konum", "Normal sohbette konum gitmez. Yalnızca \"Konumumu paylaş\" dersen yaklaşık konum (~200 m) gider.", DK.Accent2)
                            StepRow(4, "🔓", "Gizlilik", "Adın görünür. Mesajlar şifreli değildir; özel bilgi yazma. Aile kodu girdiysen normal mesajlar yalnız aynı kodu kullananlara görünür (SOS herkese).", DK.Danger)
                            StepRow(5, "👨\u200d👩\u200d👧", "Yalnız tanıdıklarına", "\"Kime\" bölümünden Yakınlarım'ı seç. Bu mesajlar internet üzerinden şifreli gider.", DK.Teal)
                        }
                        1 -> {
                            WifiPulse("🙋", DK.Accent2, size = 72.dp)
                            Text("Wi-Fi iste", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Şebekesi olmayan biri (örneğin enkaz altında), yakındaki birinden internet ister.", fontSize = 13.sp, textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            OnlyAppBanner()
                            StepRow(0, "📶", "1. Düğmeye bas", "\"Wi-Fi iste\" yakındaki kullanıcılara istek gönderir. SOS gönderdiysen ve internetin yoksa düğme turuncu vurgulanır.", DK.Accent2)
                            StepRow(1, "⏳", "2. Bekle", "Biri hotspot'unu açıp paylaşırsa \"Wi-Fi paylaşıldı\" bildirimi gelir. Yakında bağlı cihaz yoksa istek biri bağlanınca otomatik gider.", DK.Teal)
                            StepRow(2, "🔗", "3. Bağlan", "\"Bağlan\"a bas, şifre yazma. Bağlantı yalnızca bu uygulama içindir (Yakınlarım mesajları gibi).", DK.Teal)
                            Text("Dakikada en fazla bir istek gönderilebilir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        else -> {
                            WifiPulse("📲", DK.Teal, size = 72.dp)
                            Text("Wi-Fi paylaş", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("İnternetin varsa, yardıma ihtiyacı olan birine hotspot'unu paylaşırsın.", fontSize = 13.sp, textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            OnlyAppBanner()
                            StepRow(0, "⚙️", "1. Hazırlan", "\"Wi-Fi paylaş\"a basıp hotspot adını ve şifreni kaydet. Sadece buna ayırdığın geçici bir şifre kullan.", DK.Accent2)
                            StepRow(1, "🔔", "2. İstek gelince onayla", "Biri Wi-Fi isterse bildirim gelir. Hotspot'unu aç ve Paylaş de. Bilgi yalnızca isteyene, şifreli gider.", DK.Teal)
                            StepRow(2, "📡", "3. Bağlananlar internetini kullanır", "Hotspot'u uygulama açamaz; telefon ayarlarından elle açman gerekir (kısayol var). İş bitince kapat.", DK.Danger)
                        }
                    }
                }
                TextButton(onClose, Modifier.align(Alignment.End).padding(end = 8.dp, bottom = 6.dp)) { Text("Anladım") }
            }
        }
    }
}
