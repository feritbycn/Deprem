package app.depremkalkani.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay

/** Ortada simge, etrafında yayılan halkalar: "Wi-Fi aranıyor / paylaşılıyor" hissi. */
@Composable
fun WifiPulse(emoji: String, color: Color, size: Dp = 88.dp, animate: Boolean = true) {
    val t = rememberInfiniteTransition(label = "wifi")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "p")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val c = this.size.minDimension / 2
            if (animate) for (k in 0..2) {
                val q = (p + k / 3f) % 1f
                drawCircle(color.copy(alpha = (1f - q) * 0.55f), radius = c * (0.45f + 0.55f * q), style = Stroke(width = 4f))
            }
            drawCircle(color.copy(alpha = 0.16f), radius = c * 0.5f)
        }
        Text(emoji, fontSize = (size.value * 0.36f).sp)
    }
}

@Composable
fun WifiTitle(text: String, emoji: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        WifiPulse(emoji, color, size = 52.dp)
        Text(text, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun StepRow(index: Int, emoji: String, title: String, body: String, color: Color) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(120L * index); a.animateTo(1f, tween(380)) }
    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 28f }
            .clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)).padding(10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(color.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 17.sp)
        }
        Column(Modifier.padding(start = 10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(body, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Wi-Fi paylaşımının ne işe yaradığını adım adım, kısa ve görsel anlatan bilgi ekranı. */
@Composable
fun WifiInfoDialog(onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                WifiPulse("📶", DK.Teal)
                Text("Wi-Fi yardımı", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Şebekesi olmayan birine, yakındaki biri internetini paylaşır.", fontSize = 13.sp, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                StepRow(0, "🙋", "1. Wi-Fi iste", "İnternete ihtiyacı olan kişi düğmeye basar. İstek yakındaki kullanıcılara gider.", DK.Accent2)
                StepRow(1, "📲", "2. Paylaşan onaylar", "İsteği alan, hotspot'unu açıp ad ve şifreyi yazar. Bilgi yalnızca isteyene, şifreli gider.", DK.Teal)
                StepRow(2, "🔗", "3. Tek dokunuşla bağlan", "İsteyen \"Bağlan\"a basar. Şifre yazmaz. Bağlantı yalnızca bu uygulama için geçerlidir.", DK.Teal)
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(DK.Accent2.copy(alpha = 0.14f)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text("Bilmen gerekenler", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("• Hotspot'u uygulama açamaz; telefon ayarlarından elle açılır (kısayol var).", fontSize = 12.sp)
                    Text("• Bağlanan, paylaşanın internetini kullanır. Sadece buna ayırdığın geçici bir şifre kullan.", fontSize = 12.sp)
                    Text("• Yakında bağlı cihaz yoksa istek iletilemez; biri bağlanınca otomatik gider.", fontSize = 12.sp)
                }
                TextButton(onClose, Modifier.align(Alignment.End)) { Text("Anladım") }
            }
        }
    }
}
